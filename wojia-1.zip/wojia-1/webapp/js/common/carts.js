function toCart(param, callback) {
	try {
		// setCookie(param.shopid,"cart",null);
		if (!JF.isValid(param.data)) {
			return;
		}
		var cart = getCookie(param.shopid, "cart"); 
		if (!JF.isValid(cart)) {
			cart = [];
		}
		var getGoods = null;
		var len = cart.length;
		for (var i = 0; i < len; i++) {
			var goods = cart[i];
			if (goods.id == param.data.id && goods.specVal.val == param.specVal.val) {
				// 找到同一个商品同一规格
				getGoods = goods;
				break;
			}
		}
		if (JF.isValid(getGoods)) {
			var num = getGoods.num;
			num = parseInt(num) + parseInt(param.num);
			getGoods.num = num;
		} else {
			getGoods = param.data;
			cart.push({
				num : parseInt(param.num),
				id : getGoods.id,
				name : getGoods.name,
				advDesc : getGoods.advDesc,
				specVal : param.specVal,
				specKey : parseInt(param.specKey),
				headPic : getGoods.headPic,
				boothid : getGoods.boothid,
				categoryid : getGoods.categoryid,
			});
		}
		setCookie(param.shopid, "cart", cart);
		 
		//console.log(getCookie(param.shopid, "cart"));

		if (param.target) {
			var clewPanel = $("<div class='border7 circle boxSize4 p-bottom middle red-bgcolor'>");
			var clew = $("<span class='w-color strong h iconfont icon-caigou'>");
			clewPanel.css("left", "50%");
			clewPanel.css("bottom", "50%");
			clewPanel.append(clew);
			param.target.append(clewPanel);
			setTimeout(function() {
				clewPanel.animate({
					bottom : 0,
					left : 100
				}, 500, function() {
					clewPanel.remove();
					if (callback)
						callback();
				});
			}, 200);
		}else{
			if (callback)
				callback();
		}
	} catch (e) { 
		setCookie(param.shopid, "cart", null);
	}
}
function delCart(param, callback) {
	var cart = getCookie(param.shopid, "cart");
	//console.log(param);
	if (JF.isValid(cart)) {
		var getGoods = null;
		var len = cart.length;
		for (var i = len - 1; i >= 0; i--) {
			var goods = cart[i];
			if (goods.id == param.data.id && goods.specVal.val == param.specVal.val) {
				// 找到同一个商品同一规格
				getGoods = goods;

				if (param.del == true) {
					cart.splice(i, 1);
				} else if (param.cover == true) {
					// 直接覆盖数量
					getGoods.num = parseInt(param.num);
				} else {
					var num = parseInt(getGoods.num) - parseInt(param.num);
					if (num <= 0) {
						num = 0;
					}
					getGoods.num = num;
				}
				break;
			}
		}
		setCookie(param.shopid, "cart", cart);
		if (callback)
			callback();
	}

	//console.log(getCookie(param.shopid, "cart"));
}

function getCart(shopid) {
	var cart = getCookie(shopid, "cart");
	//console.log(cart);
	if (!JF.isValid(cart)) {
		cart = [];
	}
	return cart;
}
function getCartCount(shopid) {
	var cart = getCart(shopid);
	var sum = 0;
	var len = cart.length;
	for (var i = 0; i < len; i++) {
		var goods = cart[i];
		sum += parseInt(goods.num);
	}
	return sum;
}