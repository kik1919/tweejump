/*******************************************************************************
 * 
 */
JF.define("jf.ui.Config", {
	Config : function(args) {
		this.editImage = {
			html : "editImage.html",
			js : "js/common/cropper.min.js,js/common/util.js",
			css : "css/cropper.min.css",
			text : "编辑图片"
		};
		this.edit = {
			html : "edit.html",
			js : "js/kindeditor-4.1.1/kindeditor-min.js,js/kindeditor-4.1.1/lang/zh_CN.js,js/common/mobile.upload.js",
			text : "文本编辑"
		};
		this.editBrowse = {
			html : "editBrowse.html",
			text : "编辑预览"
		};
		this.cityList = {
			html : "cityList.html",
			text : "城市列表"
		};
		this.bankList = {
			html : "bankList.html",
			text : "银行列表"
		};
		this.expressList = {
			html : "expressList.html",
			text : "快递公司"
		};
		this.login = {
			html : "login.html",
			js : "js/common/MD5.min.js",
			text : "登录"
		};
		this.register = {
			html : "register.html",
			js : "js/common/MD5.min.js",
			text : "注册"
		};
		this.addUser = {
			html : "addUser.html",
			js : "js/common/photoswipe.min.js,js/common/photoswipe-ui-default.min.js,js/common/mobile.upload.js,js/common/util.js",
			text : "维护资料"
		};
		this.addCard = {
			html : "addCard.html",
			js : "js/common/photoswipe.min.js,js/common/photoswipe-ui-default.min.js,js/common/mobile.upload.js,js/common/util.js",
			css : "css/photoswipe.css,css/default-skin/default-skin.css",
			text : "联盟卡维护"
		};
		this.addBooth = {
			html : "addBooth.html",
			js : "js/common/photoswipe.min.js,js/common/photoswipe-ui-default.min.js,js/common/mobile.upload.js,js/common/util.js",
			css : "css/photoswipe.css,css/default-skin/default-skin.css",
			text : "门店维护"
		};
		this.addGoods = {
			html : "addGoods.html",
			js : "js/common/photoswipe.min.js,js/common/photoswipe-ui-default.min.js,js/common/mobile.upload.js,js/common/util.js",
			css : "css/photoswipe.css,css/default-skin/default-skin.css",
			text : "活动维护"
		};
		this.boothTypeMgr = {
			html : "boothTypeMgr.html",
			text : "类别管理"
		};
		this.addBoothType = {
			html : "addBoothType.html",
			js : "js/common/mobile.upload.js,js/common/util.js",
			text : "编辑类别"
		};
		this.goodsType = {
			html : "goodsType.html",
			text : "活动类别 "
		};
		this.mgrBooth = {
			html : "mgrBooth.html",
			text : "门店管理 "
		};
		this.boothType = {
			html : "boothType.html",
			text : "门店类型 "
		};
		this.main = {
			html : "main.html",
			text : "小i联盟"
		};
		this.changeBooth = {
			html : "changeBooth.html",
			text : "切换门店"
		};
		this.login = {
			html : "login.html",
			js : "js/common/MD5.min.js",
			text : "登录"
		};
		this.register = {
			html : "register.html",
			js : "js/common/MD5.min.js",
			text : "注册"
		};
		this.locationCard = {
			html : "locationCard.html",
			text : "小i联盟"
		};
		this.boothGoodsList = {
			html : "boothGoodsList.html",
			text : "门店活动"
		};
		this.map = {
			html : "map.html",
			text : "商圈位置"
		};
		this.mapChoose = {
			html : "mapChoose.html",
			text : "地图选址"
		};
		this.booths = {
			html : "booths.html",
			text : "门店列表"
		};
		this.goodss = {
			html : "goodss.html",
			text : "发布活动"
		};
		this.users = {
			html : "users.html",
			text : "客户列表"
		};
		this.qrcodeStat = {
			html : "qrcodeStat.html",
			js : "js/common/mobiscroll.core-2.5.2.js,js/common/mobiscroll.core-2.5.2-zh.js,js/common/mobiscroll.datetime-2.5.1.js,js/common/mobiscroll.datetime-2.5.1-zh.js",
			css : "css/mobiscroll.core-2.5.2.css",
			text : "推广统计"
		};
		this.usersSearch = {
			html : "usersSearch.html",
			text : "查找客户"
		};
		this.useGoods = {
			html : "useGoods.html",
			text : "消费记录"
		};
		this.mySPBG = {
			html : "mySPBG.html",
			text : "待服务项目"
		};
		this.boothDetail = {
			html : "boothDetail.html",
			js : "js/common/jflex.js,js/common/photoswipe.min.js,js/common/photoswipe-ui-default.min.js",
			css : "css/animate.css,css/jflex.css,css/photoswipe.css,css/default-skin/default-skin.css",
			text : "门店介绍 "
		};
		this.myQrcode = {
			html : "myQrcode.html",
			text : "推广联盟卡"
		};
		this.cardQrcode = {
			html : "cardQrcode.html",
			text : "联盟卡推广码"
		};
		this.myCards = {
			html : "myCards.html",
			text : "我的联盟卡"
		};
		this.cardMgr = {
			html : "cardMgr.html",
			text : "联盟卡管理"
		};
		this.my = {
			html : "my.html",
			text : "我的"
		};
		this.withdrawCashLog = {
			html : "withdrawCashLog.html",
			text : "本月提现"
		};
		this.withdrawHis = {
			html : "withdrawHis.html",
			js : "js/common/mobiscroll.core-2.5.2.js,js/common/mobiscroll.core-2.5.2-zh.js,js/common/mobiscroll.datetime-2.5.1.js,js/common/mobiscroll.datetime-2.5.1-zh.js",
			css : "css/mobiscroll.core-2.5.2.css",
			text : "历史提现"
		};
		this.withdrawDetail = {
			html : "withdrawDetail.html",
			js : "js/common/mobiscroll.core-2.5.2.js,js/common/mobiscroll.core-2.5.2-zh.js,js/common/mobiscroll.datetime-2.5.1.js,js/common/mobiscroll.datetime-2.5.1-zh.js",
			css : "css/mobiscroll.core-2.5.2.css",
			text : "提现明细"
		};
		this.incomeDetails = {
			html : "incomeDetails.html",
			js : "js/common/mobiscroll.core-2.5.2.js,js/common/mobiscroll.core-2.5.2-zh.js,js/common/mobiscroll.datetime-2.5.1.js,js/common/mobiscroll.datetime-2.5.1-zh.js",
			css : "css/mobiscroll.core-2.5.2.css",
			text : "提现明细"
		};
		this.myFriend = {
			html : "myFriend.html",
			text : "提现明细（朋友）"
		};
		this.myFriendFriend = {
			html : "myFriendFriend.html",
			text : "朋友的朋友"
		};
		this.mySpList = {
			html : "mySpList.html",
			text : "已购套餐"
		};
		this.myUsageRecord = {
			html : "myUsageRecord.html",
			text : "消费记录"
		};
		this.vipProtocol = {
			html : "vipProtocol.html",
			text : "会员须知"
		};
		this.signDetail = {
			html : "signDetail.html",
			text : "签到详情"
		};
		this.viewPdf = {
			html : "viewPdf.html",
			text : "浏览PDF"
		};
		this.docList = {
			html : "docList.html",
			text : "文档资料"
		};
		this.appointmentDetail = {
			html : "appointmentDetail.html",
			text : "预约详情"
		};
	},

});