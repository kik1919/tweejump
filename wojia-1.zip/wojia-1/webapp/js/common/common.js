var url = getRootPath()+"/";   
var curDate = formatDate(new Date(), "yyyy-MM-dd");
var timeout = 100000;
var mainUrl = "index"; 
var curShopid=null;// 当前门店ID
var curShop=jf.os.session.get("shopData");
 
// js获取项目根路径，如： http://localhost:8083/uimcardprj
function getRootPath(){
    // 获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    // 获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    // 获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    // 获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}

/**
 * 生成唯一订单号
 */
function MID(name,len){	
	name==null?name="":name=name
	var outTradeNo="";  // 订单号
	for(var i=0;i<3;i++)  {
	    outTradeNo += Math.floor(Math.random()*10);
	}
	outTradeNo = new Date().getTime() + outTradeNo;  // 时间戳，用来生成订单号。
	var rs=outTradeNo;
	if(JF.isValid(len)) {
		var l=rs.length;
		var s=l-len; 
		return name+rs.substring(s);
	}else {
		return name+rs;
	} 
}
/*******************************************************************************
 * 服务器请求
 * 
 * @param param
 * @returns
 */
function request(param){ 
	
	var service="";
	if(JF.isValid(param.service)){
		service=param.service;
	}else if(JF.isValid(param.url)){
		service=url + param.url;
	} 
	
	param.method ? true : param.method = "POST";
	param.cache ? true : param.cache = false;
	param.async ? true : param.async = true; 
	param.dataType ? true : param.dataType = "JSON";
	param.reqData ? true : param.reqData = {};  
	// alert(JSON.stringify(param));
	var loading=new jf.ui.Loading();
	if(JF.isNull(param.loading)||param.loading==true){
		loading.show();
	}
	$.ajax({
		"url" : service,
		"cache" : param.cache,
		"async": param.async,
		"data" : param.reqData,
		"timeout" : timeout,
		"dataType":param.dataType,
		"type" : param.method,
		"success" : function(rs) {  
			// alert(JSON.stringify(rs));
			if(JF.isNull(param.loading)||param.loading==true){
				loading.hide();
			}
			if (rs.state == 2) {
				// 权限错误
				if(JF.isValid(param.authError)){
					param.authError(rs);
				}else{
					var params=getUrlParams();// 获取所有的参数
					loader.openWin({
						name:"login",
						data:params
					});
				}
			}else if (rs.state != 0) {
				if(JF.isValid(param.success)){
					param.success(rs);
				}
			} else { 
				if(JF.isValid(param.fail)){
					param.fail(rs);
				}
			}
		},
		"error" : function(XMLHttpRequest) {  
			if(JF.isNull(param.loading)||param.loading==true){
				loading.hide();
			}
			if(JF.isValid(param.error)){
				param.error(XMLHttpRequest);
			}else{
				new jf.ui.Alert({
					text : "网络故障",
				}); 
			}
		}
	});
}
/*******************************************************************************
 * 获取门店信息，加载公众号配置
 * 
 * @param param
 * @param callback
 * @returns
 */
getShop = function(param, callback, errorback) {
	if (typeof param == "function") {
		errorback = callback;
		callback = param;
		param = {};
	}
  
	var data = {
		id : param.shopid,
		isDel : 0,
		isPass : 1,
	};
	 
	 // alert("请求参数：" + JSON.stringify(param));
	request({
		"url" : "shop/get",
		"reqData" : data,  
		"method":"POST",
		"success" : function(rs) {
			var shopData = rs.data;  
			curShop=shopData;
			curShopid=shopData.id;
			
			setCookie(curShopid,"WH", {
				w : $("body").width(),
				h : $("body") * 9 / 16
			});

			setCookie(curShopid,"WHS", {
				w : $("body").width(),
				h : $("body").height()
			}); 
			var cart = getCookie(curShopid,"cart");
			if (!JF.isValid(cart)) {
				setCookie(curShopid,"cart", [])
			}  
			jf.os.session.save({
				shopData : shopData
			});
			if (callback) {
				callback(shopData);
			}
		},
		"fail" : function(rs) {
			if (errorback)
				errorback(rs);
		},
		"error" : function(XMLHttpRequest) {
			if (errorback)
				errorback(XMLHttpRequest);
		}
	}); 
} 
/*******************************************************************************
 * 获取当前用户openid必须现获取code
 * 
 * @returns
 */
function getWeixinCode() {
	var code = "";
	var r = window.location.search.substr(1);
	var r_ = r.split("&");
	for (var i = 0; i < r_.length; i++) {
		if (r_[i].indexOf("code") != -1) {
			code = r_[i].split("=")[1];
		}
	}
	return unescape(code);
}
  
/*******************************************************************************
 * 此方法值适用于当前登录用户信息查询，不可用于查询他人信息, 一旦调用此方法，本地缓存的客户信息将被覆盖 如果没有找到，则会自动注册用户简单数据
 * 
 * @param data
 * @param callback
 * @param error
 * @returns
 */
function getUserByOpenid(data, callback, error) {  
	var code = getWeixinCode();
	if (!JF.isValid(code)) {
		new jf.ui.BottomToast({ 
			text : "无法获取code",
			s : 2000
		}).show();
		if (error)
			error("无法获取code");
		return;
	}
	data.code=code; 
	// alert("请求参数：" + JSON.stringify(data));
	request({
		"url" : "weChat/getWeChatInfo", 
		"reqData" : data,  
		"success" : function(rs) {
			//alert("响应数据：" + JSON.stringify(rs));
			var user=rs.data.user;  
			if(user.isDel==1){
				new jf.ui.Toast({
					text : "用户已经禁用",
					s : 2000
				}).show();
				return;
			}else{
				setCookie(data.shopid,"loginUser", user, 362);  
				if (callback)
					callback(user);
			}
		},
		"fail" : function(rs) {
			new jf.ui.BottomToast({ 
				text : rs.message,
				s : 2000
			}).show();

			if (error)
				error(rs.message); 
		},
		"error" : function(XMLHttpRequest) {
			loading.hide();
		}
	});

} 
function gotoMiniProgram(param){
	wx.miniProgram.navigateTo({
		url : param.url+"?shopid=" + curShopid + "&"+encodeParam(param.data)
	}); 
}
function encodeParam(data){
	var str="";
	for(var key in data){
		str+=key+"="+data[key]+"&"
	}
	if(str!=""){ 
		str=str.substring(0,str.length-1);
	}
	return str;
}
/*******************************************************************************
 * 微信支付 调用前必须先调用getUserByOpenid方法获取当前用户的信息
 * 
 * @param data
 * @param callback
 * @param error
 * @param cancel
 * @returns
 */
function weixinPay(data, callback, error, cancel) {
	var me = this;
	data.userid=getUser(curShopid).id;  
	isProgram(function(){
		// 小程序
		setTimeout(function(){
			new jf.ui.Alert({ 
				type : 1,
				text : "还未完成支付？",
				okText:"继续支付",
				cancelText:"取消支付",
				ok : function() {
					weixinPay(data, callback, error, cancel);  
				},
				cancel:function(){
					if(error){
						error();
					}
				}
			});
		},2000); 
		gotoMiniProgram({
			url : "../register/register",
			data:data 
		});
	
	},function(){ 
		var loading = new jf.ui.Loading({
			text : "正在微信下单"
		});
		loading.showBG();   
		request({
			"url" : "weChat/unifiedorder",
			"reqData" : data, 
			"loading":false,
			"method" : "GET",
			"success" : function(rs) {
				// alert("响应数据：" + JSON.stringify(rs));
				loading.hide(); 
				wechatPay(rs.data,callback, error, cancel);
			},
			"fail" : function(rs) {
				loading.hide();
				new jf.ui.Alert({ 
					type : 0,
					text : rs.message,
					ok : function() {
						if (error)
							error();
					}
				});
			},
			"error" : function(XMLHttpRequest) {
				loading.hide();
			}
		}); 
	});  
}
/*******************************************************************************
 * 调用微信支付sdk
 * 
 * @param payJson
 * @param callback
 * @param error
 * @param cancel
 * @returns
 */
function wechatPay(payJson, callback, error, cancel) {
	// alert("==========wechatPay===="+JSON.stringify(payJson));
	if (typeof WeixinJSBridge == "undefined") { 
		if (document.addEventListener) { 
			document.addEventListener('WeixinJSBridgeReady', callWechatPay, false);
		} else if (document.attachEvent) { 
			document.attachEvent('WeixinJSBridgeReady', callWechatPay);
			document.attachEvent('onWeixinJSBridgeReady', callWechatPay);
		}
	} else { 
		callWechatPay(payJson, callback, error, cancel);
	}
}
/*******************************************************************************
 * 微信支付回调
 * 
 * @param payJson
 * @param callback
 * @param error
 * @param cancel
 * @returns
 */
function callWechatPay(payJson, callback, error, cancel) {
	// alert("========5==========callWechatPay"+payJson);
	WeixinJSBridge.invoke('getBrandWCPayRequest', {
		"appId" : payJson.appId, // 公众号名称，由商户传入
		"timeStamp" : payJson.timeStamp, // 时间戳，自1970年以来的秒数
		"nonceStr" : payJson.nonceStr, // 随机串
		"package" : payJson.package,
		"signType" : payJson.signType, // 微信签名方式：
		"paySign" : payJson.paySign
	// 微信签名
	}, function(res) { 
		if (res.err_msg == "get_brand_wcpay_request:ok") { 
			if (callback) {
				callback(payJson.billid);
			}
		} else if (res.err_msg == "get_brand_wcpay_request:cancel") {
			// alert("支付取消");
			if (cancel) {
				cancel();
			} 
		} else {
			// alert("支付失败!" + res.err_msg);
			if (error) {
				error();
			}
		}
	});
}

function logout(param, success, fail) {  
	request({
		"url" : "user/logout",
		"reqData" : param,
		"method" : "POST",
		"success" : function(data) { 
			if (success)
				success(data);
		},
		"fail" : function(rs) {
			if (fail)
				fail(rs);
		}
	});
}
function autoLogin(param, success, fail) {  
	request({
		"url" : "user/login",
		"reqData" : param,
		"method" : "POST",
		"success" : function(data) { 
			var user = data.data.loginUser;
			setCookie(curShopid, "loginUser", user); 
			if (success)
				success(data);
		},
		"fail" : function(rs) { 
			if (fail)
				fail(rs);
		}
	});
}

/*******************************************************************************
 * 给控件绑定语音录入
 * 
 * @param el
 * @returns
 */
function bindVoice(el,callback){
	var me=this;
	var value = {};
	if (JF.isValid(curShopid)) {
		value.shopid = curShopid;
	} 
	registerWX(value, function() {
		wx.checkJsApi({
			jsApiList : [ "startRecord","stopRecord","translateVoice" ], // 需要检测的JS接口列表，所有JS接口列表见附录2,
			success : function(res) {
				var cr=res.checkResult; 
				if (cr.startRecord == true&&cr.stopRecord == true&&cr.translateVoice == true) { 
					
					el.on("tap", function(event) {  
						new jf.ui.Loading().show();
						wx.startRecord({
							success : function() { 
								new jf.ui.Toast({
									text : "正在录音<br/>点击关闭结束录音",
									iconfont:"iconfont icon-maikefeng",
									width : "50%",
									s:30000,
									noScrollHide:1,
									callback:function(){
										wx.stopRecord({
											success : function(res) { 
												var localId = res.localId; 
												wx.translateVoice({
													localId : localId, // 需要识别的音频的本地Id，由录音相关接口获得
													isShowProgressTips : 1, // 默认为1，显示进度提示
													success : function(res) { 
														var rs=res.translateResult; 
														if(JF.isValid(rs)&&callback){
															callback(rs,el); // 语音识别的结果
														} 
													},
													fail: function (res) {  
											        }
												});
											},
											fail: function (res) {  
									        }
										});
									}
								}).show();
							},
							cancel : function() {
								new jf.ui.Toast({ 
									text : "用户拒绝授权录音",
									width : "50%"
								}).show(); 
							}
						});
					});
					wx.onVoiceRecordEnd({
						// 录音时间超过一分钟没有停止的时候会执行 complete 回调
						complete: function (res) {
							var localId = res.localId;  
							wx.translateVoice({
								localId : localId, // 需要识别的音频的本地Id，由录音相关接口获得
								isShowProgressTips : 1, // 默认为1，显示进度提示
								success : function(res) { 
									var rs=res.translateResult; 
									if(JF.isValid(rs)&&callback){
										callback(rs,el); // 语音识别的结果
									} 
								},
								fail: function (res) {  
						        }
							});
						}
					}); 
				} else {
					new jf.ui.Toast({ 
						text : "手机微信不支持录音组件<br/>请更新微信到最新版",
						width : "50%",
						s:4000
					}).show();
				}
			}
		});
	});
}
/*******************************************************************************
 * 注册微信对象
 * 
 * @returns
 */
function registerWX(value,callback) { 
	var me = this;
	 
	var param = {
		cusUrl : window.location.href,
		shopid:value.shopid
	};
	// alert("请求参数：" + JSON.stringify(param));
	request({
		"url" :  "jssdk/index", 
		"reqData" : param, 
		"loading":false,
		"success" : function(rs) { 
			// alert("响应数据：" + JSON.stringify(data));

			var data = rs.data;  
			wx.config({
				debug : false,
				appId : data.appId,
				timestamp : data.timestamp,
				nonceStr : data.nonceStr,
				signature : data.signature,
				jsApiList : [ 'checkJsApi', 'updateAppMessageShareData', 'updateTimelineShareData', 'onMenuShareWeibo', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'translateVoice', 'startRecord', 'stopRecord', 'onRecordEnd', 'playVoice', 'pauseVoice', 'stopVoice', 'uploadVoice', 'downloadVoice', 'chooseImage','getLocalImgData', 'previewImage', 'uploadImage', 'downloadImage', 'getNetworkType', 'openLocation', 'getLocation', 'hideOptionMenu',
						'showOptionMenu', 'closeWindow', 'scanQRCode', 'chooseWXPay', 'openProductSpecificView', 'addCard', 'chooseCard', 'openCard' ]
			}); 
			wx.ready(function() {
				if(callback){
					callback();
				}else{
					if(JF.isValid(value)){
						// 默认注册分享组件
						wx.checkJsApi({
							jsApiList : [ "updateTimelineShareData","updateAppMessageShareData" ], // 需要检测的JS接口列表，所有JS接口列表见附录2,
							success : function(res) { 
								var cr=JSON.parse(res.checkResult); 
								if (cr.updateTimelineShareData== true && cr.updateAppMessageShareData== true) { 
									wx.updateAppMessageShareData({ 
								    	title : value.title,
										desc :value.desc,
										link : value.link,
										imgUrl : value.imgUrl,
									}, function(res) { 
										alert(1);
									});  
									wx.updateTimelineShareData({ 
								    	title : value.title,
										desc :value.desc,
										link : value.link,
										imgUrl : value.imgUrl,
									}, function(res) { 
										alert(1);
									}); 
								} else {
									new jf.ui.Toast({ 
										text : "手机微信不支持分享组件<br/>请更新微信到最新版",
										width : "50%",
										s:4000
									}).show();
								}
							}
						}); 
					} 
				} 
			}); 
			wx.error(function(res) {
				new jf.ui.Alert({ 
					text : res.errMsg,
				});  
			}); 
		},
		"fail" : function(rs) { 
			registerWX(value,callback)
		},
		"error" : function(XMLHttpRequest) { 
			registerWX(value,callback)
		}
	});
}; 
 
 
/*******************************************************************************
 * 获取用户数据库数据
 * 
 * @param shopid
 * @returns
 */
function getUser(shopid){ 
	// setCookie(shopid,"loginUser");
	var user = getCookie(shopid,"loginUser"); 
	// alert(JSON.stringify(user));
	if(!JF.isValid(user)){
		// 先获取父类门店
		getShop({
			shopid : shopid,
			async:false
		}, function(shop) { 
			user = getCookie(shop.id,"loginUser");
		},function(){
		}); 
	}
	return user;
}
/*******************************************************************************
 * 刷新当前登录用户
 * 
 * @returns
 */
function refreshUser(shopid,callback){ 
	var user=getUser(shopid); 
	request({
		"url" : "user/get",
		"reqData" : {
			id:user.id
		},  
		"loading":false,
		"method":"POST",
		"success" : function(rs) { 
			// alert(JSON.stringify(rs.data));
			var user = rs.data;
			setCookie(shopid, "loginUser", user); 
			if(callback){
				callback(user);
			}
		},
		"fail" : function(rs) {alert();
			if (errorback)
				errorback(rs);
		},
		"error" : function(XMLHttpRequest) {
			if (errorback)
				errorback(XMLHttpRequest);
		}
	});
}
 
function logout(shopid,callback){
	request({
		"url" : "user/logout", 
		"method" : "POST",
		"success" : function(rs) {

			new jf.ui.BottomToast({ 
				text : rs.message,
				s : 2000
			}).show();
			setCookie(shopid,"loginUser", null); 
			loader.openWin({
				name : "login", 
				data:{
					callback:function(){
						if(callback){
							callback();
						} 
					}
				}
			});
			
		},
		"fail" : function(rs) {
			new jf.ui.BottomToast({ 
				text : rs.message,
				s : 2000
			}).show();
		},
		"error" : function(XMLHttpRequest) {
			new jf.ui.Alert({ 
				text : "网络故障",
			});
		}
	});
}
function toUtf8(str) {
	var out, i, len, c;
	out = "";
	len = str.length;
	for (i = 0; i < len; i++) {
		c = str.charCodeAt(i);
		if ((c >= 0x0001) && (c <= 0x007F)) {
			out += str.charAt(i);
		} else if (c > 0x07FF) {
			out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
			out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
		} else {
			out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
			out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F));
		}
	}
	return out;
}
function randomNum(minNum, maxNum) { 
	var today = new Date();
	var day = today.getDate(); // 获取当前日(1-31)
	var month = today.getMonth() + 1; // 显示月份比实际月份小1,所以要加1
	var year = today.getYear(); // 获取完整的年份(4位,1970-????) getFullYear()
	var years = today.getFullYear();
	years = years < 99 ? "20" + years : years;
	month = month < 10 ? "0" + month : month; // 数字<10，实际显示为，如5，要改成05
	day = day < 10 ? "0" + day : day;
	var hh = today.getHours();
	hh = hh < 10 ? "0" + hh : hh;
	var ii = today.getMinutes();
	ii = ii < 10 ? "0" + ii : ii;
	var ss = today.getSeconds();
	ss = ss < 10 ? "0" + ss : ss;

	var dada = years + month + day + hh + ii + ss;// 时间不能直接相加，要这样相加！！！14位

	switch (arguments.length) {
	case 1:
		return dada + parseInt(Math.random() * minNum + 1, 10);
		break;
	case 2:
		return dada + parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
		break;
	default:
		return 0;
		break;
	}
}
function testMoney(val) {
	if (val == "0.0" || val == "0.00") {
		return false;
	} else {
		var reg1 = /^([1-9][0-9]{0,8})$/;
		var reg2 = /^([1-9][0-9]{0,8}(\.[0-9]{1,2}){1})$/;
		var reg3 = /^([0](\.[0-9]{1,2}){1})$/;
		return reg1.test(val) || reg2.test(val) || reg3.test(val);
	}
};
function cauScale(maxW, maxH, w, h) {
	var me = this;
	var rw, rh;
	if (w < maxW && h < maxH) {
		rw = w;
		rh = h;
	} else {
		var pWidth = w / (h / maxH);
		var pHeight = h / (w / maxW);
		rw = w > h ? maxW : pWidth;// 如果原始图片宽度大于高度，则取画布宽度
		rh = h > w ? maxH : pHeight;// 如果原始图片高度大于宽度，则取画布高度
	}
	return {
		w : rw,
		h : rh
	}
}

/*******************************************************************************
 * 获取URL地址参数
 * 
 * @param name
 * @returns
 */
function getUrlParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	// 构造一个含有目标参数的正则表达式对象
	var r = window.location.search.substr(1).match(reg);
	// 匹配目标参数
	if (r != null)
		return unescape(r[2]);
	return null;
	// 返回参数值
} 
/*******************************************************************************
 * 获取URL地址参数集合
 * 
 * @param name
 * @returns
 */
function getUrlParams() {
	var obj={};
	var url=window.location.search;
	var i=url.indexOf("?");
	if(i!=-1){ 
		var p=url.substring(i+1);
		var a=p.split("&");
		$(a).each(function(){
			var r=this.split("=");
			obj[r[0]]=r[1]; 
		});
	}  
	return obj;
} 
function getUrlParamBool(name) {
	var val=getUrlParam(name); 
	if(val=="true"){
		return true;
	}else if(val=="false"){
		return false; 
	}else{
		return false;
	}
} 

function setCookie(shopid,c_name, value) { 
	var shopLocalData=jf.os.local.get(shopid); 
	if(!JF.isValid(shopLocalData)){
		var d={};
		shopLocalData={};
		d[shopid]=shopLocalData;
		jf.os.local.save(d);
	} 
	shopLocalData[c_name]=value; 
	var data={};
	data[shopid]=shopLocalData; 
	jf.os.local.save(data);
	 
} 
// 取回cookie
function getCookie(shopid,c_name) {
	var shopLocalData=jf.os.local.get(shopid); 
	if(JF.isValid(shopLocalData)){
		return shopLocalData[c_name]; 
	}else{
		return null;
	}
} 
 
/*******************************************************************************
 * 判断终端
 */
var isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1; // android终端
var isiOS = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); // ios终端

/*******************************************************************************
 * 是否是微信浏览器
 * 
 * @returns
 */
function isWeixin() {
	var ua = navigator.userAgent.toLowerCase();
	if (ua.match(/MicroMessenger/i) == "micromessenger") {
		return true;
	} else {
		return false;
	}
} 
/*******************************************************************************
 * 是否是小程序
 * 
 * @returns
 */
function isProgram(success,fail){ 
    wx.miniProgram.getEnv(function(res) { 
        if (res.miniprogram) {
            // 走在小程序的逻辑
        	success();
        } else {
            // 走不在小程序的逻辑
        	fail();
        }
    })
}

function getLocation(callback,rsCallback){ 
	if (!isWeixin()) {
		getLocationBaidu(callback,rsCallback);
	} else { 
		getLocationWX(callback,rsCallback); 
	} 
}
/*******************************************************************************
 * 获取本地位置
 * 
 * @param callback
 * @returns
 */
function getLocationBaidu(callback,rsCallback) { 
	var beijingLoaction = function() {
		myLocation = {
			lon : 116.384767,
			lat : 39.989539,
			city : "北京",
			province : "北京"
		};

		// console.log('您的位置：' + JSON.stringify(myLocation));

		var obj = {};
		obj["myLocation"] = myLocation;
		jf.os.session.save(obj);

		callback(myLocation.lon, myLocation.lat, myLocation.province, myLocation.city);

	}
	try {
		// 百度地图API功能
		if (!JF.isValid($("#allmap")[0])) {
			$("body").append($("<div id='allmap'></div>"));
		}
		var map = new BMap.Map("allmap");
		var point = new BMap.Point(116.331398, 39.897445);
		var geolocation = new BMap.Geolocation(); 
		geolocation.getCurrentPosition(function(r) {
			if (this.getStatus() == BMAP_STATUS_SUCCESS) {
				if(rsCallback){
					rsCallback();
				}
				myLocation = {
					lon : r.point.lng,
					lat : r.point.lat,
					city : r.address.city,
					province : r.address.province
				};
				callback(myLocation.lon, myLocation.lat, myLocation.province, myLocation.city.replace("市",""));
				// console.log('您的位置：' + JSON.stringify(myLocation));

				var obj = {};
				obj["myLocation"] = myLocation;
				jf.os.session.save(obj);

			} else {
				beijingLoaction();
			}
		}, {
			enableHighAccuracy : true
		})
	} catch (e) { 
		throw e;
		new jf.ui.BottomToast({ 
			text : e,
		}).show();
		beijingLoaction();
	}
} 

/*******************************************************************************
 * 获取本地位置
 * 
 * @param callback
 * @returns
 */
function getLocationWX(callback,rsCallback) { 
	var beijingLoaction = function() {
		myLocation = {
			lon : 116.384767,
			lat : 39.989539,
			city : "北京",
			province : "北京"
		};

		// console.log('您的位置：' + JSON.stringify(myLocation));

		var obj = {};
		obj["myLocation"] = myLocation;
		jf.os.session.save(obj);

		callback(myLocation.lon, myLocation.lat, myLocation.province, myLocation.city);

	}
	try {
		// alert("开始注册微信wx");

		var value = {};
		if (JF.isValid(curShopid)) {
			value.shopid = curShopid;
		}
		registerWX(value, function() {
			// alert("成功注册wx，准备定位");
			if(rsCallback){
				rsCallback();
			}
			wx.checkJsApi({
				jsApiList : [ "getLocation" ], // 需要检测的JS接口列表，所有JS接口列表见附录2,
				success : function(res) { 
					if (res.checkResult && res.checkResult.getLocation == true||JSON.parse(res.checkResult).geoLocation) {
						wx.getLocation({
							type : 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
							success : function(res) { 
								var latitude = res.latitude; // 纬度，浮点数，范围为90
																// ~
								// -90
								var longitude = res.longitude; // 经度，浮点数，范围为180
																// ~
								// -180。
								var speed = res.speed; // 速度，以米/每秒计
								var accuracy = res.accuracy; // 位置精度
								 
								var ggPoint = new BMap.Point(longitude, latitude);
								
								// 把地图坐标转换成百度地图坐标
								var convertor = new BMap.Convertor();
								var pointArr = [];
								pointArr.push(ggPoint);
								convertor.translate(pointArr, 1, 5, function(data) {
									if (data.status === 0) {
										var point=data.points[0];
										// alert(JSON.stringify(point));
										myLocation = {
											lon : point.lng,
											lat : point.lat,
										};
										// alert('您的位置：' +
										// JSON.stringify(myLocation));
										callback(myLocation.lon, myLocation.lat, myLocation.province, myLocation.city);
										var obj = {};
										obj["myLocation"] = myLocation;
										jf.os.session.save(obj); 
									}
								}) 
								
							},
							cancel : function(res) {
								new jf.ui.Alert({ 
									text : "用户拒绝授权获取地理位置",
								}); 
							},
							error : function(res) { 
								new jf.ui.Alert({ 
									text : "error",
								});
							},
							fail : function(res) {
								
								new jf.ui.Alert({ 
									text : "无法获取您的城市信息<br/>请确认已经打开手机定位<br/>请稍后重试!"+JSON.stringify(res),
								}); 
							},
						});
					} else {
						new jf.ui.Toast({
							text : "手机微信不支持坐标组件<br/>请更新微信到最新版",
							width : "50%",
							s:4000
						}).show();
					}
				}
			});
		});

	} catch (e) {
		throw e;
		new jf.ui.BottomToast({ 
			text : e,
		}).show();
		beijingLoaction();
	}
} 
/*******************************************************************************
 * 图片加载错误的时候显示的图片
 * 
 * @param img
 * @param size
 * @returns
 */
function imgerror(img,size){
	if(size=="640x260"){
		img.src="img/640x260NOIMG.jpg"; 
	}else if(size=="500x250"){
		img.src="img/500x250NOIMG.jpg"; 
	}else if(size=="500x500"){
		img.src="img/500x500NOIMG.jpg"; 
	}else if(size=="640x360"){
		img.src="img/640x360NOIMG.jpg";
	}else if(size=="200x200"){
		img.src="img/200x200NOIMG.jpg";
	}else if(size=="295x413"){
		img.src="img/295x413NOIMG.jpg";
	} 
	img.onerror=null;   // 控制不要一直跳动
} 
 
/*******************************************************************************
 * 格式化时间
 */
function formatDate(date, format) {
	if (!format) {
		format = "yyyy-MM-dd hh:mm:ss";
	}
	if (!date) {
		date = new Date();
	}
	var o = {
		"M+" : date.getMonth() + 1, // month
		"d+" : date.getDate(), // day
		"h+" : date.getHours(), // hour
		"m+" : date.getMinutes(), // minute
		"s+" : date.getSeconds(), // second
		"q+" : Math.floor((date.getMonth() + 3) / 3), // quarter
		"S" : date.getMilliseconds()
	// millisecond
	};

	if (/(y+)/.test(format)) {
		format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
	}

	for ( var k in o) {
		if (new RegExp("(" + k + ")").test(format)) {
			format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
		}
	}
	return format;
};
 

// ///////////购买卡///////////////////
function buyCard(param,callback,error){
	request({
		"url" : "buyCard/add",
		"reqData" : {
			userid : param.user.id,
			referee : param.referee,
			cardid : param.cardid
		},
		"cache" : false,
		"method" : "POST",
		"success" : function(data) {
			var returnid = data.data.buyId;
			var money = data.data.buyMoney;
			var name = data.data.name;
			var pay = function() {
				// 在线支付
				weixinPay({
					billid : returnid,
					busid : returnid,
					busType : 1,// 0：会员升级；1：联盟卡支付
					shopid : curShopid,
					backUrl : "locationCard",
					money:money,
					cardid : param.cardid
				}, function() {
					// 支付完成，重新加载页面
					if(callback){
						callback();
					}
				}, function() {
					// 失败
					if(error){
						error();
					}
				}, function() {
					// 取消
					if(error){
						error();
					}
				});
			}
			
			isProgram(function(){
				// 小程序
				if (param.user.isRegisterWx==0||!JF.isValid(param.user.mobile)) {
					gotoMiniProgram({
						url : "../register/register",
						data:{
							backUrl : "locationCard",
							userid : param.user.id,
							billid : returnid,
							busid : returnid,
							busType : 1,// 0：会员升级；1：联盟卡支付
							money:money, 
							cardid : param.cardid
						} 
					});
				} else {
					pay();
				}
			},function(){
				if (!JF.isValid(param.user.mobile)) {
					loader.openWin({
						name : "register",
						data : {
							callback : function(user) {
								if(callback){
									callback();
								}
								pay();
							}
						}
					});
				} else {
					pay();
				}
			}); 
		},
		"fail" : function(data) {
			new jf.ui.Toast({
				text : data.message,
				s : 2000,
				callback:function(){ 
					loader.openWin({
						name : "main",
						animate : false,
						data : {
							cardid : data.data.id,
							location : getUser(curShopid).location
						}
					});
				}
			}).show();
		}
	});
	
}

function isVip(param,callback,error){
	var me = this;
	var user = getUser(param.shopid);
	if(JF.isValid(user.vip)){
		if(callback)
			 callback(user.vip);
		return;
	}
	request({
		"url" : "vip/get",
		"reqData" : {
			userid : param.userid
		},
		"method" : "POST",
		"success" : function(data) {
			// console.log("响应数据：" + JSON.stringify(data));
			user.vip=data;
			setCookie(param.shopid, "loginUser", user); 
			if(callback)
			 callback(data);
		},
		"fail" : function(rs) { 
			// 提醒客户绑定共享会员账号
			isProgram(function() {
				// 小程序
				gotoMiniProgram({
					url : "../bindwx/bindwx",
					data : {
						shopid : param.shopid,
					}
				});
				if(error)
					error(rs);
				return;
			}, function() {
				new jf.ui.BottomToast({
					text : "请联系共享会员管理员",
					s : 10000,
					callback : function() {
						if(error)
							error(rs);
					}
				}).show();
			});

		}
	});
}
