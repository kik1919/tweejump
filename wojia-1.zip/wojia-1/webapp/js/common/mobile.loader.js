JF.define("jf.util.Loader", {
	Loader : function(args) {
		this.isLoad = false;
		this.reqData = null;
		this.weixinShare = false;
		this.$ = $;
		this.history = [];
		this.wins=new jf.util.Map();
	},
	// 首页分发跳转
	route : function(reqData) {
		var me = this;
		//alert(JSON.stringify(reqData));
		this.reqData = reqData;
		if (!JF.isNull(reqData.weixinShare)) {
			this.weixinShare = reqData.weixinShare;
		}
		var param = {};
		param.shopid = reqData.shopid;
		// 获取门店信息
		getShop(param, function(data) {
			// 加载成功后处理后续
			if (JF.isValid(reqData.backUrl)) {
				me.loadHis(0,reqData,{});
				return;
			}
			if (!JF.isValid(reqData.win)) {
				reqData.win = "locationCard";// 默认选中第一个选项卡
			}
			if (JF.isValid(reqData.box)) {
				me.open(reqData);
			} else {
				me.openWin({
					name : reqData.win,
					animate : false,
					data : reqData
				});
			}

		}, function(data) {
			new jf.ui.Toast({
				text : "查无此店",
				s : 2000
			}).show();
		});
	},
	getWin:function(name){
		return this.wins.get(name);
	},
	loadHis : function(i, reqData,obj) {
		var me = this;
		var arr = reqData.backUrl.split("$");
		var one = arr[i];
		 
		if (JF.isValid(one)) {
			var bus = one.split("@");
			reqData.win = bus[0];
			reqData.box = bus[1];
			if (JF.isValid(reqData.box)) {
				me.open(reqData, function(jsServer) {
					obj.parent=jsServer;
					i++;
					me.loadHis(i, reqData,obj);
				});
			} else {
				if(i==0){
					reqData.weixinShare=true;
				}
				me.openWin({
					name : reqData.win,
					animate : true,
					parent : obj.parent,
					data : reqData
				}, function(jsServer) {
					obj.parent=null;
					i++;
					me.loadHis(i, reqData,obj);
				});
			}

		}
	},
	changeWinTitle : function(text) {
		$("title").text(text);
		var $iframe = $("<iframe class='hide'></iframe>");
		$iframe.on("load", function() {
			setTimeout(function() {
				$iframe.off("load").remove();
			}, 0);
		}).appendTo($('body'));
	},
	/***************************************************************************
	 * 打开页面（有父框架）
	 */
	open : function(reqData, callback) {
		var me = this;
		me.openWin({
			name : reqData.box,
			animate : false,
			data : reqData
		}, function(jsServer) {
			me.openWin({
				name : reqData.win,
				box : reqData.box,
				parent : jsServer,
				animate : false,
				data : reqData
			}, callback);
		});
	},
	/***************************************************************************
	 * 打开页面
	 * 
	 * @param param
	 * @param callback
	 * @returns
	 */
	openWin : function(param, callback) {
		var me = this;
		if (me.isLoad) {
			return;
		}
		me.isLoad = true;
		if (param.refresh!=true&&me.curPage == param.name) {
			// 如果是当前页面，则不刷新
			me.isLoad = false;
			return;
		}  
		var cfg = new jf.ui.Config();
		param.cfg = cfg[param.name];
		if (!JF.isValid(param.cfg)) {
			new jf.ui.Toast({
				text : "无此名称配置页面",
				s : 1000
			}).show();
			return;
		}
		new jf.ui.ClearToast();
		// 获取上一个frame
		var x = jf.os.frameHistory.size();
		if (x - 1 < 0) {
			x = 0;
		} else {
			x--;
		}
		this.preFrame = jf.os.frameHistory.get(x);

		if (JF.isValid(this.preFrame)) {
			// 销毁上一个页面的相关资源
			if (this.preFrame.jsServer.destory) {
				this.preFrame.jsServer.destory();
			}
			if (JF.isValid(this.preFrame.jsServer.scrollstop)) {
				this.preFrame.jsServer.scrollstop.myScroll.disable();
				this.preFrame.y = this.preFrame.jsServer.scrollstop.myScroll.y;
			} else {
				this.preFrame.y = 0;
			}
		}
		var box = "";
		var win = "";
		if (JF.isValid(param.parent)) {
			box = param.parent.targetWin.id;
		}
		win = param.name;
		var loading = new jf.ui.Loading({
			box : box,
			win : win
		});
		loading.showWin();

		param.cfg.dir ? true : param.cfg.dir = "js/";// 默认页面目录

		if (!JF.isValid(param.cfg.html)) {
			param.cfg.html = param.cfg.dir + param.name + ".html";// 默认查找同文件名的html资源
		}
		
		var js = "";
		js = param.cfg.dir + param.name + ".js";// 默认查找同文件名的js资源
		if (JF.isValid(param.cfg.js)) {
			param.cfg.js = param.cfg.js + "," + js;
		} else {
			param.cfg.js = js;
		}

		if (!JF.isValid(param.cfg.css)) {
			param.cfg.css = "";// 默认没有css资源
		}
		if (!JF.isValid(param.cfg.text)) {
			param.cfg.text = "";// 默认没有页面标题
		}
		!JF.isNull(param.cache) ? true : param.cache = true;// 默认需要缓存页面
		!JF.isNull(param.animate) ? true : param.animate = true;// 默认有动画
		param.data ? true : param.data = {};// 默认无参数

		// alert(JSON.stringify(this.history));
		this.history.push({
			win : win,
			box : null
		});
		$("body").find("input").blur();
		$("body").find("textarea").blur();
		// 异步加载css资源，不影响程序，如加载失败，只影响页面渲染
		JF.loaders({
			src : param.cfg.css.split(","),
			srcType : "css", 
		}, function() {
		});
		// 加载js资源
		JF.loaders({
			src : param.cfg.js.split(","),
			srcType : "js",
		}, function() {
			// JS资源加载完毕后，开始构建页面JS对象
			try {
				var obj = new window[param.name]();
				var jsServer = obj.jsServer;// 頁面對象
				me.wins.put(param.name,jsServer);
				jsServer.data = param.data;// 指向当前参数
				if (loader.weixinShare) {
					var value = loader.weixinShare;
					var flag = value ==="false" ? false : true;
					jsServer.data.weixinShare =new Boolean(flag);
					loader.weixinShare = false;
				}
				// 创建页面html层框架
				if (JF.isValid($('body').find("#" + param.name)[0])) {
					$('body').find("#" + param.name).remove();
				}
				jsServer.targetWin = new jf.ui.Win({
					container : $('body'),
					id : param.name
				});
				jsServer.targetWin.$.css("z-index", jf.os.zIndexCache++);

				// 初始化页面框架结构
				if (JF.isValid(jsServer.initWin)) {
					jsServer.initWin();
				} else {
					jsServer.initWin = function() {
						new jf.ui.Window({
							targetWin : jsServer.targetWin,
							hideHeader : jsServer.data.hideHeader,
							hideFooter : jsServer.data.hideFooter,
							hideBackBtn : jsServer.data.hideBackBtn,
						});
					};
					jsServer.initWin();
				} 
				if(JF.isValid(param.data.bg)){
					//设置窗口背景色
					jsServer.targetWin.$.css("background",param.data.bg);
					jsServer.targetWin.frame.$.css("background",param.data.bg);
				}
				jsServer.targetWin.$.show(); 
				// 因为有了父类框架，所以重新定位显示区域
				if (JF.isValid(param.parent)) {
					var winTop = param.parent.targetWin.$.css("top");
					var winH = param.parent.targetWin.$.height();
					var headerH = param.parent.targetWin.header.$.height();
					var footerH = param.parent.targetWin.footer.$.height();

					var _winH = winH;// 当前窗口的高度

					var top = 0;

					if (param.parent.targetWin.header.$.is(':visible')) {
						_winH = _winH - headerH;
						top = parseInt(winTop) + headerH;
					} else {
						top = parseInt(winTop);
					}
					if (param.parent.targetWin.footer.$.is(':visible')) {
						_winH = _winH - footerH+1;
					}

					jsServer.targetWin.$.css("height", _winH);

					var _headerH = jsServer.targetWin.header.$.height()
					var _footerH = jsServer.targetWin.footer.$.height()
					var _frameH = _winH;
					if (jsServer.targetWin.header.$.is(':visible')) {
						_frameH = _frameH - _headerH;
					}
					if (jsServer.targetWin.footer.$.is(':visible')) {
						_frameH = _frameH - _footerH;

					}

					jsServer.targetWin.$.css("top", top);
					setTimeout(function() {
						jsServer.targetWin.frame.$.height(_frameH - 1);
					});
					jsServer.parent = param.parent;
				}
				// 只获取本身元素的ID
				jsServer.$ = function(str) {
					str = str.replace(/@/g, param.name + "_");
					return jsServer.targetWin.$.find(str);
				};
				jsServer.$convert = function(str) {
					str = str.replace(/@/g, param.name + "_");
					return str;
				};
 
				// 刷新当前页面
				jsServer.targetWin.refresh = function() {
					param.refresh=true;
					param.animate=false;
					me.openWin(param);
				}
				// 关闭当前窗口
				jsServer.targetWin.close = function(animate, closeCallback) {
					new jf.ui.ClearToast();
					me.curPage = null;
					// 关闭当前层，历史记录清除
					var y = jf.os.frameHistory.size();
					if (y - 1 < 0) {
						y = 0;
					} else {
						y--;
					}
					var curFrame = jf.os.frameHistory.get(y);

//					if (jsServer.targetWin.id != curFrame.jsServer.targetWin.id) {
//						new jf.ui.Toast({
//							text : "请先关闭父窗口"
//						}).show();
//						return;
//					}
					if (JF.isValid(curFrame)) {
						if (JF.isValid(curFrame.preFrame)) {
							curFrame.preFrame.jsServer.jssdk();
							curFrame.preFrame.jsServer.active();
							me.changeWinTitle(curFrame.preFrame.param.cfg.text);
							curFrame.preFrame.jsServer.scrollstop.myScroll.enable();
							curFrame.preFrame.jsServer.scrollstop.myScroll.scrollTo(0, curFrame.preFrame.y);// 初始位置
						} else {
							me.changeWinTitle("");
						}
						jf.os.frameHistory.remove(y);
					}
					if (jsServer.destory) {
						jsServer.destory();
					}
					if (animate != false && param.direction != "slideDown" && param.direction != "slideUp") {
						jsServer.targetWin.$.animate({
							left : jsServer.targetWin.$.width()
						}, 300, function() {
							jsServer.targetWin.$.hide();
							if (closeCallback)
								closeCallback(jsServer);
						});
					} else if (animate != false && param.direction == "slideDown") {
						jsServer.targetWin.$.animate({
							top : jsServer.targetWin.$.height()
						}, 300, function() {
							jsServer.targetWin.$.hide();
							if (closeCallback)
								closeCallback(jsServer);
						});
					} else if (animate != false && param.direction == "slideUp") {
						jsServer.targetWin.$.animate({
							top : -jsServer.targetWin.$.height()
						}, 300, function() {
							jsServer.targetWin.$.hide();
							if (closeCallback)
								closeCallback(jsServer);
						});
					} else {
						jsServer.targetWin.$.hide();
						if (closeCallback)
							closeCallback(jsServer);
					}
				}
				// 开始加载页面初始化方法
				function initLoadPage(loadEndCallback) {
					function jump(html) {
						// 相同页面不再加入历史数据中
						jf.os.frameHistory.each(function(i) {
							if (this.param.name == param.name) {
								jf.os.frameHistory.remove(i);
								return false;
							}
						});
						jf.os.frameHistory.add({
							jsServer : jsServer,
							preFrame : me.preFrame,
							param : param
						});
						// 替换页面元素ID
						html = html.replace(/@/g, param.name + "_");
						var reg = /{{(.*?)}}/g;
						html = html.replace(reg, "<font jf-text='$1'></font>");

						jsServer.targetWin.frame.$.html(html);// 加载页面内容
						me.curPage = param.name;// 设置当前页标签
						
						if (jsServer.loadBefore) {
							//加载loadPage和界面解析之前执行
							jsServer.loadBefore(param.data);
						}
						me.watch(jsServer);// 绑定指定属性
						if (jsServer.loadPage) {
							jsServer.targetWin.showTopButton(jsServer);
							// 加载页面loadPage方法
							jsServer.loadPage(param.data);

							// 每次页面激活的时候都会触发，包括新打开、关闭上层页面
							if (!JF.isValid(jsServer.active)) {
								jsServer.active = function() {
								};
							}
							jsServer.active();
							// 页面注册事件
							if (!JF.isValid(jsServer.jssdk)) {
								jsServer.jssdk = function() {
									var me = this;
									var shop = {};
									if (JF.isValid(jf.os.session.get("shopData"))) {
										shop = jf.os.session.get("shopData");
									}
									var linkUrl = url + 'oauth2/oauth/?shopid=' + shop.id + "&win=" + param.name + "&weixinShare=true";
									if (JF.isValid(param.parent)) {
										linkUrl = linkUrl + "&box=" + param.parent.targetWin.id;
									}
									var wx = {
										shopid : shop.id,
										title : param.cfg.text,
										desc : shop.name,
										link : linkUrl,
										imgUrl : url + shop.headPic
									};
									// alert(JSON.stringify(wx));
									//registerWX(wx);
								};
							}
							jsServer.jssdk();
							
							//属于弹出层，则透明背景
							if(param.pop==true){
								jsServer.targetWin.$.css("background","transparent");
								jsServer.targetWin.frame.$.css("background","transparent"); 
								jsServer.targetWin.$.addClass("black-bgcolor");
								$(jsServer.targetWin.frame.$.children()[0]).addClass("black-bgcolor");
							}
							
							jsServer.targetWin.frame.$.scrollTop(0);
						 
						} else {
							new jf.ui.Toast({
								text : "缺少loadPage方法",
								width : "50%"
							}).show();
						}
						loading.hide();// 加载完毕后因此加载条

						if (loadEndCallback) {
							// 打开窗口完成后触发的回调函数
							loadEndCallback(jsServer); 
						}
					}
					// 先判断是否需要从缓存中获取页面信息
					var pageCache = jf.os.pageCache.get(param.name);
					if (param.cache && pageCache) {
						jump(pageCache);
						return;
					}

					// 加载HTML页面
					request({
						"url" : param.cfg.html,
						"cache" : param.cache,
						"dataType" : "html",
						"async" : false,
						"method" : "POST",
						"success" : function(rs) {
							// alert("响应数据：" + JSON.stringify(rs));
							jf.os.pageCache.put(param.name, rs);
							jump(rs);
						},
						"error" : function(rs) {
							// 加载默认HTML页面
							jump('<div class="content-padded"><ul></ul></div>');
						}
					});
				}

				// 判断如何显示页面窗口
				if (param.animate && param.direction != "slideDown" && param.direction != "slideUp") {
					// 窗口从右到左显示出来
					jsServer.targetWin.$.css("left", jsServer.targetWin.$.width() + "px");
					jsServer.targetWin.$.animate({
						left : "-0px"
					}, 300, function() {
						me.isLoad = false;
						initLoadPage(callback);
					});
				} else if (param.animate && param.direction == "slideDown") {
					// 窗口从下到上显示出来
					jsServer.targetWin.$.css("left", "-0px");
					jsServer.targetWin.$.css("top", jsServer.targetWin.$.height() + "px");
					jsServer.targetWin.$.animate({
						top : "0px"
					}, 300, function() {
						me.isLoad = false;
						initLoadPage(callback);
					});
				} else if (param.animate && param.direction == "slideUp") {
					// 窗口从上到下显示出来
					jsServer.targetWin.$.css("left", "-0px");
					jsServer.targetWin.$.css("top", -jsServer.targetWin.$.height() + "px");
					jsServer.targetWin.$.animate({
						top : "0px"
					}, 300, function() {
						me.isLoad = false;
						initLoadPage(callback);
					});
				} else {
					// 直接显示，无动画
					jsServer.targetWin.$.css("left", "-0px");
					me.isLoad = false;
					initLoadPage(callback);
				}

			} catch (e) {
				new jf.ui.Toast({
					text : e.message,
					width : "50%"
				}).show();
				throw e;
			} finally {
				me.isLoad = false;
				me.changeWinTitle(param.cfg.text);
			}

		});

	},
	/***************************************************************************
	 * 绑定页面属性
	 * 
	 * @param param
	 *            （animate、winName）
	 */
	watch : function(jsServer) {
		var me = this;
		if (!JF.isValid(jsServer.watch)) {
			jsServer.watch = {};
		}
		var box = jsServer.targetWin.frame.$;
		me.parserAllDom(jsServer, jsServer.watch, box, "", jsServer.watch, new Date().getTime(), box);

	},
	parserAllDom : function(jsServer, target, $parent, context, contextData, times, FOR) {
		var me = this;
		var rs = me.parserOneDom(jsServer, target, $parent, context, contextData, times, true, FOR);

		if (rs == true) {
			var children = $parent.children();
			children.each(function() {
				var el = $(this);
				me.parserAllDom(jsServer, target, el, context, contextData, times, FOR);
			});
		}
	},
	parserOneDom : function(jsServer, target, el, context, contextData, times, findUp, FOR) {
		var me = this;
		if (!JF.isValid(el[0])) {
			return;
		}
		// console.log(target);
		// console.log(el.prop("tagName") + "====" + el.attr("class"));
		// //////////////////////////////////////////////////
		var valueTagAttr = $.trim(el.attr("jf-value"));
		var textTagAttr = $.trim(el.attr("jf-text"));
		var classTagAttr = $.trim(el.attr("jf-class"));
		var styleTagAttr = $.trim(el.attr("jf-style"));
		var forTagAttr = $.trim(el.attr("jf-for"));
		var renderTagAttr = $.trim(el.attr("jf-render"));
		var urlTagAttr = $.trim(el.attr("jf-url"));
		var clickTagAttr = $.trim(el.attr("jf-click"));
		var ifTagAttr = $.trim(el.attr("jf-if"));
		var elseifTagAttr = $.trim(el.attr("jf-elseif"));
		var elseTagAttr = $.trim(el.attr("jf-else"));

		var objectTagAttr = $.trim(el.attr("jf-object"));

		// 解析通用規則的标签
		$(el[0].attributes).each(function() {
			var node = this;
			var name = this.name;
			var odlValue = this.nodeValue;
			var nodeValue = this.nodeValue;
			var s = name.indexOf("jf-");
			if (s == 0 && name != "jf-text" && name != "jf-object" && name != "jf-for" && name != "jf-render" && name != "jf-url" && name != "jf-click" && name != "jf-if" && name != "jf-elseif" && name != "jf-else") {
				var _attr = name.substring(3);
				me.parserTag({
					tagAttr : nodeValue,
					tagName : name,
					target : target,
					el : el,
					context : context,
					contextData : contextData,
					jsServer : jsServer,
					findUp : findUp,
					times : times,
					FOR : FOR,
					callback : function(value, key, tagAttr, tagName, target, el, context, contextData, times) {
						$(target["els" + tagName + JF.time][tagAttr]).each(function() {
							$(this).attr(_attr, value);
						});
					}
				});
			}
		});

		// ///////////条件标签/////////////
		var ifBodyFn = function(tagAttr) {
			// 执行
			var fn = jsServer.watch[tagAttr];
			if (!JF.isValid(fn)) {
				new jf.ui.Toast({
					text : "条件方法<br/>" + tagAttr + "<br/>方法不存在",
					s : 10000
				}).show();
			}
			var rs = fn.apply(jsServer, [ contextData, el ]);

			if (rs != true && !el.attr("ok")) {
				el.attr("ok", "ok");
				el.hide();
			} else if (rs == true && !el.attr("ok")) {
				el.attr("ok", "ok");
				el.show();
			}

			// 判断之后的条件是否执行
			var exp = null;
			var next = el.next();
			if (JF.isValid(next[0])) {
				exp = next.attr("jf-elseif");
				if (JF.isNull(exp)) {
					exp = next.attr("jf-else");
				}
				if (!JF.isNull(exp)) {
					if (rs == true) {
						next.attr("excute", "false");
					} else if (rs == false) {
						next.attr("excute", "true");
					}
				}
			}
			return rs;
		}
		if (JF.hasAttr(el, "jf-if")) {
			return ifBodyFn(ifTagAttr);
		}
		// ///////////条件标签/////////////
		if (JF.hasAttr(el, "jf-elseif")) {
			var excute = $.trim(el.attr("excute"));
			if (excute == "true") {
				return ifBodyFn(elseifTagAttr);
			} else {
				el.attr("ok", "ok");
				el.hide();
				return false;
			}
		}
		// ///////////条件标签/////////////
		if (JF.hasAttr(el, "jf-else")) {
			var excute = $.trim(el.attr("excute"));
			if (excute == "true") {
				var fn = jsServer.watch[elseTagAttr];
				if (!JF.isValid(fn)) {
					fn = function() {
						return true;
					}
				}
				var rs = fn.apply(jsServer, [ contextData, el ]);
				if (rs != true && !el.attr("ok")) {
					el.attr("ok", "ok");
					el.hide();
				} else if (rs == true && !el.attr("ok")) {
					el.attr("ok", "ok");
					setTimeout(function() {
						el.show();
					}, 0);
				}
				return rs;
			} else {
				el.attr("ok", "ok");
				el.hide();
				return false;
			}
		}
		// ///////////点击事件标签/////////////
		if (JF.hasAttr(el, "jf-click")) {
			if (!JF.isValid(el.attr("ok"))) {
				el.attr("ok", "ok");
				tap(el, function() {
					var fn = jsServer.watch[clickTagAttr];
					if (!JF.isValid(fn)) {
						new jf.ui.Toast({
							text : "事件方法<br/>" + clickTagAttr + "<br/>方法不存在",
							s : 10000
						}).show();
					}
					var rs = fn.apply(jsServer, [ contextData, el ]);
				},true);
			}
		}
		// ///////////渲染标签/////////////
		if (JF.hasAttr(el, "jf-render")) {
			if (!JF.isValid(el.attr("renderok"))) {
				el.attr("renderok", "renderok");
				var fn = jsServer.watch[renderTagAttr];

				if (!JF.isValid(fn)) {
					new jf.ui.Toast({
						text : "渲染方法<br/>" + renderTagAttr + "<br/>方法不存在",
						s : 10000
					}).show();
				}

				var rs = fn.apply(jsServer, [ contextData, el ]);
			}
		}
		// ///////////跳转标签/////////////
		if (JF.isValid(urlTagAttr)) {
			if (!JF.isValid(el.attr("winok"))) {
				el.attr("winok", "winok");
				tap(el, function() {
					var rs = urlTagAttr.split("?");
					var win = rs[0];
					if (new jf.ui.Config()[win]) {
						var data = {};
						if (rs.length == 2) {
							var params = rs[1].split("&");
							$(params).each(function() {
								var r = this.split("=");
								data[r[0]] = r[1];
							});
						}
						loader.openWin({
							name : win,
							data : data
						});
					} else {
						window.location.replace(urlTagAttr);
					}
				},true);
			}
		}
		// ///////////对象标签/////////////
		if (JF.isValid(objectTagAttr)) {
			me.parserTag({
				alias : objectTagAttr,
				tagAttr : objectTagAttr,
				tagName : "jf-object",
				target : target,
				el : el,
				context : context,
				contextData : contextData,
				jsServer : jsServer,
				findUp : findUp,
				times : times,
				FOR : FOR,
				before : function(value, key, tagAttr, tagName, target, el, context, contextData, times) {
					var html = el.html();
					el.data("html", html);
					el.html("");
				},
				callback : function(value, key, tagAttr, tagName, target, el, context, contextData, times, alias) {
					var jsServer = this;
					$(target["els" + tagName + JF.time][tagAttr]).each(function() {
						var elTemp = $(this);
						var _alias = elTemp.data("alias");
						var row = $(elTemp.data("html"));
						elTemp.html("");
						me.parserAllDom(jsServer, value, row, _alias, value, new Date().getTime(), elTemp);
						elTemp.append(row);
					});
				},
			});
		}
		// ///////////循环标签/////////////
		if (JF.isValid(forTagAttr)) {
			var exps = forTagAttr.split(" ");
			me.parserTag({
				alias : exps[0],
				tagAttr : exps[2],
				tagName : "jf-for",
				target : target,
				el : el,
				context : context,
				contextData : contextData,
				jsServer : jsServer,
				findUp : findUp,
				times : times,
				FOR : FOR,
				before : function(value, key, tagAttr, tagName, target, el, context, contextData, times) {
					var html = el.html();
					el.data("html", html);
					el.html("");
				},
				callback : function(value, key, tagAttr, tagName, target, el, context, contextData, times, alias) {
					var jsServer = this;
					$(target["els" + tagName + JF.time][tagAttr]).each(function() {
						var elTemp = $(this);
						// elTemp.html("");
						var _alias = elTemp.data("alias");
						$(value).each(function(i) {
							var row = $(elTemp.data("html"));
							elTemp.append(row);
							this["parent"] = {
								context : context,
								target : target,
								list : value,
								index : i
							};
							this.i = i;
							me.parserAllDom(jsServer, this, row, _alias, this, new Date().getTime(), elTemp);
						});
					});
				},
			});
		}

		// ///////////文本标签/////////////
		me.parserTag({
			tagAttr : textTagAttr,
			tagName : "jf-text",
			target : target,
			el : el,
			context : context,
			contextData : contextData,
			jsServer : jsServer,
			findUp : findUp,
			times : times,
			FOR : FOR,
			callback : function(value, key, tagAttr, tagName, target, el, context, contextData, times) {
				$(target["els" + tagName + JF.time][tagAttr]).each(function() {
					$(this).html(value);
				});
			}
		});

		return true;
	},
	parserTag : function(param) {
		if (JF.isValid(param.tagAttr)) {

			var key = param.tagAttr;

			if (JF.isValid(param.context)) {
				key = param.tagAttr.replace(param.context + ".", "");
			}

			var elBox = param.target["els" + param.tagName + JF.time];
			if (JF.isNull(elBox)) {
				elBox = {};
			}
			param.target["els" + param.tagName + JF.time] = elBox;

			var myval = param.target[key];

			// 如果标签参数没有前缀，则是全局变量
			if (param.tagAttr == param.context) {
				// 证明是取本身作为值显示
				myval = param.contextData.toString();
			} else if (JF.isNull(myval) && param.tagAttr.indexOf(".") == -1 && param.findUp == true) {
				this.parserOneDom(param.jsServer, param.jsServer.watch, param.el, "", param.contextData, param.times, false, param.FOR);
				return;
			}
			// 从本身数据没有找到结果
			if (JF.isNull(myval) && param.findUp == true) {
				return;
			}

			if (key.indexOf(".") == -1) {
				if (JF.isNull(param.target["els" + param.tagName + JF.time][param.tagAttr])) {
					param.target["els" + param.tagName + JF.time][param.tagAttr] = [];
				}
				param.target["els" + param.tagName + JF.time][param.tagAttr].push(param.el);
			} else {
				return;
			}

			// console.log(param.target);
			// console.log(param.tagAttr + "(tagAttr)");
			// console.log(key + "(key)");
			// console.log(param.context + "(context)");
			// console.log(myval + "(myval)");
			// console.log("**************");
			param.el.data("context", param.context);
			param.el.data("tagAttr", param.tagAttr);
			param.el.data("alias", param.alias);
			param.el.data("target", param.target);
			param.el.data("value", myval);
			param.el.data("key", key);

			if (param.before) {
				param.before.apply(param.jsServer, [ myval, key, param.tagAttr, param.tagName, param.target, param.el, param.context, param.contextData, param.times, param.alias ]);
			}

			if (key.indexOf(".") == -1) {
				// 必须保证是有效变量名
				var keyValue;
				Object.defineProperty(param.target, key, {
					get : function() {
						return keyValue;
					},
					set : function(value) {
						if (param.callback)
							param.callback.apply(param.jsServer, [ value, key, param.tagAttr, param.tagName, param.target, param.el, param.context, param.contextData, param.times, param.alias ]);
						keyValue = value;
					},
					configurable : true,
					enumerable : true
				});
				param.target[key] = myval;
			}

			if (param.after) {
				param.after(param.jsServer, [ myval, key, param.tagAttr, param.tagName, param.target, param.el, param.context, param.contextData, param.times, param.alias ]);
			}
		}
	},
});