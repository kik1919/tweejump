function tap(el, fn, flag) {
	el.on("tap", function(e) {
		var isTap = el.attr("isTap");
		if (!JF.isValid(isTap) || isTap == "false" || flag == true) {
			el.attr("isTap", "true");
			fn.apply(this);
			setTimeout(function() {
				el.attr("isTap", "false");
			}, 1000);
		} else if (isTap == "true") {
			new jf.ui.BottomToast({ 
				text : "别太急"
			}).show();
		}
		return false;
	});
	return el;
}

/*******************************************************************************
 * 
 * 基本组件
 */
JF.define("jf.ui.Component", {
	Component : function(args) {
		!args.id ? this.id = JF.random() : this.id = args.id;// 组件id属性
		!args.name ? this.name = this.id : this.name = args.name;// 组件name属性
		!args.text ? this.text = "" : this.text = args.text;// 组件text属性
		this.width = args.width;// 组件宽度
		this.height = args.height;// 组件高度
		this.fontSize = args.fontSize;// 字体大小
		this.fontColor = args.fontColor;// 字体颜色
		this.bg = args.bg;// 背景颜色
		!args.className ? this.className = "" : this.className = args.className;// 样式
		args.isDrag == null ? this.isDrag = false : this.isDrag = args.isDrag;// 是否允许拖动
		!args.dragListener ? this.dragListener = function() {
		} : this.dragListener = args.dragListener;// 拖动事件
		!args.dragStartListener ? this.dragStartListener = function() {
		} : this.dragStartListener = args.dragStartListener;// 拖动开始事件
		!args.dragEndListener ? this.dragEndListener = function() {
		} : this.dragEndListener = args.dragEndListener;// 拖动结束事件
		args.isDragH == null ? this.isDragH = true : this.isDragH = args.isDragH;// 横向拖动
		args.isDragV == null ? this.isDragV = true : this.isDragV = args.isDragV;// 纵向拖动
		this.position = args.position;// 层级方式
		this.zIndex = args.zIndex;// 层级
		this.left = args.left;// 靠左横坐标
		this.right = args.right;// 靠右横坐标
		this.top = args.top;// 靠上纵坐标
		this.bottom = args.bottom;// 靠下纵坐标
		!args.listener ? this.listener = function() {
		} : this.listener = args.listener;// 事件
		!args.form ? this.form = [] : this.form = args.form;// 包含的HTML源代码，从某个自定义对象中提取
		this.container = args.container;// 如果指定了容器，则会优先添加到容器中
		this.parent = args.parent;// 父类
		this.$ = args.$;// 包装、美化后的JQUERY对象
		this.esseObject = null;// 直接操作的实际的JQUERY对象
		this.bindObject = null;// 设置绑定事件的对象

	},
	/***************************************************************************
	 * 绘制开始之前
	 */
	startDraw : function() {
	},
	/***************************************************************************
	 * 绘制结束之后
	 */
	endDraw : function() {
		// 添加子类
		var len = this.form.length;
		for (var i = 0; i < len; i++) {
			this.appendChild(this.form[i]);
		}
		// 添加到容器
		if (this.precontainer) {
			this.prepend(this.$, this.container);
		} else if (this.container) {
			this.append(this.$, this.container);
		}
		// 是否能拖动
		if (this.isDrag) {
			this.$.css("cursor", "move");
			this.drag();
		}

		// 样式
		this.$.addClass(this.className);

		// 定位
		this.$.css("position", this.position);
		this.$.css("zIndex", this.zIndex);
		this.site();
	},
	/***************************************************************************
	 * 绘制接口定义，直接子类实现
	 */
	draw : function() {
	},
	/***************************************************************************
	 * 建造界面模型
	 */
	build : function() {
		this.startDraw();
		this.draw();
		this.endDraw(); 
	},
	 
	/***
	 * 获取当前所在win
	 */
	_getWin:function(el){
		var p=el.parent();
		if(JF.isValid(p)){
			if(p.hasClass(jf.os.sequence)){
				return p.data("win");
			}else{
				return this._getWin(p);
			}
		}
	},
	
	/***
	 * 滚动到自己
	 */
	scrollToMe:function(){
		this.getWin();
		this.win.scrollstop.myScroll.refresh();
		this.win.scrollstop.myScroll.scrollToElement(this.$[0],200,0,-100);
	},
	/***
	 * 获取当前所在win
	 */
	getWin:function(el){
		var ee;
		if(JF.isValid(el)){
			ee=el;
		}else{
			ee=this.$;
		}
		if(JF.isValid(this.win)){ 
			this.page= this.win.frame.$.find(".content-padded"); 
			return this.win;
		}
		this.win=this._getWin(ee);
		if(JF.isValid(this.win)){
			this.page= this.win.frame.$.find(".content-padded"); 
		} 
		return this.win;
	},
	/***************************************************************************
	 * 定位组件坐标
	 */
	site : function(point, $el, type) {
		type == null ? type = "absolute" : type = type;
		$el == null ? $el = this.$ : $el = $el;
		point == null ? point = {
			left : this.left,
			right : this.right,
			top : this.top,
			bottom : this.bottom,
		} : point = point;

		if (point.left != null) {
			$el.css("position", type);
			$el.css("left", point.left);
		}
		if (point.right != null) {
			$el.css("position", type);
			$el.css("right", point.right);
		}
		if (point.top != null) {
			$el.css("position", type);
			$el.css("top", point.top);
		}
		if (point.bottom != null) {
			$el.css("position", type);
			$el.css("bottom", point.bottom);
		}
	},
	/***************************************************************************
	 * 添加组件【可以追加字符串】,初始化的时候使用
	 */
	appendChild : function(son, parent, site) {
		var conf = this.judgeAppendConfig(son, parent, site);
		if (conf.site == "append") {
			conf.parent.append(conf.son.$);
		} else if (conf.site == "prepend") {
			conf.parent.prepend(conf.son.$);
		}
		return this;
	},
	/***************************************************************************
	 * 判定添加子类各个参数的性质
	 */
	judgeAppendConfig : function(son, parent, site) {
		// 判断子类类型
		if (typeof son == "number" || typeof son == "string") {
			son = new jf.ui.Tag({
				$ : new jf.ui.Label({
					text : son
				}).$
			});
		} else if (!JF.isJF(son) && typeof son == "object") {
			son = new jf.ui.Tag({
				$ : son
			});
		}
		// 判断父类类型
		var p;
		var $parent;
		if (!parent) {
			$parent = this.$;
			p = this;
		} else if (JF.isJF(parent)) {
			$parent = parent.$;
			p = parent;
		} else {
			$parent = parent;
			p = new jf.ui.Tag({
				$ : $parent
			});
		}

		son.parent = p;// 指定父类

		// 判断添加方式
		if (!site) {
			site = "append";
		}
		return {
			son : son,
			parent : $parent,
			site : site
		}
	},
	/***************************************************************************
	 * 追加组件【可以追加字符串】
	 */
	append : function(son, parent, site) {
		var conf = this.judgeAppendConfig(son, parent, site);
		this.appendChild(son, parent, site);
		this.form.push(conf.son);
		return this;
	},
	appends : function(jfs, parent, site) {
		var len = jfs.length;
		for (var i = 0; i < len; i++) {
			this.append(jfs[i], parent, site);
		}
		return this;
	},
	/***************************************************************************
	 * 添加组件到首位【可以添加字符串】
	 */
	prepend : function(jf, parent) {
		this.append(jf, parent, "prepend");
		return this;
	},
	prepends : function(jfs, parent, site) {
		this.appends(jfs, parent, "prepend");
		return this;
	},
	/***************************************************************************
	 * 移除子元素
	 */
	remove : function(jf) {
		if (JF.isJF(jf)) {
			jf.$.remove();
		} else {
			return;
		}
		var size = this.form.length;
		for (var i = size - 1; i >= 0; i--) {
			var temp = this.form[i];
			if (JF.isJF(jf) && jf.id == temp.id) {
				this.form.splice(i, 1);
				return jf;
			}
		}
		return this;
	},

	/***************************************************************************
	 * 鼠标拖动移动
	 */
	drag : function($obj) {
		var thiz = this;
		$obj == null ? $obj = this.$ : $obj = $obj;
		var offset = $obj.position();
		var draging = false;

		var hammer = new Hammer($obj.get(0));
		hammer.on('panmove', function(e) {
			if (draging) {
				var soffset = thiz.container.scrollTop();
				var l = offset.left + e.deltaX;
				var t = offset.top + e.deltaY + soffset;
				// console.log(l + "==" + t);
				var maxL = thiz.container.width() - $obj.width();
				var maxT = thiz.container[0].scrollHeight - $obj.height();
				if (l < 0) {
					l = 0;
				}
				if (l > maxL) {
					l = maxL;
				}

				if (t < 0) {
					t = 0;
				}
				if (t > maxT) {
					t = maxT;
				}

				$obj.css("position", "absolute");
				if (thiz.isDragH) {
					$obj.css("left", l + "px");
				}
				if (thiz.isDragV) {
					$obj.css("top", t + "px");
				}
				thiz.event(thiz.dragListener, thiz, e, l, t);
				return false;
			}

		});

		hammer.on('panstart', function(e) {
			draging = true;
			offset = $obj.position();
		});

		hammer.on('panend', function(e) {
			draging = false;

		});

	},
	/***************************************************************************
	 * 设置或者获取属性值
	 */
	attr : function(key, val, $el) {
		if (!$el) {
			$el = this.esseObject;
		}
		if (val == null) {
			return $el.attr(key);
		} else {
			$el.attr(key, val);
		}
	},
	/***************************************************************************
	 * 设置或者获取样式值
	 */
	css : function(key, val, $el) {
		if (!$el) {
			$el = this.esseObject;
		}
		if (val == null) {
			return $el.css(key);
		} else {
			$el.css(key, val);
		}
	},
	/***************************************************************************
	 * 禁用/开启
	 * 
	 * @param val
	 */
	disabled : function(val) {
		if (val == true || val == null) {
			this.esseObject.attr("disabled", true);
		} else {
			this.esseObject.attr("disabled", false);
		}
	},
	/***************************************************************************
	 * 禁用/开启
	 * 
	 * @param val
	 */
	readonly : function(val) {
		if (val == true || val == null) {
			this.esseObject.attr("readonly", true);
		} else {
			this.esseObject.attr("readonly", false);
		}
	},
	/***************************************************************************
	 * 隐藏
	 */
	hide : function() {
		this.$.hide();
	},
	/***************************************************************************
	 * 显示
	 */
	show : function() {
		this.$.show();
	},

	/***************************************************************************
	 * 事件
	 */
	event : function(fn, args0, args1, args2, args3, args4, args5, args6, args7) {
		fn.apply(this, [ args0, args1, args2, args3, args4, args5, args6, args7 ]);
	},
	off : function(event, fn) {
		var thiz = this;
		this.bindObject.off(event, function(e) {
			thiz.event(fn, e);
		});
	},
	one : function(event, fn) {
		var thiz = this;
		this.bindObject.one(event, function(e) {
			thiz.event(fn, e);
		});
	},
	bind : function(event, fn) {
		var thiz = this;
		this.bindObject.bind(event, function(e) {
			thiz.event(fn, e);
		});
	},
	click : function(fn) {
		var thiz = this;
		this.bindObject.click(function(e) {
			thiz.event(fn, e);
		});
	},
	tap : function(fn) {
		var thiz = this;
		this.bindObject.on("tap", function(e) {
			thiz.event(fn, e);
			return false;
		});
	},
	change : function(fn) {
		var thiz = this;
		this.bindObject.change(function(e) {
			thiz.event(fn, e);
		});
	},
	mouseup : function(fn) {
		var thiz = this;
		this.bindObject.on("vmouseup", function(e) {
			thiz.event(fn, e);
		});
	},
	mousedown : function(fn) {
		var thiz = this;
		this.bindObject.on("vmousedown", function(e) {
			thiz.event(fn, e);
		});
	},
	mouseover : function(fn) {
		var thiz = this;
		this.bindObject.on("vmouseover", function(e) {
			thiz.event(fn, e);
		});
	},
	mouseout : function(fn) {
		var thiz = this;
		this.bindObject.on("vmouseout", function(e) {
			thiz.event(fn, e);
		});
	},
	keydown : function(fn) {
		var thiz = this;
		this.bindObject.keydown(function(e) {
			thiz.event(fn, e);
		});
	},
	keyup : function(fn) {
		var thiz = this;
		this.bindObject.keyup(function(e) {
			thiz.event(fn, e);
		});
	},
	blur : function(fn) {
		var thiz = this;
		this.bindObject.blur(function(e) {
			thiz.event(fn, e);
		});
	},
	focus : function(fn) {
		var thiz = this;
		this.bindObject.focus(function(e) {
			thiz.event(fn, e);
		});
	},
	keypress : function(fn) {
		var thiz = this;
		this.bindObject.keypress(function(e) {
			thiz.event(fn, e);
		});
	},
	scroll : function(fn) {
		var thiz = this;
		this.bindObject.scroll(function(e) {
			var left = thiz.$.scrollLeft();
			thiz.event(fn, e, left);
		});
	},
	hover : function(fn) {
		var thiz = this;
		this.bindObject.hover(function(e) {
			thiz.event(fn, e);
		});
	}
});

/*******************************************************************************
 * 把jquery界面元素对象包装成JF界面组件
 */
JF.define("jf.ui.Tag", {
	extend : jf.ui.Component,
	Tag : function(args) {
		this.build();
	},
	draw : function() {
		if (!this.$.attr("id")) {
			this.$.attr("id", this.id);
		}
		if (!this.$.attr("name")) {
			this.$.attr("name", this.name);
		}
		this.bindObject = this.$;
		this.esseObject = this.$;
	}
});

/*******************************************************************************
 * 浮动头部栏位（不占用位置，悬浮在元素上）
 */
JF.define("jf.ui.FloatHeader", {
	extend : jf.ui.Component,
	FloatHeader : function(args) { 
		this.targetWin = args.targetWin;  
		if(JF.isValid(this.container)){  
			this.container=args.container
		}else{
			this.container=this.targetWin.$;
		}
		this.leftChild = args.leftChild;
		this.centerChild = args.centerChild;
		this.rightChild = args.rightChild;
		this.leftHtml = args.leftHtml;
		this.centerHtml = args.centerHtml;
		this.rightHtml = args.rightHtml;
		!args.boxSite ? this.boxSite ="middle" : this.boxSite = args.boxSite;
		this.build();  
	},
	draw : function() {
		var me = this;
		var $header = $('<div>');
		$header.addClass("floatHeader parent w img-bgcolor p-center p-top"); 

		this.$leftBox = $('<div class="child2">');
		this.$leftBox.addClass(this.boxSite);
		this.$centerBox = $('<div class="child8">');
		this.$centerBox.addClass(this.boxSite);
		this.$rightBox = $('<div class="child2">'); 
		this.$rightBox.addClass(this.boxSite);
		
		$header.append(this.$leftBox).append(this.$centerBox).append(this.$rightBox);

		if(JF.isValid(this.leftChild)){
			this.appendChildToLeft(this.leftChild);  
		}
		if(JF.isValid(this.centerChild)){
			this.appendChildToCenter(this.centerChild);  
		}
		if(JF.isValid(this.rightChild)){
			this.appendChildToRight(this.rightChild);  
		}
		
		if(JF.isValid(this.leftHtml)){
			this.appendHtmlToLeft(this.leftHtml); 
		}
		if(JF.isValid(this.centerHtml)){
			this.appendHtmlToCenter(this.centerHtml); 
		}
		if(JF.isValid(this.rightHtml)){
			this.appendHtmlToRight(this.rightHtml); 
		}
		
		this.$ = $header;
		this.bindObject = $header;
		this.esseObject = $header;
	},  
	hideLeft:function(){
		this.$leftBox.hide();
	},
	hideCenter:function(){
		this.$centerBox.hide();
	},
	hideRight:function(){
		this.$rightBox.hide();
	},
	appendHtmlToLeft:function(el){
		this.$leftBox.append(el);  
	},  
	appendHtmlToCenter:function(el){
		this.$centerBox.append(el);  
	},  
	appendHtmlToRight:function(el){
		this.$rightBox.append(el);  
	},
	appendChildToLeft:function(child){
		this.$leftBox.append(child.$);  
	},  
	appendChildToCenter:function(child){
		this.$centerBox.append(child.$);  
	},  
	appendChildToRight:function(child){
		this.$rightBox.append(child.$);  
	}
});
/*******************************************************************************
 * 浮动返回头部栏位（不占用位置，悬浮在元素上）
 */
JF.define("jf.ui.FloatBackHeader", {
	extend : jf.ui.FloatHeader,
	FloatBackHeader : function(args) {  
		!args.icon ? this.icon ="iconfont icon-fanhui" : this.icon = args.icon;
		JF.isNull(args.isShowRightBtn)? this.isShowRightBtn =true : this.isShowRightBtn = args.isShowRightBtn; 
		!args.rightBtnIcon ? this.rightBtnIcon ="iconfont icon-loading" : this.rightBtnIcon = args.rightBtnIcon;
		this.rightBtnListener=args.rightBtnListener;
		this.backBtnClassName=args.backBtnClassName;
		this.floatBackHeaderDraw();  
	},
	floatBackHeaderDraw : function() {
		var me = this;
		  
		var $backIcon = $('<span>');  
		$backIcon.addClass(this.icon);
		$backIcon.addClass("strong icon-h5 middle");
		
		var $backIconDiv = $('<div>');
		$backIconDiv.addClass("w-color border9 circle");
		if(JF.isValid(this.backBtnClassName)){
			$backIconDiv.addClass(this.backBtnClassName);
		}else{
			$backIconDiv.addClass("black-bgcolor");
		}
		$backIconDiv.css("width","32px");
		$backIconDiv.css("height","32px"); 
		
		$backIconDiv.addClass("list-view margin3");	 
		$backIconDiv.append($backIcon);
		
		tap($backIconDiv,function(){ 
			me.targetWin.close();
		});
		this.$leftBox.append($backIconDiv);  
		
		if(this.isShowRightBtn){
			var $homeIcon = $('<span>');  
			$homeIcon.addClass(this.rightBtnIcon);
			$homeIcon.addClass("list-view strong icon-h5 middle");
			if(isiOS){ 
				$homeIcon.css("left","2px");
			}
			var $homeIconDiv = $('<div>');
			$homeIconDiv.addClass("w-color border9 circle");
			if(JF.isValid(this.backBtnClassName)){
				$homeIconDiv.addClass(this.backBtnClassName);
			}else{
				$homeIconDiv.addClass("black-bgcolor");
			}
			$homeIconDiv.css("width","32px");
			$homeIconDiv.css("height","32px"); 
			
			$homeIconDiv.addClass("list-view margin3");	 
			$homeIconDiv.append($homeIcon);
			
			tap($homeIconDiv,function(){ 
				if(me.rightBtnListener){
					me.rightBtnListener.apply(me,[$(this)]);
				}else{
					refreshUser(curShopid);
					loader.openWin({
						name:"locationCard"
					});
				}
			});
			this.$rightBox.append($homeIconDiv); 
		}
		
	}, 
});
/*******************************************************************************
 * 头部导航栏
 */
JF.define("jf.ui.Header", {
	extend : jf.ui.Component,
	Header : function(args) {
		this.loader = new jf.util.Loader(); 
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg;
		!args.style ? this.style =1 : this.style = args.style;
		this.backBtnType = args.backBtnType;
		this.bg = args.bg;
		this.color = args.color;
		this.isShowAddBtn = false;
		this.targetWin = args.targetWin;
		this.targetFrame = this.targetWin.frame; 
		this.className = args.className;
		this.moreListener = args.moreListener;
		this.build();
		this.scroll();
		this.drag(); 

	},
	draw : function() {
		var me = this;
		var $header = $('<div>');
		$header.addClass("header main-header-bgcolor");
		$header.css("background", this.bg);

		var $box = $('<div>'); 
		if(this.style==0){
			$box.addClass("box");
			this.boxClass=".box";
		}else if(this.style==1){ 
			$box.addClass("box1");
			this.boxClass=".box1";
		} 
		$header.append($box);

		var $ul = $('<ul>');
 
		var w = 0;
		var cfgLen = this.args.cfg.length;
		for (var i = 0; i < cfgLen; i++) {
			var $li = $('<li>');
			$li.addClass("center"); 
			var c = me.args.cfg[i];   
			
			$ul.append($li);
			$li.data("fn", c.click); 
			if(JF.isNull(c.value)){
				c.value=c.text;
			} 
			$li.attr("value", c.value);
			$li.data("value", c.value);
			
			if (!JF.isValid(c.color)) {
				c.color = this.color;
			} 
			var $a = $("<a>"); 
			$a.css('color', c.color);
			$a.addClass(c.className); 
			if(this.style==0){
				$a.addClass("main-header-color"); 
			}else if(this.style==1){ 
				 
			}
			
			$a.html(c.text);
			$a.data("text", c.text);
			$li.append($a);
			tap($a, function() {
				var tab = $(this); 
				tab.parent().data("fn").apply(me, [ tab.parent().data("value"),tab ]); 
				me.selectTabMenu(tab.parent()); 
			},c.isTap);
			
			var $icon = $("<i>");
			$icon.addClass(c.iconfont);
			$icon.addClass("btnIcon");
			$a.prepend($icon);
			
			var $line = $("<div>");
			$line.addClass("line");  
			$a.append($line);
 
			var $numSpan = $("<div>");
			$numSpan.addClass('numDiv');
			$numSpan.html(0);
			$numSpan.hide();
			$a.append($numSpan); 
		}
		
		var $more = $('<div>');
		$more.addClass("more main-header-bgcolor");
		var $moreIcon = $('<i>');
		$moreIcon.addClass("main-header-bgcolor h1 strong iconfont icon-xiayiyeqianjinchakangengduo");
		$more.append($moreIcon);
		tap($more, function() {
			// 菜单末尾
			var offset=$ul.outerWidth()-$box.outerWidth(); 
			me.scrollstop.myScroll.scrollBy(-offset, 0);// 初始位置
			$moreIcon.removeClass("icon-xiayiyeqianjinchakangengduo");
			$moreIcon.addClass("icon-gengduo-hengxiang");
			$more.unbind("tap");
			tap($more, function() {
				// 更多菜单
				if(me.moreListener)
					me.moreListener.apply(me);
			},true);
		},true);
		$header.append($more); 
		
		$box.append($ul); 
		if(cfgLen==0){
			$more.hide();
		}else if(this.style==0){
			$more.show();
		}else if(this.style==1){ 
			$more.hide();
		}  
		if(this.style==0&&this.backBtnType=="0"){    
			// 返回按钮
			this.floatBackHeader=new jf.ui.FloatBackHeader({
				targetWin : this.targetWin,   
				container : $header,
			});
			$more.hide();
		}else if(this.style==0&&this.backBtnType=="1"){   
			// 关闭按钮
			this.floatBackHeader=new jf.ui.FloatBackHeader({
				targetWin : this.targetWin,  
				container : $header,
				icon:"iconfont icon-cuowuguanbiquxiao"
			});
			$more.hide();
		}
		 
		this.$ = $header;
		this.bindObject = $header;
		this.esseObject = $header;
	}, 
	drag : function() {
		var me = this;
		me.scrollstop = new jf.ui.Scrollstop({
			target : this.$.find(this.boxClass)
		}); 
	}, 
	getMenu:function(i){
		if(typeof i=="number"){ 
			return $(this.$.find("li")[i]) ;
		}else if(typeof i=="string"){
			return $(this.$.find("li[value="+i+"]"));
		}else if(typeof i=="object"){
			return i;
		}
	},
	hideMenu : function(i) {
		this.getMenu(i).hide(); 
	},
	showMenu : function(i) {
		this.getMenu(i).show(); 
	},
	selectTabMenu : function(i) {
		this.$.find("li a").removeClass("on");
		var li=this.getMenu(i)
		var on = $(li.find("a"));
		on.addClass("on"); 
		this.$.find("i").removeClass("main-header-color");
		li.find("i").addClass("main-header-color");  
	}, 
	selectNone : function(i) { 
		this.$.find("li a").removeClass("on");
		this.$.find("i").removeClass("main-header-color");
		 
	},
	setTextAlign:function(i,site){
		var item = this.getMenu(i);
		item.find("a").css("text-align", site);
	},
	setText : function(i, text) {
		var on = this.getMenu(i).find("a");
		on.html(text);
	},
	setMenuNum : function(i, num, append) {
		var item = this.getMenu(i);
		var $numSpan = item.find(".numDiv");
		$numSpan.show(); 
		var hadNum = $numSpan.html(); 
		if (append == true) {
			num = parseInt(hadNum) + num;
			$numSpan.html(num);
		} else if (append == false) {
			num = parseInt(hadNum) - num;
		} 
		if (num <= 0) {
			$numSpan.html(0);
			$numSpan.hide();
		} else {
			if(num>99){
				num="9•";
			}
			$numSpan.html(num);
			$numSpan.show();
		} 
	},
});

/*******************************************************************************
 * frame窗口html
 */
JF.define("jf.ui.Frame", {
	extend : jf.ui.Component,
	Frame : function(args) {
		this.build();
	},
	draw : function() {
		var me = this;
		var $div = $('<div>');
		$div.addClass("frame");

		this.$ = $div;
		this.bindObject = $div;
		this.esseObject = $div;
	},
});
 

/*******************************************************************************
 * 底部工具栏
 */
JF.define("jf.ui.Footer", {
	extend : jf.ui.Component,
	Footer : function(args) {
		this.targetWin = args.targetWin;
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg;
		!args.showAll ? this.showAll = true : this.showAll = args.showAll; 
		this.build();
	},
	draw : function() {
		var me = this;
		var $footer = $('<div>');
		$footer.addClass("footer");

		var add = function(cfg) { 
			var c = cfg; 
			var $btn = $('<div>');
			$btn.addClass("footer-btn");
			$btn.css("color",c.color);
			if (!this.showAll) {
				$btn.hide();
			}

			if (c.show == true || c.show == null) {
				$btn.show();
			} else {
				$btn.hide();
			}

			var $btnIcon = $('<span>');
			$btnIcon.addClass(c.iconfont);
			$btnIcon.addClass("btnIcon strong");
			$btnIcon.attr('classBak', c.iconfont);

			var $numSpan = $("<div>");
			$numSpan.addClass('numDiv');
			$numSpan.html(0);
			$numSpan.hide();
			$btnIcon.append($numSpan);

			$btn.append($btnIcon);
			$btn.data("click", c.click);
			$btn.data("value", c.value);
			$btn.attr("value", c.value);
			tap($btn, function() {
				$(this).data("click").apply(me,[$(this).data("value"),$btn]); 
				me.selectTabMenu($(this));
			}, c.isTap);

			var $btnText = $("<span>");
			$btnText.addClass('btnText');
			$btnText.html(c.text);
			$btn.append($btnText); 
			$footer.append($btn);
		}

		var cfgLen = this.cfg.length;
		for (var i = 0; i < cfgLen; i++) {
			add(me.cfg[i]);
		}
		this.$ = $footer;
		this.bindObject = $footer;
		this.esseObject = $footer;
	},
	hideMenu : function(i) {
		$(this.$.find(".footer-btn")[i]).hide();
	},
	showMenu : function(i) {
		$(this.$.find(".footer-btn")[i]).show();
	}, 
	getMenu:function(i){ 
		if(typeof i=="number"){ 
			return $(this.$.find(".footer-btn")[i]) ;
		}else if(typeof i=="string"){
			return $(this.$.find(".footer-btn[value="+i+"]"));
		}else if(typeof i=="object"){
			return i;
		}
	}, 
	selectTabMenu : function(i) { 
		var item=this.getMenu(i); 
		this.$.find(".btnIcon").removeClass('on');
		this.$.find(".btnText").removeClass('on'); 
		item.find(".btnIcon").addClass('on'); 
		item.find(".btnText").addClass('on');   
	},  
	setMenuNum : function(i, num, append) {
		var item = $(this.$.find(".footer-btn")[i]).find(".btnIcon");
		var $numSpan = item.find(".numDiv");
		$numSpan.show();

		var hadNum = $numSpan.html();

		if (append == true) {
			num = parseInt(hadNum) + num;
			$numSpan.html(num);
		} else if (append == false) {
			num = parseInt(hadNum) - num;
		}

		if (num <= 0) {
			$numSpan.html(0);
			$numSpan.hide();
		} else {
			$numSpan.html(num);
			$numSpan.show();
		}

	}, 
});
/*******************************************************************************
 * 表格
 */
JF.define("jf.ui.Grid", {
	extend : jf.ui.Component,
	Grid : function(args) {
		this.forBodyEl = args.forBodyEl;
		this.scrollstop = args.scrollstop;  
		!args.limit ? this.limit = 12 : this.limit = args.limit;
		this.oldLimit=this.limit;
		this.order=args.order;
		!args.isLoad ? this.isLoad = false : this.isLoad = args.isLoad;
		!args.skip ? this.skip = 0 : this.skip = args.skip;
		this.success = args.success;
		this.fail = args.fail;
		this.error = args.error;  
		!args.url ? this.url = "" : this.url = args.url; 
		!args.reqData ? this.reqData = {} : this.reqData = args.reqData; 
		!args.config ? this.config = {} : this.config = args.config; 
		this.build();
	},
	draw : function() {
		var me = this; 	   
		$(this.scrollstop.target.children(0)[0]).css("padding-bottom","5px");
		this.forBodyEl.html("");
		this.load();
		this.$ = this.forBodyEl;
		this.bindObject = this.forBodyEl;
		this.esseObject = this.forBodyEl;
	}, 
	reload : function(param) { 
		if(!JF.isValid(param)){
			param={};
		}
		this.forBodyEl.html("");
		this.limit = this.oldLimit;
		this.skip = 0;  
		this.load();
		this.scrollstop.nomoretip.hide(); 
		this.scrollstop.myScroll.refresh();
		if(JF.isValid(param.scrollToElement)){
			this.scrollstop.myScroll.scrollToElement(param.scrollToElement[0], 600); 
		}else if(JF.isValid(param.scrollTo)){
			this.scrollstop.myScroll.scrollTo(0, scrollTo, 300); 
		}else{
			this.scrollstop.myScroll.scrollTo(0, 0, 300);// 置顶
		}
	},
	refresh : function() { 
		this.load(true);
	},
	load : function(param) {
		var me = this;  
		if(this.isLoad == true){
			return;
		}
		this.isLoad = true;
		if(!JF.isValid(param)){
			param={};
		}
		if (param.refresh) {
			this.forBodyEl.html("");
			this.limit = this.skip;
			this.skip = 0;
		}
	 
		me.reqData.start=this.skip;
		me.reqData.limit=this.limit;
		me.reqData.order=this.order;
		var loading=new jf.ui.Loading().show();
		request({
			"url" : this.url,
			"reqData" : me.reqData,
			"success" : function(rs) {
				loading.hide();
				me.isLoad = false;
				// alert("响应数据：" + JSON.stringify(rs));
				var db = rs.data;
				me.skip += db.length;
				if(me.success){
					me.success.apply(me,[db,rs])
				}  
				me.isShowPull(me.scrollstop,me.skip, rs.count,me.config);
			},
			"fail" : function(rs) { 
				loading.hide();
				me.isLoad = false;
				me.isShowPull(me.scrollstop,me.skip, 0,me.config);
				if (param.refresh) {
					new jf.ui.NoData({
						container : me.box,
						text : "没有数据"
					});
				} 
				
				if (me.skip == 0) {
					new jf.ui.NoData({
						container : me.forBodyEl,
						text : "没有数据"
					});
				}else{
					me.scrollstop.nomoretip.slideDown();
				}
				if(me.fail){
					me.fail.apply(me,[rs])
				}
			},
			"error" : function(XMLHttpRequest) {
				loading.hide();
				me.isLoad = false;
				if(me.error){
					me.error.apply(me,[XMLHttpRequest])
				}
			}
		});
	},
	/***************************************************************************
	 * 是否显示下拉更多
	 */
	isShowPull:function(scrollstop,skip,count,config){  		
		if(JF.isValid(config)&&JF.isValid(config.color)){ 
			scrollstop.pullDown.removeClass("w2-color");
			scrollstop.pullDown.addClass(config.color);
			
			scrollstop.pullUp.removeClass("w2-color");
			scrollstop.pullUp.addClass(config.color);
			
			scrollstop.moretip.removeClass("w2-color");
			scrollstop.moretip.addClass(config.color);
			
			scrollstop.nomoretip.removeClass("w2-color");
			scrollstop.nomoretip.addClass(config.color);
		}
		if(JF.isValid(config)&&JF.isValid(config.fontBorder)){ 
			scrollstop.pullDown.removeClass("white-font-border");
			scrollstop.pullDown.addClass(config.fontBorder);
			
			scrollstop.pullUp.removeClass("white-font-border");
			scrollstop.pullUp.addClass(config.fontBorder);
			
			scrollstop.moretip.removeClass("white-font-border");
			scrollstop.moretip.addClass(config.fontBorder);
			
			scrollstop.nomoretip.removeClass("white-font-border");
			scrollstop.nomoretip.addClass(config.fontBorder);
		}  
		//console.log(count +"======"+skip);
		if (count == skip||count==0) {
			scrollstop.moretip.hide();
			scrollstop.moretip.attr("show","false"); 
		}else{ 
			scrollstop.moretip.show();
			scrollstop.moretip.attr("show","true");
		} 	
	} 
});
/*******************************************************************************
 * 滚动条控件
 */
JF.define("jf.ui.Scrollstop", {
	Scrollstop : function(args) {
		var me = this;
		this.pullTag=null;// up：上拉刷新；down：下拉加载更多
		this.target = args.target; 
		this.pullDownListener = args.pullDownListener;
		this.pullUpListener = args.pullUpListener;
		this.scrollListener = args.scrollListener;
		this.scrollEndListener = args.scrollEndListener;
		this.scrollUpListener = args.scrollUpListener;
		this.scrollDownListener = args.scrollDownListener;
		this.hidePullText = args.hidePullText;
		var isLoad = false;
		var loadTimeout = null;
		this.curY = 0;
		
		this.pullDown=$('<p class="hide center margin3 marginline h2 w2-color white-font-border iconfont icon-loading"> 释放刷新</p>');
		this.pullUp=$('<p class="hide center margin3 marginline h2 w2-color white-font-border iconfont icon-loading"> 释放加载更多</p>');
		this.moretip=$('<p class="hide center margin3 marginline h2 w2-color white-font-border iconfont icon-shangla"> 上拉加载数据</p>');
		this.nomoretip=$('<p class="hide center margin3 marginline h2 w2-color white-font-border">无更多数据</p>');
	 
		if(this.hidePullText!=true){
			this.target.children(":first").prepend(this.pullDown).append(this.pullUp).append(this.moretip).append(this.nomoretip);	
		}
		
		this.myScroll = new IScroll(this.target[0], {
			probeType : 2,
			disablePointer: true,
			disableTouch:false,
			disableMouse:false,
			fadeScrollbars:false,
			scrollX:true,
		});
		
		this.myScroll.on('beforeScrollStart', function() {
			me.myScroll.refresh(); 
			new jf.ui.ClearToast(); 
		});
		this.myScroll.on('scrollStart', function() {  
			me.curY = this.y;
		});
		this.myScroll.on("scroll", function() {

			$("body").find(".numberKeyboard").hide(); 
			$("body").find(".textbox").find("input").css("border","none");
			$("body").find("input").blur();
			$("body").find("textarea").blur(); 
			// console.log(this.y +"===scroll=="+ me.curY);
			if (this.y < (this.maxScrollY - 5)) {
                // 上拉刷新效果
				me.pullUp.slideDown();
				me.moretip.slideUp();
				me.pullTag="up";
            }else if (me.pullTag=="up"&&this.y > (this.maxScrollY - 5)) {
                // 取消上拉刷新效果
				me.pullUp.slideUp();
				me.pullTag=null;
				if(me.moretip.attr("show")=="true"){
					me.moretip.slideDown();
				}else{ 
					me.moretip.slideUp();
				}
            }else if (this.y >50) {
                // 下拉拉刷新效果
				me.pullDown.slideDown();
				me.moretip.slideUp();
				me.pullTag="down";
            }else if (me.pullTag=="down"&&this.y <50) {
                // 取消下拉拉刷新效果
				me.pullDown.slideUp();
				if(me.moretip.attr("show")=="true"){
					me.moretip.slideDown();
				}else{ 
					me.moretip.slideUp();
				}
				me.pullTag=null;
            }
			if (this.y - me.curY > 0) {
				// 向下滚动的时候监听
				if (me.scrollDownListener)
					me.scrollDownListener.apply(me,[this.y, this.maxScrollY, this.y - me.curY]);
			} else {
				// 向上滚动的时候监听
				if (me.scrollUpListener)
					me.scrollUpListener.apply(me,[this.y, this.maxScrollY, this.y - me.curY]);
			}
			// 滚动的时候监听
			if (me.scrollListener)
				me.scrollListener.apply(me,[this.y, this.maxScrollY]);
			
			$("body").find("input").blur();
			$("body").find("textarea").blur(); 
		});
		this.myScroll.on('scrollEnd', function() {
			// console.log(this.y + "==="+this.maxScrollY);
			// 滚动结束的时候监听
			if (me.scrollEndListener)
				me.scrollEndListener.apply(me,[this.y, this.maxScrollY]);
			if(me.pullTag=="up"){ 
				// 如果是上拉，则触发上拉加载更多事件
				me.pullUp.slideUp();
				if(me.pullUpListener){
					me.pullUpListener.apply(me,[this.y, this.maxScrollY]);
				} 
				
			}else if(me.pullTag=="down"){
				// 如果是下拉，则触发下拉刷新事件
				me.pullDown.slideUp();
				if(me.pullDownListener){
					me.pullDownListener.apply(me,[this.y, this.maxScrollY]);
				} 
			}
			me.pullTag=null;
			
			// 滚动的时候所有输入控件失去焦点
			$("body").find("input").blur();
			$("body").find("textarea").blur(); 
			
		});

	},
	unbind : function() {
		this.myScroll.destroy();
	}
});
/*******************************************************************************
 * 框架
 */
JF.define("jf.ui.Window", {
	extend : jf.ui.Component,
	Window : function(args) { 
		!args.hcfg ? this.hcfg = [] : this.hcfg = args.hcfg;
		!args.fcfg ? this.fcfg = [] : this.fcfg = args.fcfg;
		!args.home ? this.home = false : this.home = args.home;
		!args.headerStyle ? this.headerStyle = "0" : this.headerStyle = args.headerStyle;
		this.backBtnType = args.backBtnType;
		this.closeListener = args.closeListener;
		this.moreListener=args.moreListener;
		!args.hideHeader ? this.hideHeader = false : this.hideHeader = args.hideHeader;
		!args.hideFooter ? this.hideFooter = false : this.hideFooter = args.hideFooter;
		this.targetWin = args.targetWin;
		this.build();
	},
	draw : function() {
		var me = this; 
		// 头部工具栏
		if (this.home != true&&this.hcfg.length==0) {  
			this.hcfg = [ {
				iconfont : "",  
			} ]; 
			if(!JF.isValid(this.backBtnType)){ 
				this.backBtnType="0"
			}
		}else if(this.hcfg.length!=0){
			this.backBtnType=null;
		}
		this.targetWin.header = new jf.ui.Header({
			container : this.targetWin.$,
			targetWin : this.targetWin, 
			moreListener:this.moreListener,
			style:this.headerStyle,
			backBtnType:this.backBtnType, 
			cfg : this.hcfg
		});
		if (this.home == true&&this.back==false) { 
			this.targetWin.header.$.hide();
		}
		if (this.hideHeader == true) { 
			this.targetWin.header.$.hide();
		}
		// 内部frame窗口
		this.targetWin.frame = new jf.ui.Frame({
			container : this.targetWin.$,
		});
		// 底部工具栏
		this.targetWin.footer = new jf.ui.Footer({
			container : this.targetWin.$,
			targetWin : this.targetWin, 
			cfg : this.fcfg
		});
		if (this.hideFooter == true) {
			this.targetWin.footer.$.hide();
		} 
		if (this.fcfg.length == 0) {
			this.targetWin.footer.$.hide();
		}
		// 页面定位布局，延迟执行保证界面渲染完成后再定位
		setTimeout(function(){
			me.targetWin.rect = new jf.ui.Rect({
				targetWin : me.targetWin 
			}); 
		},0);
		
		// 返回顶部悬浮按钮
		this.targetWin.top = new jf.ui.TopButton({
			container : this.targetWin.$,
			targetFrame : this.targetWin.frame,
			isDrag : true
		});

		this.targetWin.isLoad = true;
		// 显示当前窗口top按钮
		this.targetWin.showTopButton = function(jsServer) {
			me.targetWin.top.$.hide(); 
			me.scrollstop = new jf.ui.Scrollstop({
				target : me.targetWin.frame.$,
				hidePullText:jsServer.hidePullText,
				scrollListener : function(y, maxY) { 
					// 滚动的时候监听
					if(jsServer.isScroll==false){  
						jsServer.scrollstop.myScroll.scrollTo(0, jsServer.scrollY, 300);
					}
					if (y < -300 && y < maxY / 3) {
						me.targetWin.top.$.fadeIn();
					} else if (y > -300) {
						me.targetWin.top.$.fadeOut();
					} else {
						me.targetWin.top.$.fadeOut();
					}
					if (jsServer.scrollListener) {
						jsServer.scrollListener.apply(jsServer, [ y, maxY ]);
					}
					me.targetWin.frame.$.scrollTop(0);
				},
				scrollUpListener : function(y, maxY, offset) {
					// 向上滚动的时候监听
					if(jsServer.isScroll==false){  
						jsServer.scrollstop.myScroll.scrollTo(0, jsServer.scrollY, 300);
					}
					if (jsServer.scrollUpListener) {
						jsServer.scrollUpListener.apply(jsServer, [ y, maxY, offset ]);
					}
					me.targetWin.frame.$.scrollTop(0);
				},
				scrollDownListener : function(y, maxY, offset) {
					// 向下滚动的时候监听
					if(jsServer.isScroll==false){  
						jsServer.scrollstop.myScroll.scrollTo(0, jsServer.scrollY, 300);
					}
					if (jsServer.scrollDownListener) {
						jsServer.scrollDownListener.apply(jsServer, [ y, maxY, offset ]);
					}
					me.targetWin.frame.$.scrollTop(0);
				},
				scrollEndListener : function(y, maxY) {
					// 滚动结束的时候监听
					if(jsServer.isScroll==false){  
						jsServer.scrollstop.myScroll.scrollTo(0, jsServer.scrollY, 300);
					}
					if (y < -300 && y < maxY / 3) {
						me.targetWin.top.$.fadeIn();
					} else if (y > -300) {
						me.targetWin.top.$.fadeOut();
					} else {
						me.targetWin.top.$.fadeOut();
					}
					if (jsServer.scrollEndListener) {
						jsServer.scrollEndListener.apply(jsServer, [ y, maxY ]);
					}
					me.targetWin.frame.$.scrollTop(0);
				},
				pullDownListener : function(y, maxY) {
					// 下拉刷新的时候监听
					if (jsServer.pullDownListener) {
						jsServer.pullDownListener.apply(jsServer, [ y, maxY ]);
					}
				},
				pullUpListener : function(y, maxY) {
					// 上拉加载的时候监听
					if (jsServer.pullUpListener) {
						jsServer.pullUpListener.apply(jsServer, [ y, maxY ]);
					}
				},
			});

			jsServer.scrollstop = me.scrollstop;
			jsServer.targetWin.scrollstop = me.scrollstop;
			
			jsServer.targetWin.$.data("jsServer",jsServer);
			jsServer.targetWin.$.data("win",jsServer.targetWin);
			 
			tap(me.targetWin.top.$, function() {
				me.scrollstop.myScroll.refresh();
				me.scrollstop.myScroll.scrollTo(0, 0, 300);// 置顶
			}, true);

		}

		this.$ = this.targetWin.$;
		this.bindObject = this.targetWin.$;
		this.esseObject = this.targetWin.$;
	}
});
/*******************************************************************************
 * 定位，计算frame窗口
 */
JF.define("jf.ui.Rect", {
	Rect : function(args) {
		this.body = $("body");
		this.targetWin = args.targetWin;
		this.targetFrame = this.targetWin.frame;
		this.footer =  this.targetWin.footer;
		this.header =  this.targetWin.header;
		this.draw();
	},
	draw : function() {
		var me = this;
		var winH = this.body.height();
		var headerH = this.header.$.height();
		var footerH = this.footer.$.height();
		var frameH = winH; 
		if (this.header.$.is(':visible')) {
			frameH = frameH - headerH;
		}   
		if (this.footer.$.is(':visible')) {
			frameH = frameH - footerH; 
		}
		this.targetFrame.$.height(frameH);
		jf.os.session.save({
			rect : {
				headerH : headerH,
				winH : winH,
				footerH : footerH,
				frameH : frameH
			}
		});

	},
});
/*******************************************************************************
 * 弹出提示
 */
JF.define("jf.ui.ClearToast", {
	extend : jf.ui.Component,
	ClearToast : function(args) { 
		var hadToast = $("body").find(".loading");
		if (!JF.isNull(hadToast[0])) {
			hadToast.remove();
		}
		
		hadToast = $("body").find(".toast");
		if (!JF.isNull(hadToast[0])) {
			if(hadToast.attr("noScrollHide")==0){
				hadToast.remove();
			} 
		}
		
		var hadBG = $("body").find(".BG");
		if (!JF.isNull(hadBG[0])) {
			hadBG.remove();
		} 
		
		var hadAlert =$("body").find(".aui-mask");
		if (!JF.isNull(hadAlert[0])) {
			hadAlert.remove();
		}
		
		var hadBottomToast =$("body").find(".bottom-toast");
		if (!JF.isNull(hadBottomToast[0])) {
			hadBottomToast.remove();
		} 
		
		var hadTip =$("body").find(".tip");
		if (!JF.isNull(hadTip[0])) {
			hadTip.remove();
		} 
	},
});
/*******************************************************************************
 * 弹出提示
 */
JF.define("jf.ui.Toast", {
	extend : jf.ui.Component,
	Toast : function(args) {
		!args.text ? this.text = "信息<p class='h4'>[点击关闭]</p>" : this.text = args.text+"<p class='h4'>[点击关闭]</p>";
		!args.callback ? this.callback = function() {
		} : this.callback = args.callback;
		!args.iconfont ? this.iconfont = "iconfont icon-wechat-fill" : this.iconfont = args.iconfont;
		!args.width ? this.width = "40%" : this.width = args.width;
		!args.noScrollHide ? this.noScrollHide = "0" : this.noScrollHide = args.noScrollHide;
		this.container=$("body");
	},
	draw : function() {
		var me = this;
		var $loading = $('<div>'); 
		
		new jf.ui.ClearToast();
		
		var $toast = $('<div>');
		$toast.addClass("toast main-bgcolor iconfont boxShadow");
		$toast.attr("noScrollHide",this.noScrollHide);
		
		if (JF.isValid(this.width)) {
			$toast.css("max-widht", "80%");
			$toast.css("width", this.width);
			$toast.css("left", "0px");
			$toast.css("right", "0px");
			$toast.css("margin", "auto");
		}

		var $icon = $('<div>');
		$icon.addClass(this.iconfont);
		$icon.addClass('icon-h1');

		var $msg = $('<div>');
		$msg.addClass("toast-content"); 
		
		var $msgText = $('<div>');
		$msgText.addClass("h1 strong");
		$msgText.html(this.text);
		
		this.$msgS = $('<div>');
		this.$msgS.addClass("h1 strong"); 
		
		$msg.append(this.$msgS).append($msgText);

		$toast.append($icon);
		$toast.append($msg);
		if (!JF.isValid(this.args.s)) {
			$loading.append($toast);
			this.$ = $loading;
			this.bindObject = $loading;
			this.esseObject = $loading;
		} else {
			this.$ = $toast;
			this.bindObject = $toast;
			this.esseObject = $toast;
		}
	},
	show : function() {
		this.build();
		this.$.hide();
		this.$.fadeIn();
		this._show(); 
	}, 
	_show : function() {
		var me = this;
		$("body").find("input").blur();
		$("body").find("textarea").blur();
		if (JF.isValid(this.args.s)) { 
			var s=me.args.s/1000;
			me.$msgS.html(s); 
			var timer = setInterval(function() {
				s--;
				me.$msgS.html(s); 
				if (s <= 0) {
					clearInterval(timer);
					me.$msgS.html("");  
				}
			}, 1000);
			
			var fn=function() {
				me.$.fadeOut();
				if(JF.isValid(me.BG))
					me.BG.hide();
				if (me.args.callback)
					me.args.callback();
			};
			var t=setTimeout(fn, this.args.s); 
			tap(me.$, function() {
				me.$.fadeOut();
				clearTimeout(t);
				clearInterval(timer);
				if(JF.isValid(me.BG))
					me.BG.hide();
				if (me.args.callback)
					me.args.callback();
			});
		} else {
			tap(this.$.find(".toast"), function() {
				me.$.fadeOut();
				if(JF.isValid(me.BG))
					me.BG.hide();
				if (me.args.callback)
					me.args.callback();
			});
		}

	},
	hide : function() {
		try {
			this.$.fadeOut();
			this.$.find(".toast").off("tap");
			if(JF.isValid(this.BG))
				this.BG.hide(); 
		} catch (e) {

		} 
	}
});
 
/*******************************************************************************
 * 加载进度条
 */
JF.define("jf.ui.Loading", {
	extend : jf.ui.Toast,
	Loading : function(args) {
		!args.text ? this.text = "加载中" : this.text = args.text; 
		this.win = args.win;// 当前窗口名称
		this.box = args.box;// 当前父窗口名称
		this.container=$("body");
	},
	draw : function() {
		var me = this;

		var $loading = $('<div>');
		$loading.addClass("loading h1 strong");

		new jf.ui.ClearToast();
		
		var $main = $('<div>');
		$main.addClass("ajaxloader1");
  
		this.$msg = $('<div>');
		this.$msg.addClass("msg h4 w-color border6 strong");
		this.$msg.hide(); 
		 
		$loading.append($main).append(this.$msg);
		this.$ = $loading;
		this.bindObject = $loading;
		this.esseObject = $loading;
	},
	show : function() {
		var me=this;
		this.build();
		this._show();  
		this.BG = new jf.ui.BG({ 
			bg:"rgba(0, 0, 0, 0)"
		});
		//me.BG.show();
		setTimeout(function(){
			me.$msg.show(); 
			me.$msg.addClass("main-bgcolor");
			me.$msg.html("网络不好？立即刷新？"); 
			tap(me.$msg,function(){ 
				window.location.reload();
//				if(isWeixin()){
//					window.location.replace("oauth2/oauth/?shopid=" + curShopid+"&win="+me.win+"&box="+me.box);
//				}else{
//					window.location.replace("index.html?shopid=" + curShopid+"&win="+me.win+"&box="+me.box);
//				} 
			});
		},8000);
		return this;
	},
	showBG : function() {
		var me=this;
		this.build();
		this._show();
		this.BG = new jf.ui.BG({ 
			bg:"rgba(0, 0, 0, 0)"
		});
		this.$msg.addClass("main-bgcolor");
		this.$msg.html(this.text+"<br/><font class='h2'>请不要重复操作</font>"+"<br/><font class='h4'>[点击关闭]</font>");
		this.$msg.show();
		this.BG.show();
		tap(this.$msg,function(){
			me.hide();
		});
		return this;
	},
	showWin : function() {
		var me=this;
		this.build();
		this._show();
		this.BG = new jf.ui.BG({ 
			bg:"rgba(0, 0, 0, 0)"
		});
		this.$msg.removeClass("w-color border6"); 
		this.$msg.html('<div class="loadingtext">'+
				 ' <span>L</span>'+
				  '<span>o</span>'+
				  '<span>a</span>'+
				  '<span>d</span>'+
				  '<span>i</span>'+
				  '<span>n</span>'+
				  '<span>g</span>'+
				'</div>');
		this.$msg.show();
		this.BG.show(); 
		setTimeout(function(){
			me.$msg.show(); 
			me.$msg.addClass("main-bgcolor");
			me.$msg.addClass("w-color border6");
			me.$msg.html("网络不好？立即刷新？"); 
			tap(me.$msg,function(){
				window.location.reload();
//				if(isWeixin()){
//					window.location.replace("oauth2/oauth/?shopid=" + curShopid+"&win="+me.win+"&box="+me.box);
//				}else{
//					window.location.replace("index.html?shopid=" + curShopid+"&win="+me.win+"&box="+me.box);
//				} 
			});
		},8000);
		return this;
	},
	hide : function() {
		try {
			this.$.fadeOut();
			this.$.find(".msg").off("tap");
			if(JF.isValid(this.BG))
				this.BG.hide(); 
		} catch (e) {

		} 
		return this;
	}
});
/*******************************************************************************
 * 底部弹出提示
 */
JF.define("jf.ui.BottomToast", {
	extend : jf.ui.Component,
	BottomToast : function(args) {
		!args.text ? this.text = "信息" : this.text = args.text;
		!args.s ? this.s = 1000 : this.s = args.s;
		!args.y ? this.y = -1 : this.y = args.y;
		this.container=$("body");
	},

	draw : function() {
		var me = this; 
		new jf.ui.ClearToast(); 
		var $toast = $('<div>');
		$toast.addClass("bottom-toast main-bgcolor h2");
		$toast.html(this.text);
		tap($toast, function() {
			me.hide();
		});
		var $close = $('<span class="h iconfont icon-cuowuguanbiquxiao p-right p-top">');
		$close.css("right","0px");
		$close.css("top","-5px");
		$toast.append($close);
		this.$ = $toast;
		this.bindObject = $toast;
		this.esseObject = $toast;
	},
	show : function() {
		this.build();
		this.$.hide();
		this._show();
	},
	_show : function() {
		var me = this;
		this.$.show();
		var h = this.$.height();
		this.$.css("bottom", me.y + "px");
		this.$.css("height", "-0px");
		this.$.animate({
			height : h + "px",
		}, 300, function() {
			setTimeout(function() {
				me.hide();
			}, me.s);

		});
		$("body").find("input").blur();
		$("body").find("textarea").blur();
	},
	hide : function() {
		var me = this;
		this.$.animate({
			height : "-0px",
		}, 300, function() {
			me.$.hide();
		});
	}
});

/*******************************************************************************
 * 头部弹出提示
 */
JF.define("jf.ui.TopToast", {
	extend : jf.ui.BottomToast,
	TopToast : function(args) {  
	},
	_show : function() {
		var me = this;
		this.$.show();
		var h = this.$.height();
		this.$.css("top", "-1px");
		this.$.css("height", "-0px");
		this.$.animate({
			height : h + "px",
		}, 300, function() {
			setTimeout(function() {
				me.hide();
			}, me.s); 
		});
		$("body").find("input").blur();
		$("body").find("textarea").blur();
	}, 
});

/*******************************************************************************
 * 弹出对话框
 */
JF.define("jf.ui.Alert", {
	extend : jf.ui.Component,
	Alert : function(args) {
		!args.type ? this.type = 0 : this.type = args.type;
		!args.ok ? this.ok = function() {
		} : this.ok = args.ok;
		!args.cancel ? this.cancel = function() {
		} : this.cancel = args.cancel;
		!args.title ? this.title = "温馨提示" : this.title = args.title;
		!args.text ? this.text = "" : this.text = args.text;
		!args.okText ? this.okText = "确定" : this.okText = args.okText;
		!args.cancelText ? this.cancelText = "取消" : this.cancelText = args.cancelText
		this.autoClickBtnHide = args.autoClickBtnHide;
		this.container=$("body");
		this.build();
	},
	draw : function() {
		var me = this;
		new jf.ui.ClearToast();
		var $loading = $('<div>');
		$loading.addClass("aui-mask");

		var $div = $('<div>');
		$div.addClass("dialog main-bgcolor");

		var $header = $('<div>');
		$header.addClass("dialog-header ");  
		$header.html(this.title);
		
		var $close = $('<span>');
		$close.addClass("close iconfont icon-cuowuguanbiquxiao red-color");  
		tap($close,function(){
			me.hide();
		});
		$header.append($close); 
		 
		var $body = $('<div>');
		$body.addClass("dialog-body"); 
		$body.html(this.text);

		var $footer = $('<div>');
		$footer.addClass("dialog-footer");

		var $cancel = $('<div>');
		$cancel.addClass("cancel");
		$cancel.addClass("dialog-btn w-bgcolor w2-color border6"); 
		$cancel.html(this.cancelText);
		tap($cancel, function() {
			me.cancel.apply(me);
			if (me.autoClickBtnHide == null || me.autoClickBtnHide == true) {
				me.hide();
			}
		});

		var $ok = $('<div>');
		$ok.addClass("ok");
		$ok.addClass("dialog-btn w-bgcolor green-color border6");
		$ok.addClass("aui-text-info");
		$ok.html(this.okText);
		tap($ok, function() {
			me.ok.apply(me);
			if (me.autoClickBtnHide == null || me.autoClickBtnHide == true) {
				me.hide();
			}
		});
		if (this.type == 0) {
			$footer.append($ok);
		} else {
			$footer.append($cancel).append($ok);
		} 
		
		$div.append($header).append($body).append($footer); 
		$loading.append($div);

		this.$ = $loading;
		this.bindObject = $loading;
		this.esseObject = $loading;
	},
	hide : function() {
		this.$.remove();
	}
});
/*******************************************************************************
 * 置顶按钮
 */
JF.define("jf.ui.TopButton", {
	extend : jf.ui.Component,
	TopButton : function(args) {
		this.targetFrame = args.targetFrame;
		this.build();
	},
	draw : function() {
		var me = this;
		var $topBtn = $('<div>');
		$topBtn.addClass("topBtn border7 black-bgcolor w-color");
		var $i = $('<i>');
		$i.addClass("iconfont icon-huidingbu");
		$topBtn.append($i);
 
		this.$ = $topBtn;
		this.bindObject = $topBtn;
		this.esseObject = $topBtn;
	},
	show : function() {
		this.$.fadeIn();
	},
	hide : function() {
		this.$.fadeOut();
	}
});
 

/*******************************************************************************
 * 右侧浮动字母导航
 */
JF.define("jf.ui.AlphabeticalNavigation", {
	extend : jf.ui.Component,
	AlphabeticalNavigation : function(args) {
		this.jsServer = args.jsServer;
		this.targetItems = args.targetItems;
		this.build();
	},
	draw : function() {
		var me = this;
		var $alphabeticalNavigation = $('<div>');
		$alphabeticalNavigation.addClass("alphabeticalNavigation strong h2");
		for (var i = 0; i < 26; i++) {
			var A = String.fromCharCode(65 + i);
			var $p = $('<p>');
			var $a = $('<a>');
			$a.addClass("white-font-border strong");
			$a.html(A);
			$a.css("margin-bottom", "0px");
			$a.attr("href", "javascript:void(0)");

			$p.append($a); 
			tap($a, function() { 
				var target=me.targetItems.get($(this).html());  
				if(JF.isValid(target)){ 
					me.jsServer.scrollstop.myScroll.refresh();
					me.jsServer.scrollstop.myScroll.scrollToElement(target[0], 600); 
				}
			},true);
			$alphabeticalNavigation.append($p);
		}

		this.$ = $alphabeticalNavigation;
		this.bindObject = $alphabeticalNavigation;
		this.esseObject = $alphabeticalNavigation;
	},
	show : function() {
		this.$.fadeIn();
	},
	hide : function() {
		this.$.fadeOut();
	}
});
/*******************************************************************************
 * html窗口
 */
JF.define("jf.ui.Win", {
	extend : jf.ui.Component,
	Win : function(args) {
		this.build();
	},
	draw : function() {
		var me = this;
		var $win = $('<div>');
		$win.attr("id", this.args.id);
		$win.attr("name", this.args.name);
		$win.addClass("win");
		$win.addClass(jf.os.sequence); 
		this.$ = $win;
		this.bindObject = $win;
		this.esseObject = $win;
	}
});
 
/*******************************************************************************
 * 
 */
JF.define("jf.ui.TextBox", {
	extend : jf.ui.Component,
	TextBox : function(args) { 
		this.margin = args.margin;
		this.borderColor = args.borderColor;
		!args.isBoxShadow ? this.isBoxShadow = false : this.isBoxShadow = args.isBoxShadow;
		!args.placeholder ? this.placeholder = "" : this.placeholder = args.placeholder;
		!JF.isValid(args.icon) ? this.icon = "iconfont icon-shuru" : this.icon = args.icon;
		!args.readonly ? this.readonly = false : this.readonly = args.readonly;
		!args.type ? this.type = "0" : this.type = args.type;
		!args.mode ? this.mode = "text" : this.mode = args.mode;
		!args.isVoice ? this.isVoice = false : this.isVoice = args.isVoice;
		this.listener = args.listener;// 事件
		this.maxLength = args.maxLength;
		this.cn = args.cn;
		this.build();
	},
	draw : function() {
		var me = this;
		var $panel = $('<div>');
		$panel.addClass("textbox textbox-border parent w");
		if(this.isBoxShadow){ 
			$panel.addClass("boxShadow");
		}
		$panel.css("border","1px solid "+this.borderColor); 
		$panel.css("margin", this.margin);
		$panel.css("width", this.width); 
		
		this.$cn = $('<div>');
		if(JF.isValid(this.cn)){  
			if(me.type==3||me.type==2){
				this.$cn.addClass("titleText w2-color left");
			}else if(me.type==4){
				this.$cn.addClass("titleText w2-color w2-bgcolor left");
			}else{
				this.$cn.addClass("titleText left main-titleText-border font-color w-bgcolor");
			} 
			this.$cn.css("color",this.borderColor);
			this.$cn.css("border-top","1px solid "+this.borderColor);
			this.$cn.css("border-left","1px solid "+this.borderColor);
			this.$cn.css("border-right","1px solid "+this.borderColor); 
			this.$cn.html(this.cn); 
			$panel.append(this.$cn);
			$panel.css("margin-top","15px");
			$panel.css("margin-bottom","15px"); 
		}
		
		// ////////////左侧图标start///////////////
		var $leftDiv = $('<div>');
		$leftDiv.addClass("child1 middle-left"); 
		var $icon = $('<span>');
		if(JF.isValid(this.icon)){ 
			$icon.addClass(this.icon + " icon"); 
			$icon.css("color",this.borderColor);
			$leftDiv.append($icon);
		} 
		tap($icon, function() { 
			// 弹出输入提示
			me.showTip();
		},true); 
		$panel.append($leftDiv);
		// ////////////左侧图标end///////////////
		
		
		// ////////////中间输入框start///////////////
		this.$input = null;
		if (this.mode == "textarea") {
			this.$input = $('<textarea>');
			this.$input.addClass("textarea");
		}else if (this.mode == "password") {
			this.$input = $('<input>');
			this.$input.attr("type","password");
		} else {
			this.$input = $('<input>');
		}
		this.$input.attr("maxLength", this.maxLength);
		this.$input.attr("mode", this.mode);
		
		
		this.$input.attr("id", this.id);
		this.$input.attr("name", this.name); 
		this.$input.attr("placeholder", this.placeholder); 
		
		if (me.listener) {
			tap(this.$input,function(){  
				if(me.readonly==true){
					me.$input.blur(); 
				}
				me.listener.apply(me,[me.$input]); 
			},true); 
		}else{
			tap(me.$input,function(){  
				if(me.readonly==true){
					me.$input.blur(); 
				}
				me.showTip();// 弹出输入提示
				me.$input.focus();
			},true);
		}
		
		me.$input.focus(function() {  
			if(me.readonly==true){
				me.$input.blur(); 
			}
			me.showTip();// 弹出输入提示
		}); 
		me.$input.blur(function() {  
			// 弹出输入提示
			if(JF.isValid(me.placeholder)&&JF.isValid(me.$tip)){ 
				me.$tip.remove();
			}
		});
		
		var $centerDiv = $('<div>');
		$centerDiv.addClass("child8 middle-left");  
		var $form=$('<form class="w" action="" onsubmit="return false;">'); 
		$form.append(me.$input);
		$centerDiv.append($form);
		$panel.append($centerDiv); 
		// ////////////中间输入框end///////////////
		
		var $showText = $("<div>");
		$showText.addClass("showText w1-color");
		$form.append($showText);  
 
		// ////////////右侧图标start///////////////
		this.$rightDiv = $('<div>');
		this.$rightDiv.addClass("child1 middle-left");   
		this.$clearIcon = $('<span>');
		if(this.isVoice){ 
			this.$clearIcon.addClass('iconfont icon-maikefeng clear');
			bindVoice(this.$rightDiv,function(rs){
				if(JF.type(me)=="jf.ui.TextArea"){
					me.setValue(me.getValue()+"<p class='section indent'>"+rs+"</p>");
				}else{
					me.setValue(me.getValue()+rs);
				} 
			});
		}else{
			this.$clearIcon.addClass('iconfont icon-cuowuguanbiquxiao clear');
			tap(this.$rightDiv, function() { 
				me.$input.show();
				me.$input.val("");
				me.$input.select();
				$showText.html("");
			}); 
		}
		this.$rightDiv.append(this.$clearIcon);
		$panel.append(this.$rightDiv); 
		// ////////////右侧图标end///////////////
		
		if(this.readonly==true){
			this.$input.attr("readonly", this.readonly);
			this.$clearIcon.hide();
		}
		
		if (this.mode == "textarea") {
			me.$input.css("height", this.height);
			me.$input.css("min-height", this.height);
			$icon.addClass("p-top");
			$icon.css("top", "-4px");
			this.$clearIcon.addClass("p-top");
			this.$clearIcon.css("top", "-4px"); 
			setTimeout(function(){ 
				me.autoTextarea(me.$input[0]);
			});
		}
		if(this.type==0){
			$panel.css("background","#fff"); 
		}else if(this.type==1){
			$panel.css("border-radius","0px");
		}else if(this.type==2){
			$panel.css("border-radius","0px");
			$panel.css("border","0px");
			$panel.css("border-bottom","0.5px dashed #d4d4d4");
			this.$clearIcon.hide();
			$icon.hide();
			me.$input.css("left","0px");
			me.$input.css("width","100%"); 
		}else if(this.type==3){ 
			$panel.css("border-radius","0px");
			$panel.css("border","0px");
			$panel.css("border-bottom","0.5px dashed #d4d4d4");
			this.$clearIcon.css("color","#280028"); 
		}else if(this.type==4){ 
			$panel.css("border","0px");
			$panel.css("background","#eee"); 
			this.$clearIcon.css("color","#280028"); 
		} 
 
		this.$ = $panel;
		this.bindObject = me.$input;
		this.esseObject = me.$input;
	}, 
	hideNumberKeyboard : function() {
		this.$numberPanel.hide(); 
		this.page.css("padding-bottom",this.$numberPanel.data("padding-bottom")); 
		this.$input.css("border","none"); 
		this.win.scrollstop.myScroll.refresh();
	}, 
	showNumberKeyboard : function() {
		var me=this; 
		$("body").find(".numberKeyboard").hide(); 
		$("body").find(".textbox").find("input").css("border","none");
		this.$numberPanel.css("bottom","0px");
		this.$numberPanel.css("left","0px");
		this.$numberPanel.css("width","100%");
		this.$numberPanel.show();
		if(JF.isValid(me.placeholder)&&JF.isValid(me.$tip)){ 
			me.$tip.remove();
			me.$numberPanel.find(".title").html(me.placeholder);
		}
		me.$input.blur(); 
		me.$input.css("border","0.5px dashed #f44336");
		this.numberKeyboardInput();
	},
	numberKeyboardInput : function(param) {
		var h=this.$numberPanel.height(); 
		this.page.css("padding-bottom",h);  
		this.scrollToMe();
	},
	numberKeyboard : function(param) {
		var me=this;
		if(!JF.isValid(param)){
			param={};
		}
		this.esseObject.attr("readonly", true);
		this.$numberPanel = $("<div class='p-left hide numberKeyboard' style='border-top:0.5px solid #fff;'>");
		this.$numberPanel.css("z-index",1);
		var $closeDiv = $('<div class="parent list-view btn-red"></div>');
		var $title = $('<div class="child4 middle-left"><span class="title h2">数字键盘</span></div>'); 
		var $close = $('<div class="child1"><span class="sign h2 float-left">确定</span></div>');
		tap($closeDiv,function(){
			me.hideNumberKeyboard();
		});
		var $close1 = $('<div class="child1"><span class="sign h2 float-right">确定</span></div>');
		 
		
		$closeDiv.append($close).append($title).append($close1);
		
		this.$numberPanel.append($closeDiv); 
		var nums =[];
		var back="<i class='iconfont icon-huitui icon-h4'></i>";
		if(JF.type(this)=="jf.ui.MobilePhoneTextBox"||JF.type(this)=="jf.ui.NumberTextBox"){
			nums = [ 7, 8, 9, 4, 5, 6, 1, 2, 3, 0, "", back];
		}else if(JF.type(this)=="jf.ui.MoneyTextBox"){
			nums = [ 7, 8, 9, 4, 5, 6, 1, 2, 3, 0, ".", back];
		}else{
			nums = [ 7, 8, 9, 4, 5, 6, 1, 2, 3, 0, ".", back];
		}
		
		var row = 1;
		var col = 1;
		var len = nums.length;
		var $item = null;
		for (var i = 0; i < len; i++) {
			var one = nums[i];
			if (col == 1) {
				$item = $("<div class='felxBox'>");
				$item.css("min-height", "21%");
				this.$numberPanel.append($item);
			}
			var $one = $("<div class='col1 w-bgcolor border7 font-color'>");
			$one.attr("param", one);
			$one.html(one);
			$item.append($one);
			tap($one, function() {
				me.numberKeyboardInput();
				var val=me.getValue();
				var rs=$(this).html(); 
				
				if(rs.indexOf("iconfont")!=-1){ 
					if(JF.isValid(val)){
						val=val.substring(0,val.length-1);
						me.setValue(val);
					}
				}else{
					if(val.length>=param.maxLength){
						return;
					}
					if(JF.type(me)=="jf.ui.MoneyTextBox"){ 
						var hasPoint = val.indexOf(".");
						if(hasPoint!=-1&&rs=="."){
							return;
						}else if (hasPoint != -1) {
							// 如果有小数点，判断小数点后面的数字是否为2位标准格式，多余的不准再输
							var pointBackNum = val.substring(hasPoint);
							if (pointBackNum.length > 2) {
								return false;
							}
						}
					}
					me.setValue(me.getValue()+rs);
				}
			},true);
			col++;
			if (col == 4) {
				col = 1;
				row++;
			}
		}
		this.getWin(); 
		this.win.$.append(this.$numberPanel);
		var old=this.page.css("padding-bottom");
		this.$numberPanel.data("padding-bottom",old); 
	},
	/**
	 * 文本框根据输入内容自适应高度
	 * 
	 * @param {HTMLElement}
	 *            输入框元素
	 * @param {Number}
	 *            设置光标与输入框保持的距离(默认0)
	 * @param {Number}
	 *            设置最大高度(可选)
	 */
	autoTextarea : function(elem, extra, maxHeight) {
		var me = this;
		extra = extra || 0;
		var isFirefox = !!document.getBoxObjectFor || 'mozInnerScreenX' in window, isOpera = !!window.opera && !!window.opera.toString().indexOf('Opera'), addEvent = function(type, callback) {
			elem.addEventListener ? elem.addEventListener(type, callback, false) : elem.attachEvent('on' + type, callback);
		}, getStyle = elem.currentStyle ? function(name) {
			var val = elem.currentStyle[name];

			if (name === 'height' && val.search(/px/i) !== 1) {
				var rect = elem.getBoundingClientRect();
				return rect.bottom - rect.top - parseFloat(getStyle('paddingTop')) - parseFloat(getStyle('paddingBottom')) + 'px';
			}  
			return val;
		} : function(name) {
			return getComputedStyle(elem, null)[name];
		}, minHeight = parseFloat(getStyle('height'));

		elem.style.resize = 'none';

		var change = function() { 
			var scrollTop, height, padding = 0, style = elem.style;

			if (elem._length === elem.value.length)
				return;
			elem._length = elem.value.length;

			if (!isFirefox && !isOpera) {
				padding = parseInt(getStyle('paddingTop')) + parseInt(getStyle('paddingBottom'));
			} 
			scrollTop = document.body.scrollTop || document.documentElement.scrollTop;

			elem.style.height = minHeight + 'px';

			//console.log(elem.scrollHeight+"=="+  minHeight);
			
			if (elem.scrollHeight > minHeight) {
				if (maxHeight && elem.scrollHeight > maxHeight) {
					height = maxHeight - padding;
					style.overflowY = 'auto';
				} else {
					height = elem.scrollHeight - padding;
					style.overflowY = 'hidden';
				} 
				style.height = height + extra + 'px';
				scrollTop += parseInt(style.height) - elem.currHeight;
				elem.currHeight = parseInt(style.height);
			} 
		};

		addEvent('propertychange', change);
		addEvent('input', change);
		addEvent('focus', change);
		change();
	},
	showTip:function(){
		var me=this;
		 
		if(JF.isValid(me.placeholder)){ 
			new jf.ui.ClearToast();  
			me.$tip = $('<div>');
			me.$tip.addClass("tip p-center main-bgcolor middle left h1");
			me.$tip.addClass("boxShadow radius3");
			me.$tip.html(me.placeholder); 
			if(me.$input.offset().top-80<0){  
				me.$tip.css("top",me.$input.offset().top+80-me.$.height());
			}else{  
				me.$tip.css("top",me.$input.offset().top-80);
			}
 
			me.$tipColse = $('<span>');
			me.$tipColse.addClass("iconfont icon-cuowuguanbiquxiao w-color p-right p-top");
			me.$tip.append(me.$tipColse);
			$("body").append(me.$tip);
			tap(me.$tip,function(){
				me.$tip.remove();
			}); 
		}
	},
	_getValue : function() {
		return this.$input.val();
	},
	_setValue : function(val) {
		if (JF.isValid(val+"")) { 
			this.$input.val(val);
			this.$.find(".showText").html(val); 
		} else {
			this.$input.val("");
			this.$.find(".showText").html(""); 
		}
	},
	errorStyle : function() {
		var me = this;
		me.flag = "";
		if (!JF.isValid(this.timer)) {
			this.timer = setInterval(function() {
				if (me.flag == "0") {
					me.flag = "1"; 
					me.$.find(".icon").css("color", "#535353");
					me.$.find(".clear").css("color", "#280028"); 
					me.$.css("background", "#fff");
					me.$.find(".titleText").css("background", "#fff");
					me.$.find(".titleText").css("border-bottom","1px solid #fff"); 
				} else {
					me.flag = "0"; 
					me.$.find(".icon").css("color", "#fff");
					me.$.find(".clear").css("color", "#fff"); 
					me.$.css("background", "#FFDC00");
					me.$.find(".titleText").css("background", "#FFDC00"); 
					me.$.find(".titleText").css("border-bottom","1px solid #FFDC00"); 
				}
			}, 1000);
		} 
	},
	successStyle : function() {
		clearInterval(this.timer);
		this.timer = null; 
		this.$.find(".icon").css("color", "#3D9970");
		this.$.find(".clear").css("color", "#280028"); 
		if(this.type==0){
			this.$.css("background","#fff"); 
		}else if(this.type==1){
			this.$.css("background",""); 
		}else if(this.type==2){
			this.$.css("background",""); 
		}else if(this.type==3){ 
			this.$.css("background",""); 
		}else if(this.type==4){  
			this.$.css("background", "#eee");
		} 
		this.$.find(".titleText").css("background", "");
		this.$.find(".titleText").css("color", this.borderColor);
		this.$.find(".titleText").css("border-bottom","1px solid #fff"); 
	}, 
	getValue : function() {
		return this._getValue();
	},
	setValue : function(val) {
		this._setValue(val);
	},
	/***************************************************************************
	 * 禁用/开启
	 * 
	 * @param val
	 */
	readOnly : function(val) {
		if (val == true || val == null) {
			this.esseObject.attr("readonly", true);
			this.$clearIcon.hide();
			this.readonly=true;
		} else {
			this.esseObject.attr("readonly", false);
			this.$clearIcon.show();
			this.readonly=false;
		} 
	},

});

/*******************************************************************************
 * 文本域
 */
JF.define("jf.ui.TextArea", {
	extend : jf.ui.TextBox,
	TextArea : function(args) {
		!args.editid ? this.editid = this.id : this.editid = args.editid;
		this.textAreaDesign();
	},
	textAreaDesign : function() {
		var me = this;
		this.$input.attr("readonly","readonly"); 
		this.$input.hide();
		var showText=this.$.find(".showText");
		showText.show();
		// showText.css("left", "44px");
		this.$.css("height","100px"); 
		showText.css("height","90px"); 
		this.$.find(".icon").addClass("p-top");
		this.$.find(".icon").css("top", "-1px");
		this.$.find(".clear").addClass("p-top");
		this.$.find(".clear").css("top", "-1px");
		tap(showText,function(){ 
			loader.openWin({
				name : "edit",
				data : {
					editid : me.editid + "[detail]",
					content : me.getValue(),
					callback : function(val) {
						me.setValue(val);
						showText.html(val);
					},
				},
			}); 
		});
		if(JF.isValid(this.placeholder)&&!JF.isValid(showText.html())){
			showText.html(this.placeholder); 
		}else{
			showText.html(this.placeholder);
		}
	},
});

/*******************************************************************************
 * 文本域
 */
JF.define("jf.ui.DateTextBox", {
	extend : jf.ui.TextBox,
	DateTextBox : function(args) { 
		this.selectListener = args.selectListener; 
		this.dateTextBoxDesign();
	},
	dateTextBoxDesign : function() {
		var me = this;
		var currYear = (new Date()).getFullYear();
		var opt = {};
		opt.date = {
			preset : 'date'
		};
		opt.default = {
			theme : 'android-ics light',  
			display : 'modal',  
			mode : 'scroller', 
			lang : 'zh',
			dateFormat: 'yy-mm-dd',  
			startYear : currYear - 10,  
			endYear : currYear + 10,
			onSelect: function (valueText, inst) { 
				if(me.selectListener){
					me.selectListener.apply(me,[valueText, inst]);
				} 
            }
		};

		var optDateTime = $.extend(opt['date'], opt['default']);
		this.$input.mobiscroll(optDateTime).date(optDateTime);
		this.readOnly(true);
		
		this.$.find(".icon").removeClass(this.icon);
		this.$.find(".icon").addClass("iconfont icon-riqi");
	},
});
/*******************************************************************************
 * 数字文本框
 */
JF.define("jf.ui.NumberTextBox", {
	extend : jf.ui.TextBox,
	NumberTextBox : function(args) {
		this.numberTextBoxDesign();
	},
	numberTextBoxDesign : function() {
		var thiz = this;
		this.$input.attr("type","number");
		 
		this.$input.keypress(function(e) {
			var key = e.keyCode;
			if (!(key >= 48 && key <= 57)) {
				return false;
			}
		});
		this.numberKeyboard();
		thiz.$input.focus(function() {  
			if(thiz.readonly!=true){ 
				thiz.showNumberKeyboard();
			}
		});  
	},
});
/*******************************************************************************
 * 搜索框
 */
JF.define("jf.ui.SearchBox", {
	extend : jf.ui.TextBox,
	SearchBox : function(args) {
		this.searchListener = args.searchListener;  
		this.searchBoxDesign();
	},
	searchBoxDesign : function() {
		var thiz = this;
		var voice=$("<span class='iconfont icon-maikefeng p-right'></span>");
		voice.css("top","3px");
		voice.css("right","40px");
		var btn=$("<span class='padding1 p-right img-bgcolor main-color'>搜索</span>");
		btn.css("border","0px");
		btn.css("border-left","0.5px dashed #FF851B");
		btn.css("border-radius","0px"); 
		
		btn.css("right","10px");
		this.$.append(voice).append(btn);  
		tap(btn,function(){
			thiz.$.find("input").blur();
			if(thiz.searchListener)
				thiz.searchListener();
		}); 
		this.$.find(".clear").hide();
		bindVoice(voice,function(rs){
			thiz.setValue(thiz.getValue()+rs);
		});
		this.$input.attr("type","search");
		this.$input.bind('search', function () { 
			   thiz.$.find("input").blur();
				if(thiz.searchListener)
					thiz.searchListener();
		});
		btn.addClass("h4");
		btn.css("top","5px");
		this.$.css("height", "30px");
		voice.css("top","1px");
		this.$.css("border", "0px"); 
		this.$input.css("height", "30px");
		this.$.find(".text").css("height", "20px");
		this.$.find(".text").css("bottom", "3px");
		this.$.find("input").css("bottom", "0px"); 
		this.$.find("input").css("font-size", "0.75rem");
		this.$.find(".text").css("font-size", "0.75rem");
		this.$.find(".icon").css("font-size", "0.85rem");
		this.$.find(".icon").css("top", "3px"); 

	},
});
/*******************************************************************************
 * 手机号码文本框
 */
JF.define("jf.ui.MobilePhoneTextBox", {
	extend : jf.ui.TextBox,
	MobilePhoneTextBox : function(args) {
		this.mobilePhoneTextBoxDesign();
	},
	mobilePhoneTextBoxDesign : function() {
		var thiz = this;
		this.$input.blur(function() {
			thiz.setValue(thiz.format(thiz.getValue())); 
		});
		this.$input.keyup(function() {
			thiz.setValue(thiz.format(thiz.getValue()));
		});
		this.$input.attr("maxLength", 13);
		this.numberKeyboard({
			maxLength:11
		});
		 
		thiz.$input.focus(function() {  
			//console.log(thiz.readonly);
			if(thiz.readonly!=true){ 
				thiz.showNumberKeyboard();
			}
		});  
	},
	/***************************************************************************
	 * 格式
	 */
	format : function(val) {
		var reg = /(-?\d+)(\d{4})/;
		while (reg.test(val)) {
			val = val.replace(reg, "$1 $2");
		}
		return val;
	},
	/***************************************************************************
	 * 获取值
	 * 
	 * @returns
	 */
	getValue : function() {
		var val = this._getValue();
		val = val.replace(new RegExp(/(\s)/g), "");
		return val;
	},
	/***************************************************************************
	 * 设置值
	 * 
	 * @param val
	 */
	setValue : function(val) {
		this.value = this.format(val);
		this._setValue(this.value);
	}
});
/*******************************************************************************
 * 金额文本框
 */
JF.define("jf.ui.MoneyTextBox", {
	extend : jf.ui.TextBox,
	MoneyTextBox : function(args) {
		this.moneyTextBoxDesign();
	},
	moneyTextBoxDesign : function() {
		var thiz = this;
		this.$input.blur(function() {
			thiz.setValue(thiz.format(thiz.getValue()));
		});
		this.$input.keyup(function() {
			thiz.setValue(thiz.format(thiz.getValue()));
		});
		this.$input.keypress(function(e) {
			var val = $(this).val();
			var hasPoint = val.indexOf(".");
			var key = e.keyCode;
			if ((key < 48 || key > 57) && key != 46) {
				return false;
			} else if (key == 46 && hasPoint != -1) {
				return false;
			} else if (hasPoint != -1) {
				// 如果有小数点，判断小数点后面的数字是否为2位标准格式，多余的不准再输
				var pointBackNum = val.substring(hasPoint);
				if (pointBackNum.length > 2) {
					return false;
				}
			}
		});
		
		this.numberKeyboard();
		thiz.$input.focus(function() {  
			if(thiz.readonly!=true){ 
				thiz.showNumberKeyboard();
			}
		}); 
		 
	},
	/***************************************************************************
	 * 格式
	 */
	format : function(val) {
		val+="";
		var hasPoint = val.indexOf(".");
		var left, right;
		if (hasPoint != -1) {
			left = val.substring(0, hasPoint);
			right = val.substring(hasPoint);
		} else {
			left = val;
			right = "";
		}
		var reg = /(-?\d+)(\d{3})/;
		while (reg.test(left)) {
			left = left.replace(reg, "$1,$2");
		}
		return left + right;
	},
	/***************************************************************************
	 * 获取值
	 * 
	 * @returns
	 */
	getValue : function() {
		var val = this._getValue();
		val = val.replace(new RegExp(/(,)/g), "");
		return val;
	},
	/***************************************************************************
	 * 设置值
	 * 
	 * @param val
	 */
	setValue : function(val) {
		this.value = this.format(val);
		this._setValue(this.value);
	}
});


/*******************************************************************************
 * 下拉框选择，默认时间选择控件
 */
JF.define("jf.ui.SelectBox", {
	extend : jf.ui.Component,
	SelectBox : function(args) {
		this.start = args.start;
		this.$end = args.$end;
		this.section = args.section; 
		!args.placeholder ? this.placeholder = "" : this.placeholder = args.placeholder;
		!args.cn ? this.cn = "" : this.cn = args.cn;
		!args.style ? this.style = "0" : this.style = args.style;
		!JF.isValid(args.icon) ? this.icon = "iconfont icon-wenhao-yuankuang" : this.icon = args.icon;
		this.change = args.change;
		this.borderColor = args.borderColor; 
		this.build();
	},
	draw : function() {
		var me = this;
		var $areaSelector = $('<div>');
		$areaSelector.addClass("selectBox selectBox-border");
		$areaSelector.css("border","1px solid "+this.borderColor); 
		var $titleText = $('<div>');
		if(JF.isValid(this.cn)){  
			$titleText.addClass("titleText  main-titleText-border  main-color center strong w-bgcolor");
			$titleText.css("color",this.borderColor);
			$titleText.css("border-top","1px solid "+this.borderColor);
			$titleText.css("border-left","1px solid "+this.borderColor);
			$titleText.css("border-right","1px solid "+this.borderColor); 
			$titleText.html(this.cn); 
			$areaSelector.append($titleText);
			$areaSelector.css("margin-top","10px");
			$areaSelector.css("margin-bottom","10px");
		}
		
		var $icon = $('<span>');
		if(JF.isValid(this.icon)){
			$icon.addClass(this.icon + " icon");
			$icon.addClass("main-color");
			$icon.css("color",this.borderColor);
			$areaSelector.append($icon);
		}
		tap($icon, function() { 
			// 弹出输入提示
			me.showTip();
		},true); 
		
		if(this.style==1){
			$areaSelector.css("border-radius","0px");
		}

		$areaSelector.css("width", this.width);

		var $start = $('<select>');
		$start.addClass("start");

		if (JF.isValid(this.section)) {
			for (var i = 0; i < this.section.length; i++) {
				$option = $('<option>');
				$option.html(this.section[i]);
				$start.append($option);
			}
		} 
		if (JF.isValid(this.change)) {
			$start.on("change",function(){
				if(me.change)
					me.change(me.getValue());
			});
		} 
		$areaSelector.append($start);

		this.$ = $areaSelector;
		this.bindObject = $areaSelector;
		this.esseObject = $areaSelector;
	},

	showTip:function(){
		var me=this;
		var $input=this.$.find("select");
		if(JF.isValid(me.placeholder)){ 
			new jf.ui.ClearToast(); 
			me.$tip = $('<div>');
			me.$tip.addClass("tip p-center main-bgcolor middle left h1");
			me.$tip.addClass(" strong boxShadow radius3");
			me.$tip.html(me.placeholder);
			if($input.offset().top-80<0){ 
				me.$tip.css("top",$input.offset().top+80-me.$.height());
			}else{ 
				me.$tip.css("top",$input.offset().top-80);
			}
			me.$tipColse = $('<span>');
			me.$tipColse.addClass("iconfont icon-cuowuguanbiquxiao strong w-color p-right p-top");
			me.$tip.append(me.$tipColse);
			$("body").append(me.$tip);
			tap(me.$tip,function(){
				me.$tip.remove();
			});
		}
	},
	getValue : function() {
		return this.getStart();
	},
	setValue : function(start) {
		this.setStart(start);
	},

	getStart : function() {
		return this.$.find(".start").val();
	},

	setStart : function(val) {
		this.$.find(".start").val(val);
	}, 
});
/*******************************************************************************
 * 数字加减盒
 */
JF.define("jf.ui.NumberBox", {
	extend : jf.ui.Component,
	NumberBox : function(args) {
		JF.isNull(args.multi) ? this.multi = true : this.multi = args.multi; 
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg;  
		this.build();  
	},
	draw : function() {
		var me = this; 
		var $item = $('<div>');
		$item.addClass("numberBox parent");
		
		var $itemLeft = $('<div>');
		$itemLeft.addClass("child1 middle ");
		
		var $itemCenter = $('<div>');
		$itemCenter.addClass("child2 middle ");
		
		var $itemRight = $('<div>');
		$itemRight.addClass("child1 middle ");
		
		$item.append($itemLeft).append($itemCenter).append($itemRight);
		
		var $leftBtn = $('<span>');
		$leftBtn.addClass("iconfont icon-jian h4 w1-color");
		tap($itemLeft, function() {  
			var count = parseInt(me.$input.val());
			if (count - 1 < 1) {
				new jf.ui.BottomToast({ 
					text : "不能再少了哦！"
				}).show();
				return;
			}
			me.$input.val(--count); 
			if(me.listener){
				me.listener.apply(me,[me.$input.val()]);
			}
		},true); 
		$itemLeft.append($leftBtn);
		
		this.$input = $('<input>');
		this.$input.attr("type","number");
		this.$input.addClass("num");
		this.$input.val(0); 
		this.$input.keyup(function(){  
			if(me.listener){
				me.listener.apply(me,[me.$input.val()]);
			}
		});
		$itemCenter.append(this.$input);
		
		var $rightBtn = $('<span>');
		$rightBtn.addClass("iconfont icon-jia h4");
		tap($itemRight, function() {  
			var count = parseInt(me.$input.val()); 
			me.$input.val(++count); 
			if(me.listener){
				me.listener(me.$input.val());
			}
		},true); 
		$itemRight.append($rightBtn);
	 
		this.$ = $item;
		this.bindObject = $item;
		this.esseObject = this.$input;
	}, 
	getValue:function(){
		return this.$input.val();
	},
	setValue:function(val){
		return this.$input.val(val);
	}, 
});
/*******************************************************************************
 * 单多选框
 */
JF.define("jf.ui.CheckBox", {
	extend : jf.ui.Component,
	CheckBox : function(args) {
		JF.isNull(args.multi) ? this.multi = true : this.multi = args.multi;
		this.group = args.group; 
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg;  
		!args.type ? this.type = 0 : this.type = args.type; 
		this.build();  
	},
	draw : function() {
		var me = this;
		var $box = $('<div>'); 
		$box.addClass("parent");
		me.items=new jf.util.Map();
		var cfgLen = this.cfg.length; 
		for (var i = 0; i < cfgLen; i++) { 
			var c = me.cfg[i]; 
			
			var $item = $('<div>');
			$item.addClass("checkBox child1 parent");
			
			var $itemIcon = $('<div>');
			$itemIcon.addClass("child1 middle middle-left");
			
			var $itemText = $('<div>');
			$itemText.addClass("child5 middle-left");
			
			$item.append($itemIcon).append($itemText);
			
			var $icon = $('<span>');
			$icon.addClass("icon w1-color icon-h3");  
			$itemIcon.append($icon);
			if(this.type==0){
				$icon.addClass("iconfont icon-checkbox-weixuan");  
			}
			if(JF.isNull(c.value)){
				c.value=c.text;
			}
			
			var $input = $('<input>');
			$input.attr("type","checkbox");
			$input.attr("param",c.param);
			$input.attr("value",c.value);
			$input.data("value", c.value);
			$input.attr("text", c.text);
			$item.append($input);
			
			var $text = $('<font>');
			$text.addClass("text h1"); 
			$text.html(c.text);
			$itemText.append($text);
			
			$box.append($item);
			 
			$item.data("fn", c.click);
			$item.data("text", c.text);
			$item.data("value", c.value);
			$item.attr("value", c.value);
			$item.attr("i", i); 
			
			tap($item, function() {
				var tab = $(this);
				me.selectTabMenu(tab);
				tab.data("fn").apply(me, [ tab.data("value"),tab]);
			},true); 
			
			if(JF.isValid(c.container)){
				c.container.append($item);
			}else{
				$box.append($item);
			}
			me.items.put(c.value,$item);
		} 
		this.$ = $box;
		this.bindObject = $box;
		this.esseObject = $box;
	}, 
	selectTabMenu : function(i) {   
		var item=this.getItem(i);
		if(!this.multi){ 
			this.items.each(function(key, value, i, len, array){ 
				this.unchecked(value);
			}); 
			this.checked(item); 
		}else{
			if (item.data("checked")) {
				this.unchecked(item);
			} else {
				this.checked(item);
			}
		} 
	},
	unchecked : function(i) {  
		var item;
		if (typeof i != "number"&&typeof i != "string") { 
			item=i;
		}else { 
			item=this.getItem(i);
		}   
		item.find("span").removeClass("iconfont green-color icon-checkbox-xuanzhong");
		if(this.type==0){
			item.find("span").addClass("iconfont w1-color icon-checkbox-weixuan");  
		}
		item.data("checked", false);
		item.find("input").attr("checked", false); 
		
	},
	checked : function(i) {  
		var item;
		if (typeof i != "number"&&typeof i != "string") { 
			item=i;
		}else { 
			item=this.getItem(i); 
		} 
		item.find("span").removeClass("iconfont w1-color icon-checkbox-weixuan");
		item.find("span").addClass("iconfont green-color icon-checkbox-xuanzhong"); 
		item.data("checked", true);
		item.find("input").attr("checked", true);
	},
	getItem : function(i) { 
		var me=this;
		if (JF.isNull(i)) {
			return;
		}
		var item=null;
		if (typeof i == "number") { 
			item = this.items.value(i);
		}else if (typeof i == "string") { 
			item = this.items.get(i);
		}else {
			item=i;
		}  
		return item;
	},
	
	getParam : function(i) {
		var me=this;
		var item=me.getItem(i);
		var input = item.find("input");
		return input.attr("param") 
	},
	setParam : function(i,val) {
		var me=this;
		var item=me.getItem(i);
		var input = item.find("input");
		input.attr("param",val)
	},
	getText : function() {
		var val = [];
		this.items.each(function(key, value, i, len, array){ 
			var input = value.find("input");
			if (input.attr("checked") == "checked") {
				val.push(input.attr("text"));
			}
		}); 
		return val;
	},
	setText : function(val) {
		var me=this;
		this.items.each(function(key, value, i, len, array){ 
			var input = value.find("input");
			if (input.attr("text") == val) {
				me.selectTabMenu(value);
				return false;
			}
		});  
	},
	getValue : function() {
		var val = [];
		this.items.each(function(key, value, i, len, array){ 
			var input = value.find("input");
			if (input.attr("checked") == "checked") {
				val.push(input.data("value"));
			}
		});  
		return val;
	},
	setValue : function(val) {
		var me=this;
		this.items.each(function(key, value, i, len, array){ 
			var input = value.find("input");
			if (input.val() == val) {
				me.selectTabMenu(value);
				return false;
			}
		});   
	}, 
	isChecked : function(i) {
		 if(this.getValue().length==0){
			 return false;
		 }else{
			 return true;
		 }
	},
	hideMenu : function(i) { 
		var item=this.getItem(i);
		item.hide();
	},
	showMenu : function(i) {
		var item=this.getItem(i);
		item.show();
	},
});

/*******************************************************************************
 * 盒子选择控件
 */
JF.define("jf.ui.GridBox", {
	extend : jf.ui.Component,
	GridBox : function(args) {
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg; 
		!args.borderClass ? this.borderClass = "boxShadow" : this.borderClass = args.borderClass; 
		!args.style ? this.style =0 : this.style = args.style; 
		JF.isNull(args.multi) ? this.multi =false : this.multi = args.multi; 
		JF.isNull(args.isShowDelIcon) ? this.isShowDelIcon =false : this.isShowDelIcon = args.isShowDelIcon; 
		!args.imgWidth ? this.imgWidth ="100%": this.imgWidth = args.imgWidth; 
		this.isTarget=false; 
		this.maxSize=args.maxSize; // 能选择的最大数
		this.items=new jf.util.Map();
		this.build(); 
		this.drag();
	},
	draw : function() {
		var me = this;
		var $gridBox = $('<div>');
		$gridBox.addClass("grid-box"); 
		me.$ul = $('<ul>');  
		if(this.style==0){ 
			me.$ul.addClass("box"); 
		}else{
			me.$ul.addClass("box1"); 
		}
		me.load(this.cfg);
		$gridBox.append(me.$ul); 
		this.$ = $gridBox;
		this.bindObject = $gridBox;
		this.esseObject = $gridBox;
	},
	load:function(cfg){
		var me=this;
		this.cfg=cfg;
		me.$ul.html("");
		this.items=new jf.util.Map();
		var cfgLen = this.cfg.length;  
		for (var i = 0; i < cfgLen; i++) {
			var c = me.cfg[i];
			var $li = $('<li>'); 
			$li.addClass("padding2 item");
			$li.css("height",c.height); 
			$li.css("max-height",c.height);
			$li.css("min-width",c.width);
			$li.css("max-width",c.width);
			
			var $content = $('<div>');
			$content.addClass("content");
			$content.addClass(this.borderClass);
			$content.css("height",c.height); 
			$li.append($content); 
			me.$ul.append($li); 
			
			var $icon=$("<i class='" + c.icon + "'>");
			var $text=$("<p class=''>" + c.text + "</p>");
			if (JF.isValid(c.icon)) {
				$content.append($icon); 
				$content.addClass("center middle"); 
				$content.addClass(c.className); 
				$content.css("background",c.bg);   
				$icon.addClass("icon icon-h3");   
			}else if (JF.isValid(c.text)) { 
				$content.append($text); 
				$content.addClass("center");
				$content.addClass(c.className);  
				$content.css("background",c.bg);  
				$text.addClass("text"); 
			}else{  
				$content.addClass("w-bgcolor");  
				me.isTarget=true;
				if(JF.isValid(c.target)){
					$content.append(c.target); 
				}else{ 	
					var $img;
					
					if(JF.isValid(c.img)){
						$img = $("<img>");
						$img.attr("src", c.img);
						$img.attr("width", me.imgWidth);
					}else{
						$img = $("<div>"); 
						$img.attr("width", me.imgWidth);
					}
					
					var $title = $("<div class='title padding3'>");
					$title.addClass("h3");
					$title.html(c.title); 
				
					var $subTitle = $("<div class='subTitle padding3'>");
					$subTitle.addClass("h4 w2-color");
					$subTitle.html(c.subTitle);  
					
					$content.append($img).append($title); 
					if(JF.isValid(c.subTitle)){
						$content.append($subTitle); 
					}
				}
			}
			if(JF.isNull(c.value)){
				c.value=c.text;
			}
			$content.data("fn", c.click);
			$content.data("value", c.value);
			$content.attr("value", c.value);
			$content.attr("i", i); 
			tap($content, function() {
				if(me.readonly==true){
					return;
				}
				var tab = $(this);
				me.selectTabMenu(tab);
				tab.data("fn").apply(me, [ tab.data("value"),tab,parseInt(tab.attr("i"))]);
			}); 
			if(this.isShowDelIcon==true){
				var $delIcon = $('<span class="iconfont icon-cuowuguanbiquxiao red-color p-right p-top">');
				tap($delIcon, function() {
					if(me.readonly==true){
						return;
					}
					var tab = $(this);
					if(c.delListener){
						c.delListener.apply(me,[ tab.parent().data("value"),tab.parent(),parseInt(tab.parent().attr("i"))]);
					}
				}); 
				$content.append($delIcon); 
			} 
			this.items.put(c.value,$content);

		} 
	},
	drag : function() {
		var me = this;
		me.scrollstop = new jf.ui.Scrollstop({
			target : this.$
		}); 
	}, 
	getItem : function(i) { 
		var me=this;
		if (JF.isNull(i)) {
			return;
		}
		var item=null; 
		if (typeof i == "number") { 
			item = this.items.value(i);
		}else if (typeof i == "string") { 
			item = this.items.get(i);
		}else {
			item=i;
		}  
		return item;
	}, 
	removeMenu : function(i) { 
		this.getItem(i).parent().remove(); 
		this.cfg.splice(i, 1);
		this.load(this.cfg);
	},
	getValue:function(){
		var rs=[];
		this.items.each(function(key, value, i, len, array){  
			if(value.hasClass("checked")){
				rs.push(value.data("value"));
			}
		});  
		return rs;
	},
	cancelAllMenu : function() { 
		this.items.each(function(key, value, i, len, array){  
			value.addClass("unchecked");
			value.removeClass("checked"); 
		});  
	},
	cancelSelectTabMenu : function(i) { 
		var item=this.getItem(i);  
		if(!JF.isValid(item)){
			return;
		}
		item.addClass("unchecked");
		item.removeClass("checked"); 
	},
	selectTabMenu : function(i) { 
		var item=this.getItem(i);  
		if(!JF.isValid(item)){
			return;
		}
		if(this.multi!=true){
			this.items.each(function(key, value, i, len, array){ 
				value.addClass("unchecked");
				value.removeClass("checked"); 
			});
			item.addClass("checked");
			item.removeClass("unchecked"); 
		}else if(this.multi==true){
			if(item.hasClass("checked")){ 
				item.addClass("unchecked");
				item.removeClass("checked"); 
			}else{ 
				if(JF.isValid(this.maxSize)){
					// 判断最大数
					if(this.getValue().length>=this.maxSize){
						return;
					}
				}
				item.addClass("checked");
				item.removeClass("unchecked"); 
			}
		} 
		
	},
	hideMenu : function(i) {
		this.getItem(i).hide();
	},
	showMenu : function(i) {
		this.getItem(i).show();
	},
	
	setText : function(i,text) { 
		this.getItem(i).find(".text").html(text);
	},
	
	readOnly:function(readonly){
		if(!JF.isValid(readonly)){
			readonly=true;
		}
		this.readonly=readonly;
	}
});


/*******************************************************************************
 * 选择平铺项
 */
JF.define("jf.ui.ChooseItems", {
	extend : jf.ui.GridBox,
	ChooseItems : function(args) {  
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg; 
		this.chooseItemsDraw();
	},
	chooseItemsDraw : function() {
		var me = this; 
		me.$ul.removeClass("box");
		me.$ul.addClass("box1"); 
	},
	 
});
/*******************************************************************************
 * 地址选择控件
 */
JF.define("jf.ui.AreaSelector", {
	extend : jf.ui.TextBox,
	AreaSelector : function(args) { 
		this.areaDraw();
	},
	areaDraw : function() {
		var me = this;

		var area1 = new LArea();
		new LArea().init({
			'trigger': "#"+this.id, // 触发选择控件的文本框，同时选择完毕后name属性输出到该位置
			// 'valueTo': '#addUser_area', //选择完毕后id属性输出到该位置
			'keys': {
				id: 'id',
				name: 'name'
			}, // 绑定数据源相关字段 id对应valueTo的value属性输出 name对应trigger的value属性输出
			'type': 1, // 数据源类型
			'data': LAreaData // 数据源
		});  
		this.readOnly(); 
	},
	setValue:function(a,b,c){
		if(JF.isValid(c)){
			this._setValue(a+","+b+","+c);
		}else{
			this._setValue(a+","+b);
		}
		
		this.prov = a;
		this.city = b;
		this.dist = c;
	}
 
});


/*******************************************************************************
 * 底部按钮工具栏
 */
JF.define("jf.ui.Bar", {
	extend : jf.ui.Component,
	Bar : function(args) {
		this.bar = args.bar;
		!args.type ? this.type = 0 : this.type = args.type; 
		!args.cfg ? this.cfg = [] : this.cfg = args.cfg; 
		this.build();
	},
	draw : function() {
		var me = this;
		var $bar = $('<div>');
		var barClass="bar h2 w-bgcolor";
		this.barBtnClass="bar-btn";
		if(me.type=="1"){
			barClass="bar1 w1-bgcolor h2";
			this.barBtnClass="bar-btn1";
		} 
		$bar.addClass(barClass); 
		var cfgLen = this.cfg.length;
		for (var i = 0; i < cfgLen; i++) {
			var c = me.cfg[i];
			var $btn = $('<div>');
			$btn.addClass(this.barBtnClass);
			$btn.attr("alias",c.alias);
			if(JF.isValid(c.float)){
				$btn.css("text-align",c.float); 
				$btn.css("line-height","15px"); 
			}else{
				$btn.addClass("middle");
			}
			if (!JF.isValid(c.className)) {
				$btn.addClass("main-bgcolor");
			} else {
				$btn.addClass(c.className);
			} 
			$btn.css("width",c.width); 
			if(JF.isValid(c.subText)){
				$btn.append("<p class='text'>"+c.text+"</p>"); 
				$btn.append("<p class='h3 subText'>"+c.subText+"</p>");
			}else if(JF.isValid(c.icon)){
				$btn.append("<p class='p-center icon h iconfont "+c.icon+"'></p>"); 
				$btn.append("<p class='p-center iconText h4'>"+c.iconText+"</p>");
			}else{ 
				$btn.append("<p class='text'>"+c.text+"</p>"); 
				$btn.append("<p class='h3 subText'></p>");	
			}
			
			$btn.data("fn", c.listener);
			tap($btn, function() { 
				$("body").find("input").blur();
				$("body").find("textarea").blur();
				$(this).data("fn").apply(me,[$btn]);
			});
			$bar.append($btn); 
		}
		setTimeout(function(){
			if (me.bar == "bottom") {
				$bar.css("position", "absolute"); 
				$bar.css("bottom", "-2px"); 
				me.container.find(".content-padded").css("padding-bottom",$bar.height()+1);
			} else if (me.bar == "top") {
				$bar.css("position", "absolute"); 
				$bar.css("top", "0px");  
				me.container.find(".content-padded").css("padding-top",$bar.height()+1);
			}
		});
		
		this.$ = $bar;
		this.bindObject = $bar;
		this.esseObject = $bar;
	},
	show : function() {
		this.$.show();
	},
	hide : function() {
		this.$.hide();
	},
	setWidth : function(i,w) {
		$(this.$.children("."+this.barBtnClass)[i]).css("width",w);
	},
	setText : function(i,text) {
		$(this.$.children("."+this.barBtnClass)[i]).children(".text").html(text);
	},
	setSubText : function(i,text) { 
		$(this.$.children("."+this.barBtnClass)[i]).children(".subText").html(text);
	},
	setIconText : function(i,text) { 
		$(this.$.children("."+this.barBtnClass)[i]).children(".iconText").html(text);
	},
	showBtn : function(i) {
		if (typeof i == "number" ) {
			$(this.$.children("."+this.barBtnClass)[i]).show();
		}else if(typeof i == "string"){
			$(this.$.children("."+this.barBtnClass).children("[alias="+i+"]")).show();
		}
		
	},
	hideBtn : function(i) {
		if (typeof i == "number" ) { 
			$(this.$.children("."+this.barBtnClass)[i]).hide();
		}else if(typeof i == "string"){ 
			this.$.children(".bar-btn[alias="+i+"]").hide();
		}
		
	}
});
/*******************************************************************************
 * 视频上传
 */
JF.define("jf.ui.VideoLoader", {
	extend : jf.ui.Component,
	VideoLoader : function(args) {  
		!args.maxSize ? this.maxSize = 10000000 : this.maxSize = args.maxSize;
		!args.size ? this.size = 1 : this.size = args.size;
		!args.aspectRatio ? this.aspectRatio = "1/1" : this.aspectRatio = args.aspectRatio;
		!args.imgH ? this.imgH = "200" : this.imgH = args.imgH;
		!args.imgW ? this.imgW = "200" : this.imgW = args.imgW;
		!args.desc ? this.desc = "推荐："+this.imgW+"px<font class='iconfont icon-cuowuguanbiquxiao'></font>"+this.imgH+"px" : this.desc = args.desc;
		!args.watermark ? this.watermark = "" : this.watermark = args.watermark;
		this.listener=args.listener;
		this.delListener=args.delListener;
		this.viewImage = new jf.ui.ViewImage({
			container : $("body"),
			items : []
		}); 
		this.build();
	},
	draw : function() {
		var me = this; 
		var $main = $('<div class="w-bgcolor">'); 
		this.$title = $('<div class="iconfont center icon-shangchuan hide padding2 font-color h3 w-bgcolor">'); 
		this.$title.html(this.desc);
		me.$input=$('<input type="file" accept="video/mp4" class="hide">');
		this.$titleUL = $('<ul class="parent"> '); 
	 
		var $descLI = $('<li class="list-view left w-bgcolor w2-color child3">');
		
		$descLI.append('<p class="h4 padding2 font-color">'
				+this.desc
				+'</p>');
		$descLI.append('<p class="h4 padding2">最大：'
				+this.maxSize/1000
				+' kb</p>');
		$descLI.append('<p class="h4 padding2">'
				+'最多：'+this.size+' 个视频'
				+'</p>');
		
		this.$addBtnText = $('<p class="h4 strong red-color ">'); 
		this.$addBtnText.html("选择视频");
		this.$addBtn = $('<li class="tap list-view center w2-bgcolor border7 radius3 child1">'); 
		this.$addBtn.append('<p class="icon-h2 iconfont icon-tianjiatupian red-color " ></span>');
		this.$addBtn.append(this.$addBtnText); 
		if(this.size>1){ 
			me.$input.attr("multiple","multiple");
		}
		me.$input[0].addEventListener('change', function() {
			var loading = new jf.ui.Loading({
				text : "加载视频<br/>将过滤掉超过<br/>"+me.maxSize/1000+"KB的视频"
			});
			loading.showBG();
			var hadSize=me.$listUL.find(".newimage").length;
			var len = this.files.length; 
			  
			for (var i = 0; i < len; i++) {
				if(i>me.size-1-hadSize){
					break;
				}
				var file = this.files[i];

				var oFReader = new FileReader();
				oFReader.readAsDataURL(file);
				oFReader.onload = function(oFREvent) {
					var url = oFREvent.target.result;
					var pre = "data:video/";
					var e = url.indexOf(";");
					var format = url.substring(pre.length, e);
					var size = oFREvent.total; 
					if (size > me.maxSize) {
						new jf.ui.Toast({
							text : "已过滤超过<br/>"+me.maxSize/1000/1000+"M视频",
							s : 2000
						}).show();
						return;
					}
					imgToBase64({
						src : "img/video.jpg", 
						format : "image/jpg",
						watermark:"视频",
					}, function(base64, size, img, w, h) {  
						img.video=url;
						me.createImg(img, "image/jpg");
					}) 
				};
			}
		
			loading.hide();  
			me.$input.val("");

		});
		this.$titleUL.append($descLI).append(this.$addBtn); 
		this.$listUL = $('<ul class="w-bgcolor center">');   
		
		$main.append(this.$title).append(this.$titleUL).append(this.$listUL).append(me.$input); 
		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;

		this.isDisabledAddBtn();
	},
	isDisabledAddBtn:function(){
		var me=this;
		var hadSize=this.$listUL.find(".newimage").length;  
		if (hadSize >= this.size) {
			this.$titleUL.hide();
			this.$title.show();
			this.$addBtn.unbind("tap");
			this.$addBtn.removeClass("main-bgcolor");
			this.$addBtn.addClass("w3-bgcolor");
		}else{
			this.$titleUL.show();
			this.$title.hide();
			this.$addBtn.unbind("tap");
			// 点击选择图片
			tap(this.$addBtn,function(){
				me.$input[0].click();
			});
			this.$addBtn.removeClass("w3-bgcolor");
			this.$addBtn.addClass("main-bgcolor");
		}
		this.$addBtnText.html("可上传"+(this.size-hadSize)+"个");
	},
	createImg : function(img, format) {
		var me = this;
		var size = me.size; 
		var WH = cauScale(me.imgW/3, me.imgH / 3, me.imgW, me.imgH);
 
		var $li = $('<li>');
		$li.css("width", "30%");
		$li.css("margin", "4px");
		$li.addClass("list-view inline center boxShadow"); 
		$(img).css("width", "98%");
		$(img).attr("w", me.imgW*2);
		$(img).attr("h", me.imgH*2);
		$(img).attr("format", format);
		$(img).addClass("newimage");
		$(img).attr("video", img.video);
		$li.append(img);

		var addBtn = me.$addBtn;
		var imgBox = me.$listUL;
		imgBox.append($li);
		
		this.isDisabledAddBtn();
		if(me.listener){
			me.listener.apply(me,[me]);
		}
		var $del = $("<span>");
		$del.addClass("iconfont icon-cuowuguanbiquxiao p-right p-top red-color white-font-border h");
		tap($del, function() {
			new jf.ui.Alert({
				type : 1,
				text : "您确定要删除该视频吗？",
				ok : function() {
					// 移除自己
					$del.parent().remove();
					var img = imgBox.find(".newimage");
					var len = img.length;
					if (len < size) {
						me.isDisabledAddBtn();
					}
					for (var i = 0; i <= len; i++) {
						$(img[i]).attr("i", (i));
					}
					if(me.delListener){
						me.delListener.apply(me,[me]);
					}
				}
			});
		});
		$li.append($del); 
	},  
	click : function() {
		var me = this; 
		me.$input[0].click();
	},
	upload : function(files,success,error,loading) {
		var me = this;
		var loading = new jf.ui.Loading({
			text : "上传视频"
		});
		if(JF.isNull(loading)||loading==true){
			loading.showBG();
		}
		var upload = new jf.util.Upload();
		upload.upload(files, function(rs) {
			if(JF.isNull(loading)||loading==true){
				loading.hide();
			}
			if (success)
				success();
		}, function(data) {
			if(JF.isNull(loading)||loading==true){
				loading.hide();
			}
			if (error)
				error();
		});
	},
	getValue:function(filePath,dir){
		var me=this;  
		!filePath ? filePath = "temp" : true;
		!dir ? dir = "img" : true;
		var list=this.$listUL.find(".newimage");
		var path = ""; 
		var files = [];
		
		var len=list.length;
		for (var i = 0; i < len; i++) {
			var img=list[i];
			var fileName = randomNum(1000, 9999) + "_" + i;
			path += dir+"/" + filePath + "/" + fileName + "." + "mp4" + ","; 
			files.push({
				file : $(img).attr("video"),
				filePath : filePath,
				fileName : fileName,
				fileSuffix : "mp4",
				isCompress : false,
				width : me.imgW,
				height : me.imgH,
			});
		}
		path = path.substring(0, path.length - 1);
		
		return {
			files:files,
			path:path
		}
	},
	isSelected:function(){
		var me=this;
		var list=this.$listUL.find(".newimage");
		if (list.length == 0) { 
			return false;
		}else{
			return true;
		}
	}
});
/*******************************************************************************
 * 图片上传
 */
JF.define("jf.ui.ImgLoader", {
	extend : jf.ui.Component,
	ImgLoader : function(args) {  
		!args.maxSize ? this.maxSize = 1000000 : this.maxSize = args.maxSize;
		!args.size ? this.size = 1 : this.size = args.size;
		!args.aspectRatio ? this.aspectRatio = "1/1" : this.aspectRatio = args.aspectRatio;
		!args.imgH ? this.imgH = "200" : this.imgH = args.imgH;
		!args.imgW ? this.imgW = "200" : this.imgW = args.imgW;
		!args.desc ? this.desc = "推荐："+this.imgW+"px<font class='iconfont icon-cuowuguanbiquxiao'></font>"+this.imgH+"px" : this.desc = args.desc;
		!args.watermark ? this.watermark = "" : this.watermark = args.watermark;
		JF.isNull(args.isCut) ? this.isCut =false : this.isCut = args.isCut; 
		!args.mode ? this.mode = 0 : this.mode = args.mode;
		this.selectedlistener=args.selectedlistener;
		this.delListener=args.delListener;
		this.viewImage = new jf.ui.ViewImage({
			container : $("body"),
			items : []
		});
		
		this.build();
	},
	draw : function() {
		var me = this; 
		var $main = $('<div class="w-bgcolor">'); 
		this.$title = $('<div class="iconfont center icon-shangchuan hide padding2 font-color h3 w-bgcolor">'); 
		this.$title.html(this.desc);
		me.$input=$('<input type="file" accept="image/png,image/jpeg,image/gif" class="hide">');
		this.$titleUL = $('<ul class="parent"> '); 
	 
		var $descLI = $('<li class="list-view left w-bgcolor w2-color child3">');
		
		$descLI.append('<p class="h4 padding2 font-color">'
				+this.desc
				+'</p>');
		$descLI.append('<p class="h4 padding2">最大：'
				+this.maxSize/1000
				+' kb</p>');
		$descLI.append('<p class="h4 padding2">'
				+'最多：'+this.size+' 张'
				+'</p>');
		
		this.$addBtnText = $('<p class="h4 strong red-color ">'); 
		this.$addBtnText.html("选择图片");
		this.$addBtn = $('<li class="tap list-view center w2-bgcolor border7 radius3 child1">'); 
		this.$addBtn.append('<p class="icon-h2 iconfont icon-tianjiatupian red-color" ></span>');
		this.$addBtn.append(this.$addBtnText); 
		if(this.size>1&&!me.isCut){ 
			me.$input.attr("multiple","multiple");
		}
		me.$input[0].addEventListener('change', function() {
			var loading = new jf.ui.Loading({
				text : "加载图片<br/>将过滤掉超过<br/>"+me.maxSize/1000+"KB的图片"
			});
			loading.showBG();
			var hadSize=me.$listUL.find(".newimage").length;
			var len = this.files.length; 
			if(len==1&&me.isCut){
				loader.openWin({
					name : "editImage",
					data:{
						file:this.files[0],
						aspectRatio: me.aspectRatio, 
						w:me.imgW,
						h:me.imgH,
						maxSize:me.maxSize,
						watermark:me.watermark,
						callback : function(img, sub) {
							me.createImg(img, sub); 
						}
					}
				});  
			}else if((me.size>1||!me.isCut)){  
				for (var i = 0; i < len; i++) {
					if(i>me.size-1-hadSize){
						break;
					}
					var file = this.files[i];

					var oFReader = new FileReader();
					oFReader.readAsDataURL(file);
					oFReader.onload = function(oFREvent) {
						var url = oFREvent.target.result;
						var pre = "data:image/";
						var e = url.indexOf(";");
						var format = url.substring(pre.length, e);

						if(format==""){
							
						}
						var size = oFREvent.total; 
						if (size > me.maxSize) {
							new jf.ui.Toast({
								text : "已过滤超过<br/>"+me.maxSize/1000+"KB图片",
								s : 2000
							}).show();
							return;
						}
						imgToBase64({
							src : url, 
							format : format,
							watermark:me.watermark,
						}, function(base64, size, img, w, h) {  
							me.createImg(img, format);
						}) 
					};
				}
			} 
			loading.hide();  
			me.$input.val("");

		});
		this.$titleUL.append($descLI).append(this.$addBtn); 
		this.$listUL = $('<ul class="w-bgcolor center">');   
		
		$main.append(this.$title).append(this.$titleUL).append(this.$listUL).append(me.$input); 
		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;

		this.isDisabledAddBtn();
	},
	isDisabledAddBtn:function(){
		var me=this;
		var hadSize=this.$listUL.find(".newimage").length;  
		if (hadSize >= this.size) {
			this.$titleUL.hide();
			this.$title.show();
			this.$addBtn.unbind("tap");
			this.$addBtn.removeClass("main-bgcolor");
			this.$addBtn.addClass("w3-bgcolor");
		}else{
			this.$titleUL.show();
			this.$title.hide();
			this.$addBtn.unbind("tap");
			// 点击选择图片
			tap(this.$addBtn,function(){
				if(isWeixin()){ 
					wx.chooseImage({
						count: me.size, // 默认9
						sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
						sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
						success: function (res) {
							var localIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
							// alert(JSON.stringify(res));
							var loading = new jf.ui.Loading({
								text : "加载图片<br/>将过滤掉超过<br/>"+me.maxSize/1000+"KB的图片"
							});
							loading.showBG();
							var hadSize=me.$listUL.find(".newimage").length;
							var len = localIds.length; 
							if(len==1&&me.isCut){
								wx.getLocalImgData({
									localId: localIds[0], // 图片的localID
									success: function (res) { 
										var localData = res.localData; // localData是图片的base64数据，可以用img标签显示
										
										var url = localData;
										var pre = "data:image/";
										if(url.indexOf(pre)==-1){
											url=pre+"jgp;base64,"+url;
										}
										
										loader.openWin({
											name : "editImage",
											data:{
												imgData:url,
												aspectRatio: me.aspectRatio, 
												w:me.imgW,
												h:me.imgH,
												maxSize:me.maxSize,
												watermark:me.watermark,
												callback : function(img, sub) {
													me.createImg(img, sub); 
												}
											}
										});
									}
								}); 
							}else if((me.size>1||!me.isCut)){   
								
								for (var i = 0; i < len; i++) {
									if(i>me.size-1-hadSize){
										break;
									} 

									wx.getLocalImgData({
										localId: localIds[i],
										success: function (res) { 
											var localData = res.localData; 
											
											var url = localData;
											var pre = "data:image/";
											if(url.indexOf(pre)==-1){
												url=pre+"jgp;base64,"+url;
											}
											var e = url.indexOf(";");
											var format = url.substring(pre.length, e);
											
											var base64 = url; 
											var pre="data:image/"+format+";base64,";
											var str=base64.substring(pre.length);
											var equalIndex= str.indexOf('=');
											if(str.indexOf('=')>0)
											{
											    str=str.substring(0, equalIndex);
											}
											var strLength=str.length;
											var fileLength=parseInt(strLength-(strLength/8)*2); 
											
											var size = fileLength; 
											if (size > me.maxSize) {
												new jf.ui.Toast({
													text : "已过滤超过<br/>"+me.maxSize/1000+"KB图片",
													s : 2000
												}).show();
												return;
											}
											imgToBase64({
												src : url, 
												format : format,
												watermark:me.watermark,
											}, function(base64, size, img, w, h) {  
												me.createImg(img, format);
											}) 
										}
									}); 
								}
							} 
							loading.hide();    
						}
					});
				}else{ 
					me.$input[0].click();
				}
				
			});
			this.$addBtn.removeClass("w3-bgcolor");
			this.$addBtn.addClass("main-bgcolor");
		}
		this.$addBtnText.html("可上传"+(this.size-hadSize)+"张");
	},
	createImg : function(img, format) {
		var me = this;
		var size = me.size; 
		var WH = cauScale(me.imgW/3, me.imgH / 3, me.imgW, me.imgH);
 
		var $li = $('<li>');
		$li.css("width", "30%");
		$li.css("margin", "4px");
		$li.addClass("list-view inline center boxShadow"); 
		$(img).css("width", "98%");
		$(img).attr("w", me.imgW*2);
		$(img).attr("h", me.imgH*2);
		$(img).attr("format", format);
		$(img).addClass("newimage");
		$li.append(img);

		var addBtn = me.$addBtn;
		var imgBox = me.$listUL;
		imgBox.append($li);
		
		this.isDisabledAddBtn();
		if(me.selectedListener){
			me.selectedListener.apply(me,[me]);
		}
		var $del = $("<span>");
		$del.addClass("iconfont icon-cuowuguanbiquxiao p-right p-top red-color white-font-border h");
		tap($del, function() {
			new jf.ui.Alert({
				type : 1,
				text : "您确定要删除该图片吗？",
				ok : function() {
					// 移除自己
					$del.parent().remove();
					var img = imgBox.find(".newimage");
					var len = img.length;
					if (len < size) {
						me.isDisabledAddBtn();
					}
					for (var i = 0; i <= len; i++) {
						$(img[i]).attr("i", (i));
					}
					if(me.delListener){
						me.delListener.apply(me,[me]);
					}
				}
			});
		});
		$li.append($del);
		if(JF.isValid(me.viewImage)){
			me.viewImageInit($li, imgBox);
		}
		
	}, 
	viewImageInit : function(obj, imgBox) {
		var me = this;
		var img = imgBox.find(".newimage");
		var len = img.length;
		for (var i = 0; i < len; i++) {
			$(img[i]).attr("i", (i));
		}
 
		tap(obj, function() { 
			var img = imgBox.find(".newimage");
			var len = img.length;
			var items = [];
			for (var i = 0; i < len; i++) {
				items.push({
					src : $(img[i]).attr("src"),
					w : $(img[i]).attr("w"),
					h : $(img[i]).attr("h")
				});
			}
			var i = obj.find("img").attr("i");
			me.viewImage.show(parseInt(i), items);
		});
	}, 
	click : function() {
		var me = this; 
		me.$input[0].click();
	},
	upload : function(files,success,error,loading) {
		var me = this;
		var loading = new jf.ui.Loading({
			text : "上传图片"
		});
		if(JF.isNull(loading)||loading==true){
			loading.showBG();
		}
		var upload = new jf.util.Upload();
		upload.upload(files, function(rs) {
			if(JF.isNull(loading)||loading==true){
				loading.hide();
			}
			if (success)
				success();
		}, function(data) {
			if(JF.isNull(loading)||loading==true){
				loading.hide();
			}
			if (error)
				error();
		});
	},
	getValue:function(filePath,dir){
		var me=this;  
		!filePath ? filePath = "temp" : true;
		!dir ? dir = "img" : true;
		var list=this.$listUL.find(".newimage");
		var path = ""; 
		var files = [];
		
		var len=list.length;
		for (var i = 0; i < len; i++) {
			var img=list[i];
			var fileName = randomNum(1000, 9999) + "_" + i;
			path += dir+"/" + filePath + "/" + fileName + "." + $(img).attr("format") + ","; 
			files.push({
				file : $(img).attr("src"),
				filePath : filePath,
				fileName : fileName,
				fileSuffix : $(img).attr("format"),
				isCompress : false,
				width : me.imgW,
				height : me.imgH,
			});
		}
		path = path.substring(0, path.length - 1);
		
		return {
			files:files,
			path:path
		}
	},
	isSelected:function(){
		var me=this;
		var list=this.$listUL.find(".newimage");
		if (list.length == 0) { 
			return false;
		}else{
			return true;
		}
	}
});
/*******************************************************************************
 * 背景遮罩
 */
JF.define("jf.ui.BG", {
	extend : jf.ui.Component,
	BG : function(args) { 
		this.container = $("body");
		this.build();
	},
	draw : function() {
		var me = this;

		var had = this.container.find(".BG");
		if (!JF.isNull(had[0])) {
			had.remove();
		}

		var $bar = $('<div>');
		$bar.addClass("BG");
		$bar.css("background",this.bg) ;
		this.$ = $bar;
		this.bindObject = $bar;
		this.esseObject = $bar;
	},
	show : function() {
		this.$.fadeIn();
	},
	hide : function() {
		this.$.fadeOut();
	}, 
});
/*******************************************************************************
 * 无数据提示
 */
JF.define("jf.ui.NoData", {
	extend : jf.ui.Component,
	NoData : function(args) { 
		!args.text ? this.text = "暂无数据" : this.text = args.text;
		!args.icon ? this.icon = "iconfont icon-zanwushuju" : this.icon = args.icon;
		!args.noicon ? this.noicon = false : this.noicon = args.noicon;
		!args.color ? this.color = "" : this.color = args.color;
		!args.bg ? this.bg = "" : this.bg = args.bg;
		
		this.build();
	},
	draw : function() {
		var me = this; 
		var $main = $('<div>');
		$main.addClass("img-bgcolor center w2-color marginline"); 
		$main.css("color",this.color);
		$main.css("background",this.bg);
		$main.append("<br/><br/><br/>");
		var $icon = $('<img>');
		$icon.attr("src","img/noData.jpg");  
		$icon.addClass("w2 circle boxShadow");  
		var $text = $('<p>'); 
//		$text.html(this.text);  
//		$text.css("color",this.color);
		if(this.noicon==false){
			$main.append($icon);
		}
		$main.append($text); 
		
		if(JF.isValid(this.container)){
			this.container.html("");
			this.container.append($main);
		}
		
		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;
	}

});
/*******************************************************************************
 * 图片浏览器
 */
JF.define("jf.ui.ViewImage", {
	extend : jf.ui.Component,
	ViewImage : function(args) {
		!args.items ? this.items = [] : this.items = args.items;
		this.build();
	},
	draw : function() {
		var me = this;
		var $pswp = $(".pswp");
		if (JF.isValid($pswp[0])) {
			  // $pswp.remove();
		}
		// ///////////////第一层/////////////////
		this.$pswp = $('<div>');
		this.$pswp.addClass("pswp");
		this.$pswp.addClass(this.id);
		this.$pswp.attr("tabindex", "-1");
		this.$pswp.attr("role", "dialog");
		this.$pswp.attr("aria-hidden", "true");

		var $pswp__bg = $('<div>');
		$pswp__bg.addClass("pswp__bg");

		var $pswp__scroll_wrap = $('<div>');
		$pswp__scroll_wrap.addClass("pswp__scroll-wrap");

		this.$pswp.append($pswp__bg).append($pswp__scroll_wrap);

		// ///////////////第二层/////////////////

		var $pswp__container = $('<div>');
		$pswp__container.addClass("pswp__container");

		var $pswp__ui_pswp__ui__hidden = $('<div>');
		$pswp__ui_pswp__ui__hidden.addClass("pswp__ui pswp__ui--hidden");

		$pswp__scroll_wrap.append($pswp__container).append($pswp__ui_pswp__ui__hidden);

		// ///////////////第三层/////////////////

		var $pswp__item1 = $('<div>');
		$pswp__item1.addClass("pswp__item");

		var $pswp__item2 = $('<div>');
		$pswp__item2.addClass("pswp__item");

		var $pswp__item3 = $('<div>');
		$pswp__item3.addClass("pswp__item");

		$pswp__container.append($pswp__item1).append($pswp__item2).append($pswp__item3);

		var $pswp__top_bar = $('<div>');
		$pswp__top_bar.addClass("pswp__top-bar");

		var $pswp__share_modal = $('<div>');
		$pswp__share_modal.addClass("pswp__share-modal pswp__share-modal--hidden pswp__single-tap");

		var $pswp__share_tooltip = $('<div>');
		$pswp__share_tooltip.addClass("pswp__share-tooltip");
		$pswp__share_modal.append($pswp__share_tooltip);

		var $pswp__button_pswp__button__arrow__left = $('<button>');
		$pswp__button_pswp__button__arrow__left.addClass("pswp__button pswp__button--arrow--left");
		$pswp__button_pswp__button__arrow__left.attr("title", "Previous (arrow left)");

		var $pswp__button_pswp__button__arrow__right = $('<button>');
		$pswp__button_pswp__button__arrow__right.addClass("pswp__button pswp__button--arrow--right");
		$pswp__button_pswp__button__arrow__right.attr("title", "Next (arrow right)");

		var $pswp__caption = $('<div>');
		$pswp__caption.addClass("pswp__caption");

		$pswp__ui_pswp__ui__hidden.append($pswp__top_bar).append($pswp__share_modal).append(
				$pswp__button_pswp__button__arrow__left).append($pswp__button_pswp__button__arrow__right).append(
				$pswp__caption);

		// ///////////////第四层/////////////////

		var $pswp__counter = $('<div>');
		$pswp__counter.addClass("pswp__counter");

		var $pswp__button_pswp__button__close = $('<button>');
		$pswp__button_pswp__button__close.addClass("pswp__button pswp__button--close");

		var $pswp__preloader = $('<div>');
		$pswp__preloader.addClass("pswp__preloader");

		var $pswp__preloader__icn = $('<div>');
		$pswp__preloader__icn.addClass("pswp__preloader__icn");
		$pswp__preloader.append($pswp__preloader__icn);

		var $pswp__preloader__cut = $('<div>');
		$pswp__preloader__cut.addClass("pswp__preloader__cut");
		$pswp__preloader__icn.append($pswp__preloader__cut);

		var $pswp__preloader__donut = $('<div>');
		$pswp__preloader__donut.addClass("pswp__preloader__donut");
		$pswp__preloader__cut.append($pswp__preloader__donut);

		$pswp__top_bar.append($pswp__counter).append($pswp__button_pswp__button__close).append($pswp__preloader);

		var $pswp__caption__center = $('<div>');
		$pswp__caption__center.addClass("pswp__caption__center");

		$pswp__caption.append($pswp__caption__center);

		this.$ = this.$pswp;
		this.bindObject = this.$pswp;
		this.esseObject = this.$pswp;
	},
	show : function(i, items) {
		// http://www.cnblogs.com/jiangxiaobo/p/5695947.html
		var pics = [];
		if (JF.isValid(items)) {
			pics = items;
		} else {
			pics = this.args.items;
		}
		this.gallery = new PhotoSwipe(this.$pswp[0], PhotoSwipeUI_Default, pics, {
			history : false,
			focus : false,
			showAnimationDuration : 0,
			hideAnimationDuration : 0
		});
		this.gallery.init();
		if (JF.isValid(i)) {
			this.gallery.goTo(i);
		}
	},
	distory:function(){
		// console.log($(".pswp["+this.id+"]"));
		$(".pswp["+this.id+"]").remove();
	},
	goto : function(i) {
		this.gallery.goTo(i);
	}
});

/*******************************************************************************
 * 弹出活动层
 */
JF.define("jf.ui.ActivityPanel", {
	extend : jf.ui.Component,
	ActivityPanel : function(args) {
		this.targetFrame = args.targetFrame;
		this.img = args.img;
		this.imgBorderCss = args.imgBorderCss;
		this.closeImg = args.closeImg;
		!args.isHideAlertImg ? this.isHideAlertImg =false : this.isHideAlertImg = args.isHideAlertImg;
		!args.isHideAlertBG ? this.isHideAlertBG =false : this.isHideAlertBG = args.isHideAlertBG;
		!args.width ? this.width ="60%" : this.width = args.width;
		!args.imgText ? this.html ="" : this.imgText = args.imgText;
		!args.html ? this.html ="" : this.html = args.html;
		!args.title ? this.title ="" : this.title = args.title;
		this.param = args.param;
		this.container=$("body");
		this.build();  
	},
	draw : function() {
		var me = this;
		var $main = $('<div>');
		$main.addClass("bgDiv center");
		$main.css("z-index",9999);
		 
		var $first = $('<div>'); 
		this.$firstImg = $('<img>');
		this.$firstImg.addClass(this.imgBorderCss);
		this.$firstImg.attr("width",this.width);
		
		this.$firstImgText = $('<div>');
		this.$firstImgText.html(this.imgText);
		this.$firstImgText.addClass("p-center");
		this.$margin=$('<br/><br/>');
		$first.append(this.$margin).append(this.$firstImg).append(this.$firstImgText);
		
		var $second = $('<div>'); 
		$second.css("padding","0px");
		this.$closeImg = $('<img>'); 
		this.$closeImg.attr("width","10%");
		this.$closeImg.addClass("marginline");
		$second.append(this.$closeImg); 
		
		var $third = $('<div>'); 
		$third.css("padding","0px");
		this.$thirdImg = $('<img>');  
		this.$thirdImg.attr("width","48%");
		this.$thirdImg.addClass("p-center boxShadow");
		$third.append(this.$thirdImg); 
		
		this.$body = $('<div>'); 
		this.$body.addClass("radius1 padding1 w-bgcolor"); 
		this.$body.css("max-height","70%");
		this.$body.css("margin","10%");
		
		this.$textBody = $('<div>'); 
		this.$textBody.addClass("img-color middle"); 
		this.$textBody.css("position","relative"); 
		this.$textBody.css("overflow-x","hidden");
		this.$textBody.css("overflow","auto"); 
		this.$textBody.css("max-height","50%");
		this.$textBodyUl = $('<ul>'); 
		this.$textBodyLi = $('<li>');  
		this.$textBodyLi.addClass("w-bgcolor"); 
		this.$textBodyUl.append(this.$textBodyLi);
		this.$textBody.append(this.$textBodyUl);
		
		this.$textBodyTitle= $('<div>'); 
		this.$textBodyTitle.addClass("p-center w1"); 
		this.$textBodyTitle.css("top","0px"); 
		this.$textBodyTitle.attr("src","img/title.png");  
		
		this.$textBodyTitleImg= $('<img>');  
		this.$textBodyTitleImg.addClass("p-left  "); 
		this.$textBodyTitleImg.css("left","-5%"); 
		this.$textBodyTitleImg.css("z-index","100"); 
		this.$textBodyTitleImg.css("top","-2%");
		this.$textBodyTitle.css("left","-109%"); 
		this.$textBodyTitleImg.css("width","30%"); 
		this.$textBodyTitleImg.attr("src","img/alertImg.png"); 
		if(this.isHideAlertImg){
			this.$textBodyTitleImg.hide();
		}
		
		$main.append(this.$textBodyTitleImg)  
		this.$textBody.append(this.$textBodyTitle);
		
		this.$text = $('<div>');  
		this.$text.css("margin","0px 14px 0px 14px");  
		this.$text.addClass("left h3 w-bgcolor padding1"); 
		if(this.isHideAlertBG){ 
			this.$body.removeClass("w-bgcolor");
			this.$body.addClass("img-bgcolor");
			this.$textBodyLi.removeClass("w-bgcolor");
			this.$textBodyLi.addClass("img-bgcolor");
			this.$text.removeClass("w-bgcolor");
			this.$text.addClass("img-bgcolor w-color strong middle");
		}
		this.$text.html(this.html);
		this.$textBodyLi.append(this.$text);
		
		me.scrollstop = new jf.ui.Scrollstop({
			target : this.$textBody
		});
		this.$body.append(this.$textBody); 
		$main.append($first).append(this.$body).append($third).append($second); 
		
		tap($first,function(){
			if(me.listener){
				me.listener.apply(me);
			}
		});
		tap($second,function(){
			me.scrollstop.myScroll.refresh();
			me.scrollstop.myScroll.scrollTo(0, 0, 300);// 置顶
			if(me.closeListener){
				me.closeListener.apply(me);
			}else{
				me.hide();
			}
		});
		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;
	},
	setListener:function(fn){
		this.listener = fn;
	},
	setCloseListener:function(fn){
		this.closeListener = fn;
	},
	setImg:function(src){
		this.img = src; 
	},
	setImg2:function(src){
		this.img2 = src; 
	},
	setHtml:function(text){
		this.html = text; 
		this.$text.html(this.html);
	},
	setCloseImg:function(src){
		this.closeImg = src;
	},
	setParam:function(param){
		this.param = param;
	},
	show:function(src){
		if(JF.isValid(this.closeImg)){
			this.$closeImg.attr("src",this.closeImg);
		}else{
			this.$closeImg.hide();
		}
		if(JF.isValid(this.img)){
			this.$firstImg.attr("src",this.img);
		}else{
			this.$firstImg.hide();
		}
		if(JF.isValid(this.img2)){
			this.$thirdImg.attr("src",this.img2);
		}else{
			this.$thirdImg.hide();
		} 
		if(JF.isValid(this.html)){
			this.$body.show();
		}else{
			this.$body.hide();
		}
		this.$.show();
	}
});
 
/*******************************************************************************
 * 页面操作向导
 */
JF.define("jf.ui.Guide", {
	extend : jf.ui.Component,
	Guide : function(args) { 
		!args.cfg ? this.cfg =[] : this.cfg = args.cfg;
		this.build();
	},
	draw : function() {
		var me = this; 
		var $main = $('<div>');
		
		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;
	},
	def : {
		title : "当前步骤",
		text : "这里是向导文本"
	},
	name : "D" + new Date().getTime(),
	g : new Array(),
	gn : 0,
	s : 0,
	created : false,
	create : function() {
		var _this = this;
		_this.created = true;
		_this.ele = $("<div id='wlGuide_box" + _this.name + "' class='cGuide_box'><span class='cGuide_arrow'></span></div>");
		_this.blank = {
			t : $("<div class='cGuide_blank_t'></div>"),
			r : $("<div class='cGuide_blank_r'></div>"),
			b : $("<div class='cGuide_blank_b'></div>"),
			l : $("<div class='cGuide_blank_l'></div>")
		};
		_this.blank_all = $("<div class='cGuide_blank'></div>").append(_this.blank.t, _this.blank.r, _this.blank.b, _this.blank.l);
		_this.content = $("<div class='cGuide_content'></div>");
		_this.title = $("<h2 class='cGuide_title'></h2>");
		_this.scount = $("<span class='cGuide_scount'></span>");
		_this.text = $("<p></p>");
		_this.button = {
			p : tap($("<a href='javascript:void(0)' class='cGuide_button'>上一步</a>'"), function() {
				if (!$(this).hasClass("cGuide_button_unable")) {
					_this.step(-1)
				}
			}, true),
			n : tap($("<a href='javascript:void(0)' class='cGuide_button'>下一步</a>'"), function() {
				if (!$(this).hasClass("cGuide_button_unable")) {
					_this.step(1)
				}
			}, true),
			c : tap($("<a href='javascript:void(0)' class='cGuide_button'>关闭</a>'"), function() {
				if (!$(this).hasClass("cGuide_button_unable")) {
					_this.close();
				}
			}, true)
		};
		
		$("body").prepend(_this.blank_all, _this.ele.append(_this.content.append(_this.title, _this.scount, $("<div  class='cGuide_content_text'></div>").append(_this.text), _this.button.p, _this.button.n, _this.button.c)))
		
	},
	step : function(i) {
		var _this = this;
		var ind = _this.s += i;
		if (ind > _this.gn) {
			ind = _this.s = _this.gn;
			return false
		} else if (ind < 1) {
			ind = _this.s = 1;
			return false
		}
		_this.button.p.attr("class", ind === 1 ? "cGuide_button_unable" : "cGuide_button");
		_this.button.n.attr("class", ind === _this.gn ? "cGuide_button_unable" : "cGuide_button");
		_this.button.c.attr("class", ind === _this.gn ? "cGuide_button" : "cGuide_button");
		if (_this.g[ind]) {
			_this.ele.hide();
			_this.title.html(_this.g[ind].title);
			_this.scount.html("(" + ind + "/" + _this.gn + ")");
			_this.text.html(_this.g[ind].text);
			var obj = $(_this.g[ind].ele);
			var bfs = {
				left : 0,
				top : 0
			};
			var ofs = obj.offset();
			var h = obj.outerHeight();
			var w = obj.outerWidth();
			var wc = Array($(document).width(), $(document).height());
			var sc = {
				left : obj.scrollLeft(),
				top : obj.scrollTop()
			};
			if ($("body").width() < (ofs.left + _this.ele.width())) {
				_this.ele.css({
					left : ofs.left - _this.ele.width() + obj.width(),
					top : ofs.top + h + 25,
				});
				_this.ele.find(".cGuide_arrow").css("left", (_this.ele.width() - obj.width() / 1.3) + "px");
			} else {
				_this.ele.css({
					left : ofs.left,
					top : ofs.top + h + 25
				});
				_this.ele.find(".cGuide_arrow").css("left", "10px");
			}

			_this.blank.t.css({
				width : wc[0],
				height : ofs.top - 1,
				left : 0,
				top : 0
			});
			_this.blank.r.css({
				height : h + 2,
				width : wc[0] - ofs.left - w - 1,
				left : ofs.left + w + 1,
				top : ofs.top - 1 + sc.top
			});
			var bHeight = wc[1] - ofs.top - h - 1;
			bHeight = bHeight > _this.ele.outerHeight() + 20 ? bHeight : _this.ele.outerHeight() + 20;
			_this.blank.b.css({
				width : wc[0],
				height : bHeight,
				left : 0,
				top : ofs.top + h + 1 + sc.top
			});
			_this.blank.l.css({
				height : h + 2,
				width : ofs.left - 1,
				left : 0,
				top : ofs.top - 1 + sc.top
			});
			var toTop = 0;
			var toBottom = ofs.top + _this.ele.outerHeight() + 20;
			while (toBottom - toTop > $(window).height()) {
				toTop += 200
			}
			$("html,body").animate({
				scrollTop : toTop
			}, 200);

			/** 支持每个步骤的回调函数: added by malinjie66@126.com 2014-3-21* */
			if (undefined != _this.g[ind].action)
				_this.g[ind].action();

			_this.ele.show()
		}
	},
	setCfg:function(cfg){
		this.cfg =cfg;
	},
	show : function(callback) {
		var _this = this;
		setTimeout(function(){
			if (!_this.created) {
				_this.create()
			} 
			_this.blank_all.show().find("div").css({
				opacity : "0.5"
			});
			_this.ele.fadeIn();
			_this.s = _this.gn = 0;
			_this.g = new Array();
			$.each(_this.cfg, function(i, e) {
				_this.g[i + 1] = $.extend({}, _this.def, e);
				_this.gn++
			});
			_this.func = callback;
			/** 支持步骤末尾的回调函数: added by malinjie66@126.com 2014-3-21* */
			_this.step(1)
		},800);
		
	},
	close : function() {
		var _this = this;
		if(_this.ele&&!_this.ele.is(":hidden")){ 
			_this.ele.hide();
			_this.blank_all.hide();
			_this.func();
		}
	}
});

/*******************************************************************************
 * 倒计时器
 */
JF.define("jf.ui.CountDownTimer", {
	extend : jf.ui.Component,
	CountDownTimer : function(args) {
		!args.color ? this.color = "#fff" : this.color = args.color;
		!args.tcolor ? this.tcolor = "#fff" : this.tcolor = args.tcolor;
		!args.beforeListener ? this.beforeListener = function() {
		} : this.beforeListener = args.beforeListener;// 事件
		this.param = args.param; 
		this.build();
	},
	draw : function() {
		var me = this;
		var $main = $('<div>');
		function checkTime(i) { // 将0-9的数字前面加上0，例1变为01
			if (i < 10) {
				i = "0" + i;
			}
			return i;
		}
		var initDateUI=function(ui,days,hours,minutes,seconds,mms){
			var d="<input dd readonly='readonly' class='center w-bgcolor red-color padding1 radius2' value='"+days + "'/>";
			var h="<input hh readonly='readonly' class='center w-bgcolor red-color padding1 radius2' value='"+hours + "'/>";
			var m="<input mmm readonly='readonly' class='center w-bgcolor red-color padding1 radius2' value='"+minutes + "'/>";
			var s="<input ss readonly='readonly' class='center w-bgcolor red-color  padding1 radius2' value='"+seconds + "'/>";
			var mm="<input mm value='"+mms + "' readonly='readonly' class=' orange-color center w-bgcolor padding1 radius2'/>";
			ui.html(d+"<font style='color:"+me.tcolor+"'>天</font>"+h + "<font style='color:"+me.tcolor+"'>:</font>" + m + "<font style='color:"+me.tcolor+"'>:</font>" + s+ "<font style='color:"+me.tcolor+"'>:</font>"+mm + "");
		}
		this.container.each(function() { 
			var $c = $(this);
			var $timer = $('<div style="position:relative;">');
			$timer.addClass("countDownTimer");
			$timer.addClass("center radius");
			$timer.css("color",me.color);
			var $title = $('<font class="h2 strong">距结束还剩</font>');
			$title.css("color",me.tcolor);
			$title.hide();
			var $time = $('<p  class="h4"></p>');
			initDateUI($time,"00","00","00","00","00");
			$timer.append($title).append($time); 
			// 倒计时
			var ordertimer = null;
			var mmtimer = null;
			
			var data = new Date();
			function leftTimer(enddate) {
				var leftTime = (new Date(enddate)) - new Date(); // 计算剩余的毫秒数
				var days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10); // 计算剩余的天数
				var hours = parseInt(leftTime / 1000 / 60 / 60 % 24, 10); // 计算剩余的小时
				var minutes = parseInt(leftTime / 1000 / 60 % 60, 10);// 计算剩余的分钟
				var seconds = parseInt(leftTime / 1000 % 60, 10);// 计算剩余的秒数
				var mm = 10;// 计算剩余的豪秒数
				days = checkTime(days);
				hours = checkTime(hours);
				minutes = checkTime(minutes);
				seconds = checkTime(seconds);  
				if (days >= 0 || hours >= 0 || minutes >= 0 || seconds >= 0) { 
					// initDateUI($time,days,hours,minutes,seconds,mm);
					$time.find("[dd]").val(days);
					$time.find("[mmm]").val(minutes);
					$time.find("[hh]").val(hours);
					$time.find("[ss]").val(seconds);
				}
				if (days <= 0 && hours <= 0 && minutes <= 0 && seconds <= 0) {
					window.clearInterval(ordertimer);
					window.clearInterval(mmtimer);
					ordertimer = null;
					mmtimer=null;
					$title.html("已经结束");
					$time.find("input").removeClass("blue-bgcolor btn-orange w-color");
					$time.find("input").addClass("w2-bgcolor w1-color");
					if (me.listener)
						me.listener($c);
				}
			}
			function go(s,v,o,p) { 
				 
				var date1 = new Date(), data2 = new Date(parseInt(v)), data3 = new Date(parseInt(s));
				if (o==1||data2 < date1) {
					$title.html("已经结束");
					$time.find("input").removeClass("blue-bgcolor btn-orange w-color");
					$time.find("input").addClass("w2-bgcolor w1-color"); 
					if (me.listener)
						me.listener($c);
					return;
				}else if (o==1||data3 > date1) { 
					$title.html("未开始");
					$time.find("input").removeClass("blue-bgcolor btn-orange w-color");
					$time.find("input").addClass("w2-bgcolor w1-color");
					if (me.beforeListener)
						me.beforeListener($c);
					return;
				}else if (JF.isValid(p)){ 
					$title.html(p);
				}
				
				// 设置的时间小于现在时间退出
				ordertimer = setInterval(function() {
					leftTimer(data2)
				}, 1000);
 
				mmtimer = setInterval(function() {
					var $mm=$time.find("[mm]");
					if(!JF.isValid($mm.val())){
						$mm.val("0");
					}
					if(parseInt($mm.val())>60){
						$mm.val("0");
					}
					if(JF.isValid($mm.val())){
						var mm=parseInt($mm.val())+1; 
						mm = checkTime(mm);  
						$mm.val(mm);
					}
				}, 20);
			}
			go($(this).attr("startDate"),$(this).attr("endDate"),$(this).attr("isOver"),$(this).attr("title"));
			$(this).append($timer);

		});

		this.$ = $main;
		this.bindObject = $main;
		this.esseObject = $main;
	}, 
	
});


/*******************************************************************************
 * 视频组件
 */
JF.define("jf.ui.Video", {
	extend : jf.ui.Component,
	Video : function(args) {
		this.src = args.src;
		!args.width ? this.width ="100%" : this.width = args.width;
		!args.title ? this.title ="" : this.title = args.title;
		!args.poster ? this.poster ="" : this.poster = args.poster;
		this.build();
	},
	draw : function() {
		var me=this;
		var $main = $('<div class="list-view">'); 
		var $title = $('<span class="w-color blue-font-border h3 p-left">'); 
		$title.html(this.title);
		this.$video = $('<video>'); 
		this.$video.attr("class","video-source");
		this.$video.attr("width",this.width);
		this.$video.attr("height",this.height);
		this.$video.attr("controls","controls");
		this.$video.attr("style","object-fit:fill");
		this.$video.attr("webkit-playsinline","true");
		this.$video.attr("x-webkit-airplay","true");
		this.$video.attr("playsinline","true");
		this.$video.attr("x5-video-player-type","h5");
		this.$video.attr("x5-video-orientation","h5");
		this.$video.attr("x5-video-player-fullscreen","true");
		this.$video.attr("preload","none");
		this.$video.attr("data-config", '{"mediaTitle": "' + this.title + '"}');
		this.$video.attr("poster", this.poster);
		var $source = $('<source>'); 
		$source.attr("src",this.src);
		$source.attr("type","video/mp4");
		$source.append("您的浏览器不支持视频");
		this.$video.append($source); 

		$main.append(this.$video).append($title);
		 
		this.$ = $main;
		this.bindObject = this.$;
		this.esseObject = this.$;
	},
	toggleSound: function (){
        var video = this.$video[0];
        if(video.paused){ // 如果已暂停则播放
            video.play(); // 播放控制
        }else{ // 已播放点击则暂停
            video.pause(); // 暂停控制
        }
	} 
});

/*******************************************************************************
 * 伸缩面板
 */
JF.define("jf.ui.SpreadPanel", {
	extend : jf.ui.Component,
	SpreadPanel : function(args) { 
		this.target = this.container.children(0); 
		JF.isNull(args.isSpread) ? this.isSpread =false : this.isSpread = args.isSpread;
		!args.title ? this.title ="" : this.title = args.title;
		!args.btnText ? this.btnText ="展开" : this.btnText = args.btnText;
		!args.btnCloseText ? this.btnCloseText ="关闭" : this.btnCloseText = args.btnCloseText;
		JF.isNull(args.hideTitle) ? this.hideTitle =false : this.hideTitle = args.hideTitle;
		this.scrollstop = args.scrollstop;
		this.bgClassName = args.bgClassName;
		 
		this.child = args.child;
		this.childHtml = args.childHtml;
		
		this.build();
	},
	draw : function() {
		var me=this;
		var $main = $('<div class="list-view">'); 
		$main.addClass(this.bgClassName);
		var $titleDiv = $('<div class="table padding2" style="width:97%">'); 
		var $titleDiv_child1 = $('<div class="table-cell left">'); 
		var $titleDiv_child2 = $('<div class="table-cell center">'); 
		var $titleDiv_child3 = $('<div class="table-cell right">'); 
		var $title = $('<font class="h3"></font>'); 
		this.$titleIconText = $('<font class="h3">'+this.btnText+'</font>'); 
		this.$titleIcon = $('<font class="iconfont icon-xiangxiazhankai h3"></font>'); 
		$title.html(this.title);
		$titleDiv_child1.append($title);
		if(JF.isValid(this.child)){
			$titleDiv_child2.append(this.child.$);
		}else if(JF.isValid(this.childHtml)){
			$titleDiv_child2.append(this.childHtml);
		} 
		$titleDiv_child3.append(this.$titleIconText).append(this.$titleIcon); 
		$titleDiv.append($titleDiv_child1).append($titleDiv_child2).append($titleDiv_child3); 
		me.target.data("height",me.target.height());
		if(this.isSpread==true){
			me.spread(); 
		} else{ 
			me.close();
		}
		if(this.hideTitle==true){
			$titleDiv.hide();
		}
		tap($titleDiv_child3,function() {  
			if(me.target.attr("expend")=="true"){
				me.close();
				$closeDiv.hide();
				me.getWin(); 
				me.scrollToMe();
			}else{ 
				$closeDiv.show();
				me.spread();  
				me.scrollToMe(); 
			}  
		},true); 
		var $felxBox = $('<div class="felxBox">'); 
		var $col = $('<div class="col">');
		var $div = $('<div class="w-bgcolor radius3 border7 padding1">');
		$div.append(this.target); 
		$col.append($div); 
		$felxBox.append($col);
		  
		$main.append($titleDiv).append($felxBox);
		
		var $closeDiv = $('<div class="hide center"></div>');
		var $close = $('<font class="h1 w2-color iconfont icon-xiangshangshouqi"></font>');
		var $closeText = $('<p class="h4 list-view w2-color iconfont">关闭</p>');
		$closeText.css("bottom","6px");
		$closeDiv.append($close).append($closeText);
		
		tap($closeDiv,function() {  
			$closeDiv.hide();
			me.close();
			me.scrollToMe();
		},true); 
		
		$main.append($closeDiv);
		
		this.$ = $main;
		this.bindObject = this.$;
		this.esseObject = this.$;
	},
	spread:function(){
		this.target.attr("expend","true");
		this.target.css("height","");
		this.$titleIcon.removeClass("icon-xiangxiazhankai");
		this.$titleIcon.addClass("icon-xiangshangshouqi");
		this.$titleIconText.html(this.btnCloseText); 
	},
	close:function(){
		this.target.attr("expend","false");
		this.target.css("height",this.target.data("height"));
		this.$titleIcon.removeClass("icon-xiangshangshouqi");
		this.$titleIcon.addClass("icon-xiangxiazhankai");
		this.$titleIconText.html(this.btnText); 
	},
	stop:function(){
		 
	}
});

/*******************************************************************************
 * 按钮
 */
JF.define("jf.ui.Button", {
	extend : jf.ui.Component,
	Button : function(args) { 
		!args.listener ? this.listener = function() {
		} : this.listener = args.listener;// 事件
		!args.text ? this.text = "按钮": this.text = args.text;
		this.className = args.className;
		!args.type ? this.type = 0: this.type = args.type;
		
		this.build();
	},
	draw : function() {
		var me=this;
		var $main = $('<div class="list-view">'); 
		if(this.type==0){
			$main.addClass("button");	
		}else{
			$main.addClass("iconButton");	
		}
		$main.html(this.text);
		tap($main,function() {  
			me.listener.apply(me,[$(this)]); 
		},true);
		$main.addClass(this.className);
		  
		this.$ = $main;
		this.bindObject = this.$;
		this.esseObject = this.$;
	},
	 
});
