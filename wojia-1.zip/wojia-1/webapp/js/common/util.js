
 
/*******************************************************************************
 * 缩放图片大小
 * 
 * @param Img
 * @param maxWidth
 * @returns
 */
function scaleImage(Img, maxWidth) {
	var rs = {};
	rs["w"] = maxWidth;
	rs["h"] = maxWidth * (Img.height / Img.width);
	// alert(Img.height);
	return rs;
}
/*******************************************************************************
 * 转化图片格式Base64
 * 
 * @param param
 * @param callback
 * @returns
 */
function imgToBase64(param, callback) { 
	var image = new Image();
	image.src = param.src; 
	image.onload = function() {
		var w, h; 
		if(image.width>640){ 
			var wh=scaleImage(image, 640);
			image.width=wh.w;
			image.height=wh.h;
		}
		if (JF.isValid(param.width) && !JF.isValid(param.height)) {
			var scale = scaleImage(image, param.width);
			w = scale.w;
			h = scale.h;
		} else if (JF.isValid(param.width) && JF.isValid(param.height)) {
			w = param.width;
			h = param.height;
		} else {
			w = image.width;
			h = image.height;
		}
		if (!JF.isValid(param.scale)) {
			param.scale=1;
		} 
		var canvas = $("<canvas>");
		canvas[0].width = w;
		canvas[0].height = h;
		var ctx=canvas[0].getContext("2d");
		ctx.drawImage(this, 0, 0, w, h);
		
		if(JF.isValid(param.watermark)){
			// 绘制水印
			ctx.fillStyle = "rgba(255,255,255,0.5)";
			ctx.font="20px Georgia";
			ctx.fillText(param.watermark,2,h-5);
		}  
		if (callback) {
			var base64 = canvas[0].toDataURL("image/"+param.format); 
			var pre="data:image/"+param.format+";base64,";
			var str=base64.substring(pre.length);
			var equalIndex= str.indexOf('=');
			if(str.indexOf('=')>0)
			{
			    str=str.substring(0, equalIndex);
			}
			var strLength=str.length;
			var fileLength=parseInt(strLength-(strLength/8)*2);
 	
			var img = new Image();
			img.src = base64;
			callback(base64, fileLength, img,image.width,image.height);
		}
	}

}
/*******************************************************************************
 * 获取图片格式
 * 
 * @param src
 * @returns
 */
function getImageFormat(src){
	return "image/"+getImageSub(src);
}
/*******************************************************************************
 * 获取图片后缀
 * 
 * @param src
 * @returns
 */
function getImageSub(src){
	if(!JF.isValid(src)){
		return "";
	}
	var i=src.lastIndexOf(".");
	if(i!=-1){
		var sub=src.substring(i+1);
		if(sub!="png"&&sub!="jpeg"&&sub!="gif"&&sub!="jpg"&&sub!="bmp"){
			sub="jpeg";
		}
		return sub;
	}
} 
/*******************************************************************************
 * 保存用户点击历史数据
 * 
 * @param id
 * @param type
 * @returns
 */
function toBrowsingHistory(id,type){ 
	var browsingHistory = jf.os.session.get("browsingHistory");
	if (!JF.isValid(browsingHistory)) {
		browsingHistory = {
			product:[],
			project:[]
		};
	}
	if(type==0){ 
		browsingHistory.product.push(id);
	}else{
		browsingHistory.project.push(id);
	}
	jf.os.session.save({
		browsingHistory : browsingHistory
	});  
	// alert(JSON.stringify(jf.os.session.get("browsingHistory")));
}
/*******************************************************************************
 * 获取用户点击历史数据
 * 
 * @param type
 * @returns
 */
function getBrowsingHistory(type){ 
	var browsingHistory = jf.os.session.get("browsingHistory");
	if (!JF.isValid(browsingHistory)) {
		browsingHistory = {
			product:[],
			project:[]
		};
	}
	if(type==0){ 
		return  browsingHistory.product;
	}else{
		return browsingHistory.project;
	}  
}
/*******************************************************************************
 * 设置客户临时电话号码
 * 
 * @param shopid
 * @param phone
 * @returns
 */
function saveTempPhone(shopid,phone){  
	setCookie(shopid,"tempPhone", phone);	
}
/*******************************************************************************
 * 获取客户临时电话号码
 * 
 * @param shopid
 * @returns
 */
function getTempPhone(shopid){ 
	var tempPhone = getCookie(shopid, "tempPhone"); 
	if (!JF.isValid(tempPhone)) {
		var user = getUser(shopid);
		if(JF.isValid(user)&&user.userid!="none"){ 
			tempPhone = user.mobile; 
		}
	}	
	return tempPhone;
}

/*******************************************************************************
 * 编码中文字符
 * 
 * @param s
 * @returns
 */
function decode(s) {
	return unescape(s.replace(/\\(u[0-9a-fA-F]{4})/gm, '%$1'));
}
/*******************************************************************************
 * 解码中文字符
 * 
 * @param s
 * @returns
 */
function encode(s) {
	return escape(s).replace(/%(u[0-9A-F]{4})|(%[0-9A-F]{2})/gm, function($0, $1, $2) {
		return $1 && '\\' + $1.toLowerCase() || unescape($2);
	});
}
