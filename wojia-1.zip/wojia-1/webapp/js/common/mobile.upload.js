/*******************************************************************************
 * 上传图片
 */
JFast.define("jf.util.Upload", {
	Upload : function(args) {

	},
	/**
	 * @param base64Codes
	 *            图片的base64编码
	 */
	upload : function(files, callback, process) {
		var me = this;
		var formData = new FormData();

		for (var i = 0; i < files.length; i++) {
			var file = files[i];

			formData.append("file" + i, me.convertBase64UrlToBlob(file.file));
			formData.append("fileName", file.fileName);
			formData.append("filePath", file.filePath);
			formData.append("fileSuffix", file.fileSuffix);
			formData.append("width", file.width);
			formData.append("height", file.height);
			formData.append("isCompress", file.isCompress);
			formData.append("pathPre", file.pathPre);
		}

		$.ajax({
			url : url + "file/upload",
			type : "POST",
			data : formData,
			dataType : "text",
			processData : false, // 告诉jQuery不要去处理发送的数据
			contentType : false, // 告诉jQuery不要去设置Content-Type请求头

			success : function(data) {
				if (callback)
					callback(data);
			},
			xhr : function() { // 在jquery函数中直接使用ajax的XMLHttpRequest对象
				var xhr = new XMLHttpRequest();

				xhr.upload.addEventListener("progress", function(evt) {
					if (evt.lengthComputable) {
						var percentComplete = Math.round(evt.loaded * 100 / evt.total);
						if (process)
							process(percentComplete);
					}
				}, false);

				return xhr;
			}

		});
	},

	/**
	 * 将以base64的图片url数据转换为Blob
	 * 
	 * @param urlData
	 *            用url方式表示的base64图片数据
	 */
	convertBase64UrlToBlob : function(urlData) {

		var bytes = window.atob(urlData.split(',')[1]); // 去掉url的头，并转换为byte

		// 处理异常,将ascii码小于0的转换为大于0
		var ab = new ArrayBuffer(bytes.length);
		var ia = new Uint8Array(ab);
		for (var i = 0; i < bytes.length; i++) {
			ia[i] = bytes.charCodeAt(i);
		}

		return new Blob([ ab ]);
	},
	// 从 canvas 提取图片 image
	convertCanvasToImage : function(canvas) {
		// 新Image对象，可以理解为DOM
		var image = new Image();
		// canvas.toDataURL 返回的是一串Base64编码的URL，当然,浏览器自己肯定支持
		// 指定格式 PNG
		image.src = canvas.toDataURL();
		return image;
	}
});
