var JFast = {};
var context = "/wojia/";
/*******************************************************************************
 * 获取某个实例的类型
 */
JFast.type = function(instance) {
	if (typeof instance == "object") {
		var str = instance.toString();
		var i = str.indexOf("@");
		if (i == -1) {
			return null;
		} else {
			return str.substring(0, i);
		}
	} else {
		return null;
	}
};

/*******************************************************************************
 * 是否是JF组件
 */
JFast.isJF = function(instance) {
	if (typeof instance == "object") {
		var str = instance.toString();
		var i = str.indexOf("@");
		var y = str.indexOf("jf.");
		if (i == -1 || y == -1) {
			return false;
		} else {
			return true;
		}
	} else {
		return false;
	}
};
JFast.time = new Date().getTime();// 当前时间轴
//JFast.time = 10;// 当前时间轴
/*******************************************************************************
 * 创建js脚本链接
 */
JFast.createScript = function(src, fn, async) {
	if (JF.isNull(async)) {
		async = true;//默认异步
	}
	var _body = document.getElementsByTagName('head')[0];
	var src = src + "?ver=" + JF.time;
	var tagStr = "script[src='" + src + "']";

	var had = $(tagStr);
	if (JF.isValid(had[0])) {
		if (fn)
			fn();
	} else {
		var tag = document.createElement('script');
		tag.type = 'text/javascript';
		tag.src = src;
		if(async){
			tag.async = async; 
		} 
		tag.onload = function() { 
			if (fn)
				fn();
		}
		_body.appendChild(tag);
		jf.os.jsCache.add(tagStr);
	}
};
/*******************************************************************************
 * 创建css样式表链接
 */
JFast.createLink = function(src, fn, async) {
	if (JF.isNull(async)) {
		async = false;//默认同步
	}
	var _body = document.getElementsByTagName('head')[0];
	var src = src + "?ver=" + JF.time;
	var tagStr = "link[href='" + src + "']";
	var had = $(tagStr);
	if (JF.isValid(had[0])) {
		if (fn)
			fn();
	} else {
		var tag = document.createElement('link');
		tag.rel = 'stylesheet';
		tag.type = 'text/css';
		tag.href = src;
		if(async){
			tag.async = async; 
		} 
		tag.onload = function() { 
			if (fn)
				fn();
		}
		_body.appendChild(tag);
		jf.os.cssCache.add(tagStr);
	}
};
/*******************************************************************************
 * 加载资源文件集合
 */
JFast.loaders = function(param, callback) {
	var me = this;
	if (!JF.isValid(param.src) || param.src.length == 0) {
		if (callback)
			callback("");
		return;
	}
	var i = 0;
	var fn = function() {
		i++;
		if (JF.isValid(param.src[i])) {
			JF.loader({
				src : param.src[i],
				srcType : param.srcType,
				async:param.async,
			}, fn);
		} else {
			if (callback)
				callback();
		}
	};
	JF.loader({
		src : param.src[i],
		srcType : param.srcType,
		async:param.async,
	}, fn);
},
/*******************************************************************************
 * 加载单个资源文件
 */
JFast.loader = function(param, fn) {
	var me = this;
	var _body = document.getElementsByTagName('head')[0];
	if (param.srcType == "js") {
		JF.createScript(param.src, fn, param.async);
	} else if (param.srcType == "css") {
		JF.createLink(param.src, fn, param.async);
	}
},
/*******************************************************************************
 * 字母数字随机数
 */
JFast.random = function(n) {
	var chars = [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' ];
	var res = "";
	if (!n || n == 0) {
		n = 20;
	}
	for (var i = 0; i < n; i++) {
		var id = Math.ceil(Math.random() * 35);
		res += chars[id];
	}
	return res;
};

/*******************************************************************************
 * 判断是否为null
 */
JFast.isNull = function(val) {
	if (val == null || val == undefined) {
		return true;
	} else {
		return false;
	}
};

/*******************************************************************************
 * 判断是否为有效值（包括等于空字符串）
 */
JFast.isValid = function(val) {
	if (val != null && val != undefined && val != "" && val != "null" && val != "undefined" && val != "NaN")
		return true;
	else
		return false;
};

/*******************************************************************************
 * 判断是否为null
 */
JFast.hasAttr = function(el,name) {
	return typeof(el.attr(name))!="undefined"
};

/*******************************************************************************
 * 扩充类的方法
 */
JFast.extendBody = function(clazz, body) {
	if (typeof body == 'object' || typeof body == 'function') { // 方法的扩充
		for ( var key in body) {
			clazz.prototype[key] = body[key];
		}
	} else {
		alert("extendBody:type " + typeof body + " invalid.");
	}
	return clazz;
};
/*******************************************************************************
 * 继承类
 */
JFast.extendClass = function(clazz, superClass) {
	if (typeof superClass == 'function') {// 类式继承
		var F = function() {
		}; // 创建一个中间函数对象以获取父类的原型对象
		F.prototype = superClass.prototype; // 设置原型对象
		clazz.prototype = new F(); // 实例化F,继承父类的原型中的属性和方法，而无需调用父类的构造函数实例化无关的父类成员
		// clazz.prototype.super = F.prototype;
		clazz.superClass = superClass; // 同时，添加一个指向父类构造函数的引用，方便调用父类方法或者调用父类构造函数
	} else {
		alert("extendClass:type " + typeof superClass + " invalid.");
	}
	return clazz;
};

/*******************************************************************************
 * 创建包名[命名空间]或类 type：namespace or class
 */
JFast.createObject = function(namespace, type) {
	// 运行构造方法
	var fnInit = function(clazz, args, ns, thiz) {
		args == null ? args = {} : args = args;

		// 提取父类构造方法
		var superClassArray = [];
		var superClass = clazz.superClass;
		while (superClass) {
			superClassArray.push(superClass);
			superClass = superClass.superClass;
		}

		// 运行父类构造方法
		var len = superClassArray.length;
		for (var i = len - 1; i >= 0; i--) {
			var s = superClassArray[i];
			var constructor = s.prototype.constructor;
			thiz[constructor](args);
		}
		// 运行本类构造方法
		if (thiz[ns]) {
			thiz.args = args;
			thiz[ns](args);

			if (thiz.id) {
				jf.os.cache.put(thiz.id, thiz);
			}
			// 类实例描述(通过new方式实例化类)
			thiz.sequence = ns + "@" + JFast.random(20) + "[INSTANCE]";
			thiz.toString = function() {
				return thiz.sequence;
			};
		} else {
			alert("constructor method " + ns + " not found.");
			return;
		}
	}
	type == null ? type = "namespace" : type = type;
	var nsArray = namespace.split('.');
	var size = nsArray.length;
	var obj;
	for (var i = 0; i < size; i++) {
		var ns = nsArray[i];
		if (i == 0) {
			if (!window[ns] && type == "namespace") {
				obj = window[ns] = {};
			} else if (!window[ns] && type == "class") {
				// 构造方法
				obj = window[ns] = function(args) {
					fnInit(obj, args, namespace, this);
				};
			} else {
				obj = window[ns];
			}
		} else if (i == size - 1 && type == "class") {
			if (!obj[ns]) {
				// 构造方法
				obj = obj[ns] = function(args) {
					fnInit(obj, args, namespace, this);
				};
			} else {
				obj = obj[ns];
			}
		} else {
			if (!obj[ns]) {
				obj = obj[ns] = {};
			} else {
				obj = obj[ns];
			}
		}
	}
	return obj;
};

/*******************************************************************************
 * 定义类
 */
JFast.define = function(ns, body) {
	var clazz = JFast.createObject(ns, "class");
	if (body.extend) {
		JFast.extendClass(clazz, body.extend, ns);
	} else if (!body.extend && ns != "jf.lang.Object") {
		body.extend = jf.lang.Object;
		JFast.extendClass(clazz, body.extend, ns);
	}
	var namespace = "";
	var className = "";
	var i = ns.lastIndexOf(".");
	if (i != -1) {
		namespace = ns.substring(0, i);
		className = ns.substring(i + 1)
	} else {
		namespace = "";
		className = ns;
	}
	body.namespace = namespace;// 指定命名空间
	body.constructor = ns;// 指定构造方法名称
	body[ns] = body[className];// 指定构造方法

	if (i != -1) {
		delete body[className];// 删除定义中的临时构造方法
	}
	JFast.extendBody(clazz, body);
	return clazz;
}

/*******************************************************************************
 * 创建命名空间/包名
 */
JFast.namespace = function(ns) {
	JFast.createObject(ns);
}

// /////////////////////////////声明基础类,所有类默认继承此类///////////////////////////////////
JFast.define("jf.lang.Object", {
	Object : function(args) {
	},
	toString : function() {
		return this.constructor + "@[CLASS]";
	}
});
// ////////////////////////////////工具/////////////////////////////////////////
/*******************************************************************************
 * MAP键值映射
 */
JFast.define("jf.util.Map", {
	Map : function(args) {
		this.array = new Array();
		if (args.data) {
			this.array = args.data;
		}
	},
	size : function() {
		return this.array.length;
	},
	// 转换成数组对象
	toArray : function() {
		var rs = [];
		this.each(function(key, value, i, len, array) {
			var t = {};
			t[key] = value;
			rs.push(t);
		});
		return rs;
	},
	// 转换成数组对象
	toKeyArray : function() {
		var rs = [];
		this.each(function(key, value, i, len, array) {
			rs.push(key);
		});
		return rs;
	},
	// 转换成数组对象
	toValueArray : function() {
		var rs = [];
		this.each(function(key, value, i, len, array) {
			rs.push(value);
		});
		return rs;
	},
	// 根据索引位置获取值
	value : function(index) {
		return this.array[index].value;
	},
	// 根据索引位置获取键名
	key : function(index) {
		return this.array[index].key;
	},
	// 根据键名获取值
	_get : function(key) {
		var rs={};
		var size = this.array.length;
		for (var i = 0; i < size; i++) {
			var val = this.array[i];  
			if (val.key == key) {
				rs.value= val.value;
				rs.i= i;
				break;
			}
		}
		return rs;
	},
	// 根据键名获取值
	get : function(key) { 
		return this._get(key).value;
	},
	// 删除某个键的值
	remove : function(key) {
		var rs=null; 
		if (typeof key == "number") { 
			var val = this.array[key]; 
			this.array.splice(key, 1);
			rs= val.value;
		}else if (typeof key == "string") { 
			var size = this.array.length;
			for (var i = size - 1; i >= 0; i--) {
				var val = this.array[i];
				var kn = val.key;
				if (kn == key) {
					this.array.splice(i, 1);
					rs= val.value;
					break;
				}
			} 
		} 
		return rs; 
	},
	// 清空所有键值
	removeAll : function() {
		var size = this.array.length;
		for (var i = size - 1; i >= 0; i--) {
			this.array.splice(i, 1);
		}
	},
	clear : function() {
		this.removeAll();
	},
	// 存入键值
	put : function(key, value) {
		var val = {};
		val.key = key;
		val.value = value;
		var size = this.array.length;
		var rs=this._get(key);
		if (JF.isNull(rs.value)) {
			this.array.push(val);
		} else {
			this.array[rs.i] = val;
		}
	},
	// 循环数组
	each : function(fn) {
		var len = this.size();
		for (var i = 0; i < len; i++) {
			var obj = this.array[i];
			var key = obj.key;
			var value = obj.value;
			if (fn.apply(obj, [ key, value, i, len, this.array ]) == false) {
				break;
			}
		}
	},
	// 循环数组
	eachBack : function(fn) {
		var len = this.size();
		for (var i = len - 1; i >= 0; i--) {
			var obj = this.array[i];
			var key = obj.key;
			var value = obj.value;
			if (fn.apply(obj, [ key, value, i, len, this.array ]) == false) {
				break;
			}
		}
	},
});

/*******************************************************************************
 * 数组
 */
JFast.define("jf.util.List", {
	List : function(args) {
		this.array = new Array();
		if (args.data) {
			this.array = args.data;
		}
	},
	size : function() {
		return this.array.length;
	},
	// 转换成数组对象
	toArray : function() {
		return this.array;
	},
	// 根据索引获取值
	get : function(index) {
		return this.array[index];
	},
	// 删除某个键的值
	remove : function(i) {
		this.array.splice(i, 1);
	},
	// 清空所有键值
	removeAll : function() {
		this.array = new Array();
	},
	clear : function() {
		this.removeAll();
	},
	// 存入键值
	add : function(value) {
		this.array.push(value);
	},
	// 循环数组
	each : function(fn) {
		var len = this.size();
		for (var i = 0; i < len; i++) {
			var value = this.get(i);
			if (fn.apply(value, [ value, i, len, this.array ]) == false) {
				break;
			}
		}
	},
	// 循环数组
	eachBack : function(fn) {
		var len = this.size();
		for (var i = len - 1; i >= 0; i--) {
			var obj = this.array[i];
			if (fn.apply(obj, [ i, len, this.array ]) == false) {
				break;
			}
		}
	},
});

/*******************************************************************************
 * 会话数据，需要HTML5的支持
 */
JFast.define("jf.util.Session", {
	Session : function(args) {
		!args.storage ? this.storage = sessionStorage : this.storage = args.storage;
	},
	getBaseSessionObj : function() {
		var YTDStr = this.storage.getItem(context);
		if (typeof YTDStr != 'string' || YTDStr == null) {
			YTD = {};
		} else {
			YTD = $.parseJSON(YTDStr);
		}
		return YTD;
	},
	saveBaseSessionObj : function(str) {
		try {
			this.storage.setItem(context, str);
		} catch (e) {
			this.clear();
		}

	},
	// 获取指定session
	get : function(name) {
		var YTD = this.getBaseSessionObj();
		if (name != null && name != "") {
			return YTD[name];
		} else {
			return YTD;
		}
	},
	// 清除指定session
	clear : function(name) {
		var YTD = this.getBaseSessionObj();
		if (name != null && name != "") {
			YTD[name] = null;
		} else {
			YTD = {};
		}
		this.saveBaseSessionObj(JSON.stringify(YTD));
	},
	// 保存会话数据
	save : function(conf, name) {
		var YTD = this.getBaseSessionObj();
		if (name != null && name != "") {
			var obj = YTD[name];
			if (obj == null) {
				obj = {};
			}
			for ( var k in conf) {
				obj[k] = conf[k];
			}
			YTD[name] = obj;
		} else {
			for ( var k in conf) {
				YTD[k] = conf[k];
			}
		}
		this.saveBaseSessionObj(JSON.stringify(YTD));
	}
});

/*******************************************************************************
 * 获取组件
 */
JFast.get = function(id) {
	return jf.os.cache.get(id);
}
// ///////////////////////////////////系统级别全局变量//////////////////////////////////////////
JFast.namespace("jf.os");
jf.os.sequence = JFast.random(50);// JFast唯一序列号，很重要，不要覆盖
jf.os.cache = new jf.util.Map();// JFast缓存，很重要，不要覆盖
jf.os.session = new jf.util.Session();// JFast缓存，很重要，不要覆盖
jf.os.local = new jf.util.Session({
	storage : localStorage
});

// /////////////////////////////声明别名///////////////////////////////////
JFast.namespace("JF");
JF = JFast;
JF.namespace("JF.ui");

jf.os.pageCache = new jf.util.Map();// 页面资源缓存，很重要，不要覆盖
jf.os.jsCache = new jf.util.List();// js资源缓存，很重要，不要覆盖
jf.os.cssCache = new jf.util.List();// css资源缓存，很重要，不要覆盖
jf.os.zIndexCache = 0;// 弹出层级缓存，很重要，不要覆盖
jf.os.frameHistory = new jf.util.List();// 页面缓存，很重要，不要覆盖

