package com.jhl.refpp.support;

import org.springframework.stereotype.Component;
import com.jhl.refpp.mapper.*;
import com.jhl.refpp.mapper.ext.SerialNoExtMapper;
import com.jhl.refpp.mapper.ext.ShopExtMapper;
import com.jhl.refpp.mapper.ext.UserExtMapper; 
import javax.annotation.Resource;

@Component
public class MapperFactory {
	public static SquenceMapper squenceMapper;

	public static WxSessionMapper WxSessionMapper;

	public static ShopExtMapper shopExtMapper;
	public static ShopMapper shopMapper;

	public static WxMapper wxMapper;

	public static SerialNoExtMapper serialNoExtMapper;
	public static SerialNoMapper serialNoMapper;

	public static UserExtMapper userExtMapper;
	public static UserMapper userMapper;

	public static MesTemplateMapper mesTemplateMapper;

	@Resource
	public void setSquenceMapper(SquenceMapper squenceMapper) {
		MapperFactory.squenceMapper = squenceMapper;
	}

	@Resource
	public void setWxSessionMapper(WxSessionMapper wxSessionMapper) {
		WxSessionMapper = wxSessionMapper;
	}

	@Resource
	public void setShopExtMapper(ShopExtMapper shopExtMapper) {
		MapperFactory.shopExtMapper = shopExtMapper;
	}

	@Resource
	public void setShopMapper(ShopMapper shopMapper) {
		MapperFactory.shopMapper = shopMapper;
	}

	@Resource
	public void setWxMapper(WxMapper wxMapper) {
		MapperFactory.wxMapper = wxMapper;
	}

	@Resource
	public void setSerialNoExtMapper(SerialNoExtMapper serialNoExtMapper) {
		MapperFactory.serialNoExtMapper = serialNoExtMapper;
	}

	@Resource
	public void setSerialNoMapper(SerialNoMapper serialNoMapper) {
		MapperFactory.serialNoMapper = serialNoMapper;
	}

	@Resource
	public void setUserExtMapper(UserExtMapper userExtMapper) {
		MapperFactory.userExtMapper = userExtMapper;
	}

	@Resource
	public void setUserMapper(UserMapper userMapper) {
		MapperFactory.userMapper = userMapper;
	}

	@Resource
	public void setMesTemplateMapper(MesTemplateMapper mesTemplateMapper) {
		MapperFactory.mesTemplateMapper = mesTemplateMapper;
	}

}
