package com.jhl.refpp.weixin.menu;

import com.jfinal.kit.JsonKit;
import com.jfinal.weixin.sdk.api.ApiConfig;
import com.jfinal.weixin.sdk.api.ApiConfigKit;
import com.jfinal.weixin.sdk.api.ApiResult;
import com.jfinal.weixin.sdk.api.MenuApi;

/**
 * @Email 蜜美约菜单管理器类
 */
public class MenuManager {
	public static void main(String[] args) {

		// 将菜单对象转换成json字符串
		// 有问题：主菜单项多了一个type
		String jsonMenu = JsonKit.toJson(getMenu()).toString();
		System.out.println(jsonMenu);
		ApiConfig ac = new ApiConfig();

		ac.setAppId("wx7a189f600abb25ac");
		ac.setAppSecret("b54f0658beab95d5a042deaf515ecb9a");

		ApiConfigKit.setThreadLocalApiConfig(ac);

		// 创建菜单
		ApiResult apiResult = MenuApi.createMenu(jsonMenu);

		System.out.println(apiResult.getJson());

	}

	private static Menu getMenu() {

		ViewButton poster = new ViewButton();
		poster.setName("公司官网");
		poster.setType("view");
		poster.setUrl("https://www.jinghaihuanyu.com/wojia/oauth2/oauth/?win=poster&shopid=S00000");
 
	 

		/////////////////////////////////////////////
		ViewButton order = new ViewButton();
		order.setName("联营卡");
		order.setType("view");
		order.setUrl("https://www.jinghaihuanyu.com/wojia/oauth2/oauth/?win=locationCard&shopid=S00000");

		/////////////////////////////////////////////

		ViewButton adminConsole = new ViewButton();
		adminConsole.setName("共享会员");
		adminConsole.setType("view");
		adminConsole.setUrl("https://www.jinghaihuanyu.com/wojia/oauth2/oauth/?win=my&shopid=S00000&weixinShare=true");
 
		ComButton mainBtn3 = new ComButton();
		mainBtn3.setName("更多功能");
		mainBtn3.setSub_button(new Button[] { adminConsole});

		/**
		 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
		 * 
		 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
		 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
		 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
		 */
		Menu menu = new Menu();
		menu.setButton(new Button[] { poster, order, adminConsole });
		return menu;
	}
}
