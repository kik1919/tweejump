package com.jhl.refpp.weixin.menu;

/**
 * @author Javen
 * @Email javenlife@126.com
 * 
 */
public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	} 
	
	
}
