package com.jhl.refpp.weixin.menu;

/**
 * @author Javen
 * @Email javenlife@126.com
 * 
 */
public class ViewButton extends Button{
	private String url;
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
