package com.jhl.refpp.weixin.menu;

/**
 * @author Javen
 * @Email javenlife@126.com
 * 
 */
public class ClickButton extends Button{
	private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
}
