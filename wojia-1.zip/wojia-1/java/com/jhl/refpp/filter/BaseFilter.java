package com.jhl.refpp.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter; 
import com.jhl.refpp.util.Util; 

public class BaseFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest arg0, HttpServletResponse arg1, FilterChain arg2)
			throws ServletException, IOException {
		Util.setRequest(arg0);
		Util.setResponse(arg1);
		Util.setSession(arg0.getSession());
		arg2.doFilter(arg0, arg1); 
	} 
}
