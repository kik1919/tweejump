package com.jhl.refpp.filter;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import org.springframework.web.filter.OncePerRequestFilter;

import com.alibaba.fastjson.JSON;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.po.WxSession;
import com.jhl.refpp.po.WxSessionExample;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.Util;

public class BossAuthFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest arg0, HttpServletResponse arg1, FilterChain arg2)
			throws ServletException, IOException {

		Para loginUser = (Para) arg0.getSession().getAttribute("loginUser");
		if (loginUser == null) {
			try {
				WxSessionExample wxSessionExample = new WxSessionExample();
				wxSessionExample.createCriteria().andSessionidEqualTo(arg0.getParameter("sessionid"));
				List<WxSession> sessionList = MapperFactory.WxSessionMapper.selectByExample(wxSessionExample);
				if (Util.hasValue(sessionList)) {
					WxSession wxSession = sessionList.get(0);
					Map<Object,Object> map = (Map<Object,Object>) JSON.parse(wxSession.getData());
					loginUser = new Para(map);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
		arg0.setAttribute("notAuthDesc", "老板");
		if (loginUser != null) {
			Integer level = loginUser.getInteger("level");
			Integer role = loginUser.getInteger("role");
			if (level != null && role != null) {
				if (role == DBC.BOSS) {
					arg2.doFilter(arg0, arg1);
				} else {
					arg0.getRequestDispatcher("/auth/notAuth").forward(arg0, arg1);
				}
			} else {
				arg0.getRequestDispatcher("/auth/notAuth").forward(arg0, arg1);
			}
		} else {
			arg0.getRequestDispatcher("/auth/notAuth").forward(arg0, arg1);
		}
	}

}
