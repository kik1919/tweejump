package com.jhl.refpp.service;

import com.jhl.refpp.core.SqlMappler;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.DataList;
import com.jhl.refpp.core.config.tag.Pager;
import com.jhl.refpp.service.SerialNoService;
import com.jhl.refpp.support.MapperFactory;

import org.springframework.stereotype.Service;

@Service("serialNoService")
public class SerialNoService {

	/***
	 * 获取系统操作日志
	 * 
	 * @param map
	 * @param pager
	 * @return
	 * @throws Exception
	 */
	public DataList getList(Para map, Pager pager) throws Exception {
		Para param = new Para();
		param.put("data", map);
		param.put("pager", pager);
		DataList data = SqlMappler.query(MapperFactory.serialNoExtMapper, param);
		return data;

	}

}
