package com.jhl.refpp.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import java.io.UnsupportedEncodingException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.codehaus.xfire.util.Base64;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.kit.StrKit;
import com.jfinal.weixin.sdk.api.ApiResult;
import com.jfinal.weixin.sdk.api.PaymentApi;
import com.jfinal.weixin.sdk.api.QrcodeApi;
import com.jfinal.weixin.sdk.api.PaymentApi.TradeType;
import com.jfinal.weixin.sdk.kit.PaymentKit;
import com.jfinal.weixin.sdk.utils.HttpUtils;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.exception.ServiceLogicException;
import com.jhl.refpp.po.SerialNo;
import com.jhl.refpp.po.User;
import com.jhl.refpp.po.Wx;
import com.jhl.refpp.po.WxExample;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.service.WeChatService;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.DateParser;
import com.jhl.refpp.util.RedPackUtil;
import com.jhl.refpp.util.StringUtils;
import com.jhl.refpp.util.Util;

@Service("weChatService")
public class WeChatService {
	private static Logger logger = Logger.getLogger(WeChatService.class);
	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "shopService")
	private ShopService shopService;

	/***
	 * 注册微信用户
	 * 
	 * @param userObj
	 * @return
	 * @throws Exception
	 */
	public Message register(JSONObject wxUser) throws Exception {
		if (wxUser == null) {
			throw new ServiceLogicException("注册失败：无法读取微信用户数据");
		}
		Para data = new Para();

		String shopid = wxUser.getString("shopid");
		int platform = wxUser.getInteger("platform");
		String refereeid = wxUser.getString("refereeid");
		String isAttention = wxUser.getString("isAttention");

		String unionid = wxUser.getString("unionid");
		String openid = wxUser.getString("openid");
		String nickname = wxUser.getString("nickname");
		String headimgurl = wxUser.getString("headimgurl");
		String country = wxUser.getString("country");
		String province = wxUser.getString("province");
		String city = wxUser.getString("city");
		String sex = wxUser.getString("sex");
		if (StringUtils.isNullOrEmpty(nickname)) {
			nickname = "匿名用户";
		}

		shopService.loadWXConfById(shopid);// 加载门店微信配置

		/////////////////// 判断数据库中是否有用户Start///////////////////

		Para user = userService.findWholeUser(unionid, openid);

		System.out.println("==========数据库是否有用户？=============" + user);
		/////////////////// 判断数据库中是否有用户End///////////////////

		String userid = null;
		if (user != null) {
			userid = user.getString("id");
			// 服务器已经有用户信息，
			String qrCodeUrl = user.getString("qrCodeUrl");
			// 判断是否有推广二维码，如果没有，生成推广二维码并更新
			if (StringUtils.isNullOrEmpty(qrCodeUrl)) {
				// 获取推广二维码
				ApiResult tg = QrcodeApi.createPermanent(openid);
				if (tg.isSucceed()) {
					qrCodeUrl = tg.getStr("url");
				} else {
					System.out.println(tg.getJson());
				}
			}
			// 更新用户推荐二维码信息
			User u = new User();
			u.setId(userid);
			u.setQrCodeUrl(qrCodeUrl);
			u.setUnionid(unionid);// 重新更新下unionid，因为可能存在之前无数据或数据错误
			u.setOpenid(openid);
			u.setIsDel(DBC.NO);
			if (StringUtils.isNullOrEmpty(isAttention)) {
				u.setIsAttention(DBC.NO);
			} else {
				u.setIsAttention(Integer.parseInt(isAttention));
			}
			int i = MapperFactory.userMapper.updateByPrimaryKeySelective(u);
			if (i != 0) {
				System.out.println("更新用户信息成功！");
			}
		} else {
			userid = Util.userID();
			// 如果没有，保存用户信息
			// 获取推广二维码
			ApiResult tg = QrcodeApi.createPermanent(openid);
			String qrCodeUrl = null;
			if (tg.isSucceed()) {
				qrCodeUrl = tg.getStr("url");
			} else {
				System.out.println(tg.getJson());
			}
			User u = new User();
			u.setId(userid);
			u.setIsDel(0);
			u.setCreatedAt(new Date());
			u.setQrCodeUrl(qrCodeUrl);
			u.setIsDel(DBC.NO);
			if (StringUtils.isNullOrEmpty(isAttention)) {
				u.setIsAttention(DBC.NO);
			} else {
				u.setIsAttention(Integer.parseInt(isAttention));
			}
			u.setOpenid(openid);
			u.setUnionid(unionid);
			u.setName(nickname);
			u.setCountry(country);
			u.setCity(city);
			u.setSex(sex);
			u.setProvince(province);
			u.setLevel(DBC.VIP1);
			u.setRole(DBC.CUSTOMER);
			u.setPlatform(platform);
			u.setReferee(refereeid);

			if (!StringUtils.isNullOrEmpty(headimgurl)) {
				String headPic = "img/user/" + userid + ".jpg";
				String dest = Util.appRoot + headPic;
				System.out.println("===========项目目录dest=======" + dest);
				Util.pullImage(headimgurl, dest);// 从服务器拉取头像
				u.setHeadPic(headPic);
			} else {
				u.setHeadPic("img/userHead.png");
			}
			MapperFactory.userMapper.insertSelective(u);
			System.out.println("新用户保存成功！");

			if (!StringUtils.isNullOrEmpty(refereeid)) {
				// 赠送1000积分给推荐人
				User refereeUser = MapperFactory.userMapper.selectByPrimaryKey(refereeid);
				if (refereeUser != null) {
					refereeUser.setCredit(refereeUser.getCredit() + 1000);
					MapperFactory.userMapper.updateByPrimaryKeySelective(refereeUser);
				}
			}
		}
		Para newUser = userService.get(new Para("id", userid));

		String sessionKey = wxUser.getString("sessionKey");
		newUser.put("sessionKey", sessionKey);// 小程序注册用户手机号需要用到
		newUser.put("openid", openid);// 小程序注册用户手机号需要用到
		data.put("user", newUser);
		data.put("wxUser", wxUser);
		return new Message(1, "注册用户成功", data);
	}

	/***
	 * 根据微信授权code查找微信用户数据（H5页面）
	 * 
	 * @throws Exception
	 */
	public JSONObject getWeChatInfo(String code, String shopid) throws Exception {
		System.out.println("START========获取客户信息======START");

		String APPID = "";
		String SECRET = "";

		if (!StringUtils.isNullOrEmpty(shopid)) {
			Para shop = shopService.loadWXConfById(shopid);// 加载门店公众号配置
			APPID = shop.getString("appid");
			SECRET = shop.getString("appSecret");
		} else {
			throw new ServiceLogicException("无效的公众号门店ID");
		}

		// 第1步：通过code换取网页授权access_token
		String url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + APPID + "&secret=" + SECRET + "&code="
				+ code + "&grant_type=authorization_code";
		System.out.println("=======通过code换取网页授权URL========" + url);
		String result = HttpUtils.get(url);
		System.out.println("===============getWeChatInfo================" + result);
		JSONObject resultObj = (JSONObject) JSONObject.parse(result);
		String errcode = resultObj.getString("errcode");
		if (errcode == "null" || StringUtils.isNullOrEmpty(errcode)) {
			String access_token = resultObj.getString("access_token");
			String openid = resultObj.getString("openid");

			// 第2步：拉取用户信息(需scope为 snsapi_userinfo)
			String catchUserInfoUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=" + access_token + "&openid="
					+ openid + "&lang=zh_CN";
			System.out.println("=====拉取用户信息URL=======" + catchUserInfoUrl);
			String catchUserInfoResult = HttpUtils.get(catchUserInfoUrl);
			System.out.println("============" + catchUserInfoResult);
			JSONObject resultUser = (JSONObject) JSONObject.parse(catchUserInfoResult);
			System.out.println("END========获取客户信息======END");
			String errcode1 = resultUser.getString("errcode");
			if (errcode1 == "null" || StringUtils.isNullOrEmpty(errcode1)) {
				// 获取客户资料成功
				return resultUser;
			}
		}
		return null;
	}

	/***
	 * 根据微信授权code查找微信用户数据（小程序）
	 */
	public JSONObject getWeChatInfoWX(String code, String appid, String encryptedData, String iv) throws Exception {
		System.out.println("START========获取客户信息======START");
		String APPID = appid;
		String SECRET = "";

		WxExample wxExample = new WxExample();
		wxExample.createCriteria().andAppidEqualTo(APPID);
		List<Wx> listWx = MapperFactory.wxMapper.selectByExample(wxExample);
		if (Util.hasValue(listWx)) {
			Wx wx = listWx.get(0);
			SECRET = wx.getAppSecret();
		}

		String url = "https://api.weixin.qq.com/sns/jscode2session?appid=" + APPID + "&secret=" + SECRET + "&js_code="
				+ code + "&grant_type=authorization_code";
		System.out.println("===============" + url);
		String result = HttpUtils.get(url);
		System.out.println("===============getWeChatInfoWX================" + result);
		JSONObject resultObj = (JSONObject) JSONObject.parse(result);
		String openid = String.valueOf(resultObj.get("openid"));
		String sessionKey = String.valueOf(resultObj.get("session_key"));
		if (openid != "null" || !StringUtils.isNullOrEmpty(openid)) {
			// 微信查询成功
			resultObj.put("sessionKey", sessionKey);

			if (!StringUtils.isNullOrEmpty(encryptedData) && !StringUtils.isNullOrEmpty(iv)) {
				// 需要解密unionid
				System.out.println("===encryptedData==" + encryptedData);
				System.out.println("===iv==" + iv);
				JSONObject userInfo = this.getUserInfo(encryptedData, sessionKey, iv);
				System.out.println("===userInfo==" + userInfo);
				resultObj.put("unionid", userInfo.getString("unionId"));
				resultObj.put("province", userInfo.getString("province"));
				resultObj.put("city", userInfo.getString("city"));
				resultObj.put("country", userInfo.getString("country"));
				resultObj.put("avatarUrl", userInfo.getString("avatarUrl"));
				resultObj.put("gender", userInfo.getString("gender"));
				resultObj.put("nickName", userInfo.getString("nickName"));
			}

			System.out.println("END========获取客户信息======END");
			return resultObj;
		} else {
			return null;
		}
	}

	private static BouncyCastleProvider bouncyCastleProvider = null;

	public static synchronized BouncyCastleProvider getInstance() {
		if (bouncyCastleProvider == null) {
			bouncyCastleProvider = new BouncyCastleProvider();
		}
		return bouncyCastleProvider;
	}

	/**
	 * 获取信息
	 */
	public JSONObject getUserInfo(String encryptedData, String sessionkey, String iv) {
		// 被加密的数据
		byte[] dataByte = Base64.decode(encryptedData.replaceAll(" ", "+"));
		// 加密秘钥
		byte[] keyByte = Base64.decode(sessionkey);
		// 偏移量
		byte[] ivByte = Base64.decode(iv.replaceAll(" ", "+"));
		try {
			// 如果密钥不足16位，那么就补足. 这个if 中的内容很重要
			int base = 16;
			if (keyByte.length % base != 0) {
				int groups = keyByte.length / base + (keyByte.length % base != 0 ? 1 : 0);
				byte[] temp = new byte[groups * base];
				Arrays.fill(temp, (byte) 0);
				System.arraycopy(keyByte, 0, temp, 0, keyByte.length);
				keyByte = temp;
			}
			// 初始化
			Security.addProvider(getInstance());
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding", "BC");
			SecretKeySpec spec = new SecretKeySpec(keyByte, "AES");
			AlgorithmParameters parameters = AlgorithmParameters.getInstance("AES");
			parameters.init(new IvParameterSpec(ivByte));
			cipher.init(Cipher.DECRYPT_MODE, spec, parameters);// 初始化
			byte[] resultByte = cipher.doFinal(dataByte);
			if (null != resultByte && resultByte.length > 0) {
				String result = new String(resultByte, "UTF-8");
				return JSONObject.parseObject(result);
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidParameterSpecException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		}
		return null;
	}

	/***
	 * 统一下单
	 * 
	 * @param notify_url
	 * @param openid
	 * @param billid
	 * @param price
	 * @param ip
	 * @param shopid
	 * @param appidWx
	 * @return
	 * @throws Exception
	 */
	public Para unifiedorder(String notify_url, String userid, String billid, String price, String ip, String shopid,
			String appidWx) throws Exception {

		Para shop = shopService.loadWXConfById(shopid);// 加载门店公众号配置

		Para userPara = new Para("id", userid);
		userPara.put("appidWx", appidWx);// 传递小程序appid，则用户数据中包括所属小程序的openid
		Para user = userService.getWhole(userPara);

		String openid = null;// 支付用户openid
		String APPID = "";
		if (appidWx != null) {
			APPID = appidWx;
			openid = user.getString("openidWx");// 小程序支付用户openid
		} else {
			APPID = shop.getString("appid");
			openid = user.getString("openid");// H5页面支付用户openid
		}
		Float fp = Float.valueOf(price);
		fp = fp * 100;
		int priceFen = fp.intValue();

		logger.info("微信统一下单开始=========================================");
		Map<String, String> params = new HashMap<String, String>();

		params.put("appid", APPID);
		logger.info("appid===========" + APPID);

		params.put("mch_id", shop.getString("mchId"));
		logger.info("mch_id===========" + shop.getString("mchId"));

		params.put("body", shop.getString("name"));

		params.put("out_trade_no", billid);// 订单ID
		logger.info("out_trade_no===========" + billid);

		params.put("total_fee", String.valueOf(priceFen));// 金额
		logger.info("total_fee===========" + priceFen);

		if (ip == null || ip == "null" || StrKit.isBlank(ip)) {
			ip = "127.0.0.1";
		}
		if (ip != null && ip.indexOf(",") != -1) {
			String[] ips = ip.split(",");
			if (ips.length != 0) {
				ip = ips[0];
			}
		}
		params.put("spbill_create_ip", ip);
		logger.info("spbill_create_ip===========" + ip);
		logger.info("===JSAPI========" + TradeType.JSAPI.name());
		params.put("trade_type", TradeType.JSAPI.name());

		String nonce_str = System.currentTimeMillis() / 1000 + "";
		params.put("nonce_str", nonce_str);
		logger.info("nonce_str===========" + nonce_str);

		params.put("notify_url", notify_url);
		logger.info("notify_url===========" + notify_url);

		params.put("openid", openid);
		logger.info("openid===========" + openid);
		logger.info("PaternerKey===========" + shop.getString("paternerKey"));

		String sign = PaymentKit.createSign(params, shop.getString("paternerKey"));
		params.put("sign", sign);
		logger.info("sign签名===========" + sign);

		String xmlResult = PaymentApi.pushOrder(params);
		logger.info("微信支付请求响应报文:" + xmlResult);
		Map<String, String> result = PaymentKit.xmlToMap(xmlResult);

		String return_code = result.get("return_code");
		logger.info("签名结果代码===================" + return_code);
		String return_msg = result.get("return_msg");
		logger.info("签名结果===================" + return_msg);

		if (StrKit.isBlank(return_code) || !"SUCCESS".equals(return_code)) {
			if (StrKit.isBlank(return_msg) || !"OK".equals(return_msg)) {
				return new Para();
			}
		} else if (StrKit.notBlank(return_code) && "SUCCESS".equals(return_code)) {
			if (StrKit.isBlank(return_msg) || !"OK".equals(return_msg)) {
				return new Para();
			} else {

				String prepay_id = result.get("prepay_id");
				String timeStamp = System.currentTimeMillis() / 1000 + "";
				String nonceStr = System.currentTimeMillis() + "";

				HashMap<String, String> maps = new HashMap<String, String>();
				maps.put("appId", APPID);
				maps.put("timeStamp", timeStamp);
				maps.put("nonceStr", nonceStr);
				maps.put("package", "prepay_id=" + prepay_id);
				maps.put("signType", "MD5");
				String packageSign = PaymentKit.createSign(maps, shop.getString("paternerKey"));
				maps.put("paySign", packageSign);
				logger.info("微信统一下单结束=========================================");
				Para rs = new Para();
				rs.put("appId", APPID);
				rs.put("timeStamp", timeStamp);
				rs.put("nonceStr", nonceStr);
				rs.put("package", "prepay_id=" + prepay_id);
				rs.put("signType", "MD5");
				rs.put("paySign", packageSign);
				rs.put("id", billid);
				rs.put("prepay_id", prepay_id);
				return rs;

			}
		} else {
			return new Para();
		}
		return new Para();
	}

	/***
	 * 统一下单前验证合法性
	 * 
	 * @param para
	 * @return
	 * @throws Exception
	 */
	public Para validUnifiedorder(Para para) throws Exception {
		Para params = new Para();
		System.out.println("=validUnifiedorder===" + params);
		String userid = para.getString("userid");// 支付用户userid
		String billid = para.getString("billid");// 业务订单号
		String busid = para.getString("busid");// 付款数据库数据ID，用来查询支付的真实数据
		Integer busType = para.getInteger("busType");// 业务类型
		String shopid = para.getString("shopid"); // 公众号门店ID

		if (busType.equals(DBC.PAY_0)) {
			params.put("pass", true);
		} else {

		}
		return params;
	}

	/***
	 * 微信支付成功后触发的事件
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public Para paySuccess(Map<String, String> params) throws Exception {
		SerialNo serialNo = new SerialNo();

		String openid = params.get("openid");
		String totalFee = params.get("total_fee");// 总金额
		String orderId = params.get("out_trade_no");// 商户订单号
		String transId = params.get("transaction_id");// 微信支付订单号
		String timeEnd = params.get("time_end");// 支付完成时间，格式为yyyyMMddHHmmss

		float payMoney = (Long.parseLong(totalFee) * 0.01f);
		String desc = "";

		/////////// 获取当前支付用户信息Start///////////
		Para param = new Para();
		param.put("openid", openid);
		Para u = userService.get(param);
		User user = (User) u.trans(User.class);
		/////////// 获取当前支付用户信息End///////////

		if (orderId.startsWith("M")) {
			desc = "订单支付";

		} else {

		}

		serialNo.setDetail("支付成功，业务单号：" + orderId + "】【微信订单号：" + transId + "】【总金额：" + payMoney + "元】【操作时间:" + timeEnd
				+ "】【" + desc + "】");

		serialNo.setLevel(DBC.YES);
		serialNo.setTargetid(orderId);
		serialNo.setTrace(serialNo.getDetail());
		serialNo.setId(Util.ID("N"));
		serialNo.setCreatedAt(new Date());
		serialNo.setUserid(user.getId());
		serialNo.setUsername(user.getName());

		MapperFactory.serialNoMapper.insert(serialNo);

		return null;
	}

	/***
	 * 微信支付失败后触发的事件
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public Para payFail(Map<String, String> params) throws Exception {
		SerialNo serialNo = new SerialNo();

		String openid = params.get("openid");
		String totalFee = params.get("total_fee");// 总金额
		String orderId = params.get("out_trade_no");// 商户订单号
		String transId = params.get("transaction_id");// 微信支付订单号
		String timeEnd = params.get("time_end");// 支付完成时间，格式为yyyyMMddHHmmss

		timeEnd = DateParser.StringTime(timeEnd);
		float payMoney = (Long.parseLong(totalFee) * 0.01f);
		String desc = "";

		/////////// 获取当前支付用户信息Start///////////
		Para param = new Para();
		param.put("openid", openid);
		Para u = userService.get(param);
		User user = (User) u.trans(User.class);
		/////////// 获取当前支付用户信息End///////////

		if (orderId.startsWith("M")) {
			desc = "订单支付";

		} else {

		}

		serialNo.setDetail("支付失败，业务单号：" + orderId + "】【微信订单号：" + transId + "】【总金额：" + payMoney + "元】【操作时间:" + timeEnd
				+ "】【\"+desc+\"】");

		serialNo.setLevel(DBC.YES);
		serialNo.setTargetid(orderId);
		serialNo.setTrace(serialNo.getDetail());
		serialNo.setId(Util.ID("N"));
		serialNo.setCreatedAt(new Date());
		serialNo.setUserid(user.getId());
		serialNo.setUsername(user.getName());

		MapperFactory.serialNoMapper.insert(serialNo);
		return null;
	}

	/***
	 * 针对成功付款的订单退款
	 * 
	 * @param serviceid
	 * @param billid
	 * @param price
	 * @param refundPrice
	 * @param shopid
	 * @param desc
	 * @return
	 * @throws Exception
	 */
	public Message refund(String serviceid, String billid, String price, String refundPrice, String shopid, String desc)
			throws Exception {
		Para shop = shopService.loadWXConfById(shopid);// 加载门店公众号配置
		return RedPackUtil.refund(serviceid, billid, price, refundPrice, shop, desc);
	}
}
