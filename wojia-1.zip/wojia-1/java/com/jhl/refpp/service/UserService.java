package com.jhl.refpp.service;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import com.jhl.refpp.core.SqlMappler;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.DataList;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.core.config.tag.Pager;
import com.jhl.refpp.po.User;
import com.jhl.refpp.po.UserExample;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.MD5;
import com.jhl.refpp.util.SMS;
import com.jhl.refpp.util.StringUtils;
import com.jhl.refpp.util.Util;

import org.springframework.stereotype.Service;

@Service("userService")
public class UserService {

	/***
	 * 获取用户列表（有敏感数据，此方法仅限管理员使用）
	 * 
	 * @param map
	 * @param pager
	 * @return
	 * @throws Exception
	 */
	public DataList getList(Para map, Pager pager) throws Exception {
		Para param = new Para();
		param.put("data", map);
		param.put("pager", pager);
		DataList data = SqlMappler.query(MapperFactory.userExtMapper, param);
		return data;
	}

	/***
	 * 根据unionid、openid依次查找完整用户数据
	 */
	public Para findWholeUser(String unionid, String openid) throws Exception {
		Para user = null;
		// 如果有开放平台id，则通过此id查询是否已经有用户
		if (!StringUtils.isNullOrEmpty(unionid)) {
			// 根据unionid判断是否有其他渠道注册的用户
			Para param = new Para();
			param.put("unionid", unionid);
			user = this.getWhole(param);// 获取用户信息
		}

		if (user == null) {
			// 根据unionid没有查询出用户，再通过公众号或者小程序openid查询用户
			System.out.println("==========没有unionid，再次通过openid查找当前用户数据=========");
			Para param = new Para();
			param.put("openid", openid);
			user = this.getWhole(param);// 获取用户信息
		} else {
			System.out.println("==========通过unionid查找出当前用户数据=========");
		}

		return user;
	}
	
	/***
	 * 根据unionid、openid依次查找用户数据
	 */
	public Para findUser(String unionid, String openid) throws Exception {
		Para user = null;
		// 如果有开放平台id，则通过此id查询是否已经有用户
		if (!StringUtils.isNullOrEmpty(unionid)) {
			// 根据unionid判断是否有其他渠道注册的用户
			Para param = new Para();
			param.put("unionid", unionid);
			user = this.get(param);// 获取用户信息
		}

		if (user == null) {
			// 根据unionid没有查询出用户，再通过公众号或者小程序openid查询用户
			System.out.println("==========没有unionid，再次通过openid查找当前用户数据=========");
			Para param = new Para();
			param.put("openid", openid);
			user = this.get(param);// 获取用户信息
		} else {
			System.out.println("==========通过unionid查找出当前用户数据=========");
		}

		return user;
	}

	/***
	 * 获取一个完整数据
	 * 
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Para getWhole(Para map) throws Exception {
		Pager pager = new Pager(0, 1);
		List<Para> list = this.getList(map, pager).list();
		if (Util.hasValue(list)) {
			Para one = list.get(0);
			return one;
		} else {
			return null;
		}
	}

	/***
	 * 获取一个（无敏感数据）
	 * 
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Para get(Para map) throws Exception {
		Pager pager = new Pager(0, 1);
		List<Para> list = this.getList(map, pager).list();
		if (Util.hasValue(list)) {
			Para one = list.get(0);
			// 清空敏感字段
			one.remove("openid");
			one.remove("unionid");
			one.remove("openidWx");
			one.remove("pwd");
			return one;
		} else {
			return null;
		}
	}

	/***
	 * 修改用户资料（所有字段权限），判断电话号码不重复
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateByIdForAdminMobileNorepeat(Para map) throws Exception {
		String id = map.getString("id");
		String mobile = map.getString("mobile");
		if (!StringUtils.isNullOrEmpty(mobile)) {
			UserExample userExample = new UserExample();
			userExample.createCriteria().andMobileEqualTo(mobile).andIdNotEqualTo(id);
			List<User> users = MapperFactory.userMapper.selectByExample(userExample);
			if (Util.hasValue(users)) {
				return new Message(0, "手机号已被使用<br/>请重新输入");
			}
		}

		return this.updateByIdForAdmin(map);

	}

	/***
	 * 修改用户资料（所有字段权限）
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateByIdForAdmin(Para map) throws Exception {
		String id = map.getString("id");
		String op = map.getString("op");
		User old = MapperFactory.userMapper.selectByPrimaryKey(id);
		User record = (User) map.trans(User.class);
		int i = MapperFactory.userMapper.updateByPrimaryKeySelective(record);
		Para adminpara = new Para("id", id);
		adminpara.put("isUpdateLevel", DBC.NO);
		Para newUser = this.get(adminpara);
		if (i != 0) {
			if (op != null && op.equals("update") && !old.getHeadPic().equals("img/userHead.png")) {
				File f = new File(Util.appRoot + old.getHeadPic());
				f.delete();
			}
			return new Message(1, "修改成功", new Para("user", newUser));
		} else {
			return new Message(0, "修改失败", new Para("user", newUser));
		}
	}

	/***
	 * 修改积分
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateCreditBy(String userid, int credit) throws Exception {
		Para map = new Para();
		map.put("id", userid);
		map.put("credit", credit);
		return this.updateByIdForAdmin(map);
	}

	/***
	 * 修改用户资料（除了禁用、手机号、角色和等级，以及敏感数据）
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateById(Para map) throws Exception {
		map.remove("isDel");
		map.remove("role");
		map.remove("level");
		map.remove("mobile");
		// 清空敏感字段
		map.remove("openid");
		map.remove("unionid");
		map.remove("openidWx");
		map.remove("pwd");
		return this.updateByIdForAdmin(map);
	}

	/***
	 * 修改openid和unionid
	 * 
	 * @param id
	 * @param openid
	 * @param unionid
	 * @return
	 * @throws Exception
	 */
	public Message updateWxidById(String userid, String openid, String unionid) throws Exception {
		Para one = new Para();
		one.put("id", userid);
		if (!StringUtils.isNullOrEmpty(openid)) {
			one.put("openid", openid);
		}
		if (!StringUtils.isNullOrEmpty(unionid)) {
			one.put("unionid", unionid);
		}

		Message mes = this.updateByIdForAdmin(one);
		if (mes.getState() == DBC.YES) {
			return new Message(1, "更新成功");
		} else {
			return new Message(0, "更新失败");
		}
	}

	/***
	 * 修改密码
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updatePwd(Para map) throws Exception {
		String id = map.getString("id");
		String newpwd = map.getString("newpwd");
		// System.out.println("=====newpwd====="+newpwd);
		if (StringUtils.isNullOrEmpty(newpwd)) {
			return new Message(0, "请输入新密码");
		}
		Para one = new Para();
		one.put("id", id);
		one.put("pwd", newpwd);
		Message mes = this.updateByIdForAdmin(one);
		if (mes.getState() == DBC.YES) {
			return new Message(1, "成功修改密码");
		} else {
			return new Message(0, "修改密码失败");
		}
	}
	
	/***
	 * 取消关注
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message cancelAttention(String unionid, String openid) throws Exception {
		Para user=this.findUser(unionid, openid);
		user.put("isAttention", DBC.NO);
		Message mes = this.updateByIdForAdmin(user);
		if (mes.getState() == DBC.YES) {
			return new Message(1, "已取消关注");
		} else {
			return new Message(0, "取消关注失败");
		}
	}

	/***
	 * 修改用户基本资料
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateByIdForBase(Para map) throws Exception {
		map.remove("credit");
		map.remove("platform");
		map.remove("cardid");
		map.remove("qrCodeUrl");
		map.remove("boothType");
		map.remove("isAttention");
		map.remove("isDel");
		map.remove("role");
		map.remove("level");
		map.remove("mobile");
		// 清空敏感字段
		map.remove("openid");
		map.remove("unionid");
		map.remove("openidWx");
		map.remove("pwd");

		String id = map.getString("id");
		String uh = map.getString("headPic");
		try {
			// 单独处理微信头像图片
			if (!StringUtils.isNullOrEmpty(uh)) {
				String headPic = "img/user/" + id + ".jpg";
				String dest = Util.appRoot + headPic;
				System.out.println("===========项目目录dest=======" + dest);
				Util.pullImage(uh, dest);// 从服务器拉取头像
				map.put("headPic", headPic);
			}
		} catch (Exception e) {
			map.put("headPic", uh);
		}
		Message mes = this.updateByIdForAdmin(map);
		if (mes.getState() == DBC.YES) {

		}
		return mes;
	}

	/***
	 * 用户登录
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message login(Para map) throws Exception {
		Para para = new Para();
		String msg = "";
		String mobile = map.getString("mobile");
		String validCode = map.getString("validCode");
		String pwd = map.getString("pwd");
		boolean isPassValidCode = false;
		if (!StringUtils.isNullOrEmpty(validCode) && SMS.checkCode(Util.getRequest(), mobile, validCode)) {
			// 随机密码登录
			isPassValidCode = true;
		}
		if (!StringUtils.isNullOrEmpty(validCode) && !isPassValidCode) {
			return new Message(0, "验证码错误");
		}

		if (StringUtils.isNullOrEmpty(mobile)) {
			return new Message(0, "请输入11位手机号");
		}

		Para user = null;
		// System.out.println(validCode + "===========" + isPassValidCode);
		if (validCode != null && isPassValidCode) {
			// 验证通过，查询原始密码
			Para validPara = new Para();
			validPara.put("mobile", mobile);
			user = this.get(validPara);
			if (user != null) {
				User loginUser = new User();
				loginUser.setId(user.getString("id"));
				loginUser.setPwd(MD5.encrypt(validCode));
				MapperFactory.userMapper.updateByPrimaryKeySelective(loginUser);
				msg += user.getString("name") + "<br/>请牢记新密码<br/>" + validCode + "<br/>点击进入";
				para.put("s", 1000 * 60);
			}
		} else {
			Para validPara = new Para();
			validPara.put("mobile", mobile);
			validPara.put("pwd", pwd);
			user = this.get(validPara);
			System.out.println("====validPara======" + validPara);
			if (user != null) {
				msg += user.getString("name") + "<br/>欢迎您的到来";
				para.put("s", 2000);
			}
		}

		if (user != null) {
			if (user.getInteger("isDel") == DBC.YES) {
				return new Message(0, "您已被禁用");
			}
			para.put("loginUser", user);
			return new Message(1, msg, para);
		} else {
			return new Message(0, "手机号或者密码错误");
		}

	}

	/***
	 * 用户H5页面用户访问时候自动注册
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message register(Para map) throws Exception {
		Para para = new Para();
		String id = map.getString("id");
		String pwd = map.getString("pwd");
		String mobile = map.getString("mobile");
		String validCode = map.getString("validCode");
		HttpServletRequest req = (HttpServletRequest) map.get("req");
		UserExample userExample = new UserExample();
		userExample.createCriteria().andMobileEqualTo(mobile);
		List<User> users = MapperFactory.userMapper.selectByExample(userExample);
		if (Util.hasValue(users)) {
			return new Message(0, "手机号已被使用<br/>请重新输入");
		}

		if (validCode != null && !SMS.checkCode(req, mobile, validCode)) {
			// 随机密码登录
			return new Message(0, "验证码错误");
		}
		User user = MapperFactory.userMapper.selectByPrimaryKey(id);
		if (user.getMobile() == null || user.getMobile().trim().equals("")) {
			user.setCredit(user.getCredit() + 1000);// 首次注册送积分
		}
		user.setPwd(pwd);
		user.setMobile(mobile);
		if (user.getLevel() < DBC.VIP2) {
			user.setLevel(DBC.VIP2);
		}
		int i = MapperFactory.userMapper.updateByPrimaryKeySelective(user);

		user.setPwd("");// 不需要把密码发送给客户端
		para.put("loginUser", Para.trans(user));

		if (i == 1) {
			return new Message(i, "绑定手机号成功", para);
		} else {
			return new Message(i, "绑定手机号失败", para);
		}
	}

}
