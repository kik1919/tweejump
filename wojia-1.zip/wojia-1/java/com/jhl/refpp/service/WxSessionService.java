package com.jhl.refpp.service;
 
import java.util.List;
import com.alibaba.fastjson.JSONObject;
import com.jhl.refpp.core.Para; 
import com.jhl.refpp.core.config.tag.Message; 
import com.jhl.refpp.po.WxSession;
import com.jhl.refpp.po.WxSessionExample;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.StringUtils;
import com.jhl.refpp.util.Util;

import org.springframework.stereotype.Service;

@Service("wxSessionService")
public class WxSessionService {

	/***
	 * 获取一个
	 * 
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Para getData(String sessionid) throws Exception {
		WxSessionExample wxSessionExample = new WxSessionExample();
		wxSessionExample.createCriteria().andSessionidEqualTo(sessionid);
		List<WxSession> sessionList = MapperFactory.WxSessionMapper.selectByExample(wxSessionExample);
		if (Util.hasValue(sessionList)) {
			WxSession wxSession = sessionList.get(0);
			JSONObject json = JSONObject.parseObject(wxSession.getData());
			return Para.trans(json);
		} else {
			return null;
		}
	}

	/***
	 * 新增
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message add(Para map) throws Exception {
		String id = "";
		if (StringUtils.isNullOrEmpty(map.getString("id"))) {
			id = Util.ID("_G");
			map.put("id", id);
		} else {
			id = map.getString("id");
		}
		WxSession record = (WxSession) map.trans(WxSession.class);

		WxSessionExample wxSessionExample = new WxSessionExample();
		wxSessionExample.createCriteria().andUseridEqualTo(record.getUserid())
		.andAppidEqualTo(record.getAppid());
		List<WxSession> sessionList = MapperFactory.WxSessionMapper.selectByExample(wxSessionExample);
		if (Util.hasValue(sessionList)) {
			WxSession wxSession = sessionList.get(0);
			wxSession.setSessionid(record.getSessionid());
			wxSession.setData(record.getData());
			int i = MapperFactory.WxSessionMapper.updateByPrimaryKeySelective(wxSession);
			if (i != 0) {
				return new Message(1, "更新会话成功", Para.trans(wxSession));
			} else {
				return new Message(0, "更新会话失败");
			}

		} else {
			int i = MapperFactory.WxSessionMapper.insertSelective(record);
			if (i != 0) {
				return new Message(1, "更新会话成功", map);
			} else {
				return new Message(0, "更新会话失败");
			}
		}
	}
}
