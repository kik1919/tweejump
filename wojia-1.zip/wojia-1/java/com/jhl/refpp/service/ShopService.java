package com.jhl.refpp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jfinal.weixin.sdk.api.ApiConfigKit;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.core.config.tag.Pager; 
import com.jhl.refpp.po.Shop;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.Util;
import com.jhl.refpp.util.WeixinUtil;

@Service("shopService")
public class ShopService {

	public void startRun() throws Exception {
		this.loadWXConf(new Para());
	}

	/**
	 * 根据门店ID查找配置
	 * 
	 * @param shopid
	 * @return
	 * @throws Exception
	 */
	public Para loadWXConfById(String shopid) throws Exception {
		Para param = new Para();
		param.put("id", shopid);
		return this.loadWXConf(param);
	}

	/***
	 * 根据微信相关信息匹配查找配置
	 * 
	 * @param wx
	 * @return
	 * @throws Exception
	 */
	public Para loadWXConfByWX(String wx) throws Exception {
		Para param = new Para();
		param.put("wx", wx);
		return this.loadWXConf(param);
	}

	/***
	 * 查找门店配置
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Para loadWXConf(Para map) throws Exception {
		Pager pager = new Pager(0, 1);

		Para param = new Para();
		param.put("data", map);
		param.put("pager", pager);

		List<Para> list = MapperFactory.shopExtMapper.getList(param);

		if (Util.hasValue(list)) {
			// 如果只返回一条数据，则加载店铺公众号配置
			Para shop = list.get(0); 
			String file = shop.getString("file"); 
			System.out.println("========shop======" + shop);
			WeixinUtil.loadProp(file);// 加载指定门店的配置文件
			ApiConfigKit.setThreadLocalApiConfig(WeixinUtil.getApiConfig(file));

			return shop;
		} else {
			return null;
		}
	}
	
	/***
	 * 修改
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public Message updateById(Para map) throws Exception {
		Shop record = (Shop) map.trans(Shop.class);
		int i = MapperFactory.shopMapper.updateByPrimaryKeySelective(record); 
		if (i != 0) {
			return new Message(1, "修改成功");
		} else {
			return new Message(0, "修改失败");
		}
	}

}
