package com.jhl.refpp.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.weixin.sdk.api.ApiResult;
import com.jfinal.weixin.sdk.api.TemplateMsgApi;
import com.jhl.refpp.core.Context;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.po.MesTemplate;
import com.jhl.refpp.po.MesTemplateExample;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.SMS;
import com.jhl.refpp.util.SMS.Content; 
import com.jhl.refpp.util.TemplateMiniApi;
import com.jhl.refpp.util.Util;

import org.springframework.stereotype.Service;

@Service("mesService")
public class MesService {

	@Resource(name = "shopService")
	private ShopService shopService;

	@Resource(name = "userService")
	private UserService userService;

	/***
	 * 获取模板ID
	 * 
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public String getTid(Para map) throws Exception {
		String type = map.getString("type");
		MesTemplateExample mesTemplateExample = new MesTemplateExample();
		mesTemplateExample.createCriteria().andTypeEqualTo(type);
		List<MesTemplate> list = MapperFactory.mesTemplateMapper.selectByExample(mesTemplateExample);
		if (Util.hasValue(list)) {
			return list.get(0).getTid();
		} else {
			return null;
		}
	}

	/***
	 * 发送短信操作密码
	 * 
	 * @param para
	 * @return
	 * @throws Exception
	 */
	public Message sendVerificationCodeSMS(Para para) throws Exception {
		String mobile = para.getString("mobile");
		String name = para.getString("name");
		Content sms = new Content();
		sms.setPhone(mobile);
		sms.setTemplateCode("SMS_167963443");// 操作密码：${code}，仅支持当前${name}操作，5分钟有效，请不要泄露给他人！

		JSONObject obj = new JSONObject();
		Random random = new Random();
		String code = random.nextInt(999999) + "";
		obj.put("code", code);
		obj.put("name", name);
		sms.setTemplateContent(obj.toJSONString());

		sms = SMS.sendMsg(sms, "窝家");
		if (sms.getSendSmsResponse().getCode().equals("OK")) {
			return new Message(1, "发送成功",new Para("msg",sms));
		} else {
			return new Message(0, "发送失败");
		}
	}

	/***
	 * 发送小程序模板消息
	 * 
	 * @param id
	 * @param host
	 * @return
	 * @throws Exception
	 */
	public Message sendMiniTemplate(String id, String prepayid) throws Exception {
		String tid = this.getTid(new Para("type", "1"));// 模板ID
		if (tid != null && !tid.equals("")) {
			String openid = "";
			JSONObject json = new JSONObject();
			json.put("touser", openid);
			json.put("template_id", tid);
			json.put("form_id", prepayid);
			json.put("page", "pages/index/index");
			JSONObject data = new JSONObject();
			json.put("data", data);

			JSONObject keyword1 = new JSONObject();
			keyword1.put("value", "");

			data.put("keyword1", keyword1);

			System.out.println("=========send=============" + json.toString());

			Para shop = shopService.loadWXConf(new Para());
			ApiResult rs = TemplateMiniApi.send(json.toString(), shop);
			System.out.println(rs.getErrorMsg());

			return new Message(1, "发送消息成功");
		} else {
			return new Message(0, "发送消息失败：未找到模板");
		}
	}

	/***
	 * 发送公众号模板消息
	 * 
	 * @param id
	 * @param host
	 * @return
	 * @throws Exception
	 */
	public Message sendTemplate(String id, String host) throws Exception {
		String tid = this.getTid(new Para("type", "1"));// 模板ID
		DateFormat dateFm = new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss");
		if (tid != null && !tid.equals("")) {
			Para shop = shopService.loadWXConf(new Para());
			String openid = "";
			JSONObject json = new JSONObject();
			json.put("touser", openid);
			json.put("template_id", tid);

			String url = Context.url(host) + "";
			json.put("url", url);

			JSONObject miniprogram = new JSONObject();
			miniprogram.put("appid", shop.getString("appidWx"));
			miniprogram.put("pagepath", "pages/index/index");
			json.put("miniprogram", miniprogram);

			json.put("topcolor", "#FF0000");
			JSONObject data = new JSONObject();
			json.put("data", data);

			JSONObject first = new JSONObject();
			first.put("value", "");
			first.put("color", "#489b4c");

			JSONObject keyword1 = new JSONObject();
			keyword1.put("value", "");
			keyword1.put("color", "#173177");

			JSONObject remark = new JSONObject();
			remark.put("value", "");
			remark.put("color", "#f44336");

			data.put("first", first);
			data.put("keyword1", keyword1);
			data.put("remark", remark);

			System.out.println("=========send=============" + json.toString());

			ApiResult rs = TemplateMsgApi.send(json.toString());
			System.out.println(rs.getErrorMsg());
			return new Message(1, "发送消息成功");
		} else {
			return new Message(0, "发送消息失败：未找到模板");
		}
	}
}
