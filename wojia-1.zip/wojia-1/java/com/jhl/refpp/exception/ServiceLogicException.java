package com.jhl.refpp.exception;

import java.util.Date;

import com.jhl.refpp.po.SerialNo; 
import com.jhl.refpp.util.DBC;

/***
 * 服务逻辑处理错误
 * 
 * @author 蒋海林
 * 
 */
public class ServiceLogicException extends Exception {
	private static final long serialVersionUID = 1L;
	private SerialNo serialNo;

	public SerialNo getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(SerialNo serialNo) {
		this.serialNo = serialNo;
	}

	public ServiceLogicException(String errorMsg, SerialNo serialNo) {
		super(errorMsg);
		this.serialNo = serialNo;
		if (serialNo != null) {
			// 记录流水
			serialNo.setLevel(DBC.YES);
			serialNo.setTrace(serialNo.getDetail());
			serialNo.setId(new Date().getTime() + "");
			serialNo.setCreatedAt(new Date());
			//MapperFactory.serialNoMapper.insert(serialNo);
		}
	}

	public ServiceLogicException(String errorMsg) {
		super(errorMsg);

	}

}
