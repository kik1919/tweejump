package com.jhl.refpp.exception;

/***
 * 系统核心支持项错误
 * 
 * @author 蒋海林
 * 
 */
public class SupportException extends Exception {
	private static final long serialVersionUID = 1L;

	public SupportException(String errorMsg) {
		super(errorMsg);
	}

}
