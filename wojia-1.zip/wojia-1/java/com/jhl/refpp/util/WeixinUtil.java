package com.jhl.refpp.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.kit.PropKit;
import com.jfinal.weixin.sdk.api.ApiConfig;
import com.jfinal.weixin.sdk.utils.HttpUtils;
import com.jfinal.weixin.sdk.utils.JsonUtils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * 
 * @author Javen
 * @Email javenlife@126.com 公众平台通用接口工具类
 */
public class WeixinUtil {
	/**
	 * 获取配置
	 */
	public static ApiConfig getApiConfig(String file) {
		ApiConfig ac = new ApiConfig();

		// 配置微信 API 相关常量
		ac.setToken(PropKit.getProp(file).get("token"));
		ac.setAppId(PropKit.getProp(file).get("appId"));
		ac.setAppSecret(PropKit.getProp(file).get("appSecret"));

		/**
		 * 是否对消息进行加密，对应于微信平台的消息加解密方式： 1：true进行加密且必须配置 encodingAesKey
		 * 2：false采用明文模式，同时也支持混合模式
		 */
		ac.setEncryptMessage(PropKit.getProp(file).getBoolean("encryptMessage", false));
		ac.setEncodingAesKey(PropKit.getProp(file).get("encodingAesKey", "setting it in config file"));
		return ac;
	}

	/**
	 * emoji表情转换(hex -> utf-16)
	 *
	 * @param hexEmoji
	 * @return
	 */
	public static String emoji(int hexEmoji) {
		return String.valueOf(Character.toChars(hexEmoji));
	}

	/**
	 * UTF-8编码
	 *
	 * @param source
	 * @return
	 */
	public static String urlEncodeUTF8(String source) {
		try {
			return URLEncoder.encode(source, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}

	public static void loadProp(String pro) {
		PropKit.use(pro);
	}

	/***
	 * 生成小程序二维码
	 * 
	 * @param name
	 * @param sceneStr
	 * @param accessToken
	 */
	public static String getminiqrQr(String path, String sceneStr, String accessToken) {
		return _getminiqrQr(path, null, sceneStr, accessToken);
	}

	/***
	 * 生成小程序二维码
	 * 
	 * @param name
	 * @param sceneStr
	 * @param accessToken
	 */
	public static String getminiqrQr(String path, String page, String sceneStr, String accessToken) {
		return _getminiqrQr(path, page, sceneStr, accessToken);
	}

	/***
	 * 生成小程序二维码
	 * 
	 * @param name
	 * @param sceneStr
	 * @param accessToken
	 */
	public static String _getminiqrQr(String path, String page, String sceneStr, String accessToken) {
		try {
			if (StringUtils.isNullOrEmpty(page)) {
				page = "pages/index/index";
			}
			// 发送请求参数
			JSONObject paramJson = new JSONObject();
			paramJson.put("scene", sceneStr);
			paramJson.put("page", page);
			paramJson.put("width", 400);
			// paramJson.put("auto_color", true);
			System.out.println("===sceneStr=====" + sceneStr);
			InputStream in = HttpUtils.download(
					"https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + accessToken,
					JsonUtils.toJson(paramJson));

			// 开始获取数据
			String headPic = path;
			String dest = Util.appRoot + headPic;
			Util.writeToLocal(dest, in);
			return "data:image/png;base64," + Img2Base64Util.getImgStr(dest);
			// return headPic;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public static void main(String[] args) throws Exception {
		String accessToken = WeixinUtil.postToken("wx94ded5fa15ee6dc6", "6e2eb14c80b9dc7b1bd5efa70b221572 ");// 生产小程序
	 
		System.out.println("======accessToken=======" + accessToken);
 
		// 新店开业活动信息页面二维码
		String mySpBuyPage = WeixinUtil.getminiqrQr("img/myspQrcode.jpg", "pages/mysp/mysp", "#", accessToken);// 第一个为参数 
		
		
	}
 
	/**
	 * 用于获取access_token
	 * 
	 * @param params
	 * @param APIKEY
	 *            小程序id
	 * @param SECRETKEY
	 *            小程序密钥
	 * @return access_token
	 * @throws Exception
	 */
	public static String postToken(String APIKEY, String SECRETKEY) throws Exception {
		String requestUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + APIKEY
				+ "&secret=" + SECRETKEY;
		URL url = new URL(requestUrl);
		// 打开和URL之间的连接
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		// 设置通用的请求属性
		connection.setRequestProperty("Content-Type", "application/json");
		connection.setRequestProperty("Connection", "Keep-Alive");
		connection.setUseCaches(false);
		connection.setDoOutput(true);
		connection.setDoInput(true);

		// 得到请求的输出流对象
		DataOutputStream out = new DataOutputStream(connection.getOutputStream());
		out.writeBytes("");
		out.flush();
		out.close();

		// 建立实际的连接
		connection.connect();
		// 定义 BufferedReader输入流来读取URL的响应
		BufferedReader in = null;
		if (requestUrl.contains("nlp"))
			in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "GBK"));
		else
			in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
		String result = "";
		String getLine;
		while ((getLine = in.readLine()) != null) {
			result += getLine;
		}
		in.close();
		JSONObject jsonObject = JSON.parseObject(result);
		String accesstoken = jsonObject.getString("access_token");
		return accesstoken;
	}
}