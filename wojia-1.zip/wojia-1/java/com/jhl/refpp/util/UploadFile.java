package com.jhl.refpp.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/*******************************************************************************
 * 当表单存在上传文件的时候，使用此类取参数和文件(需要commons-fileupload和commons.io的支持)
 * 
 * @author 蒋海林
 * @version version1.0
 */
public class UploadFile {
	private List<FileItem> items = new ArrayList<FileItem>();
	private List<FileItem> uploaditems = new ArrayList<FileItem>();
	private List<String> valueitems = new ArrayList<String>();
	private HashMap<String, ArrayList<Object>> map = new HashMap<String, ArrayList<Object>>();
	boolean isLoad = false;

	private UploadFile() {
	}

	/***************************************************************************
	 * 解析请求值
	 * 
	 * @param request
	 */
	public static UploadFile parser(HttpServletRequest request) throws Exception {
		return parser(request, null);
	}

	/***************************************************************************
	 * 解析请求值
	 * 
	 * @param request
	 */
	public static UploadFile parser(HttpServletRequest request, ProgressListener progressListener) throws Exception {
		if (!UploadFile.isUploadRequest(request)) {
			return null;
		}
		UploadFile uploadFile = new UploadFile();
		if (!uploadFile.isLoad) {
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setHeaderEncoding("utf-8");
			if (progressListener != null) {
				upload.setProgressListener(progressListener);// 设置进度监听器
			}

			List parseRequest;
			try {
				parseRequest = upload.parseRequest(request);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			uploadFile.items = parseRequest;
			for (FileItem fileItem : uploadFile.items) {

				String name = fileItem.getFieldName();
				if (uploadFile.map.get(name) == null) {
					ArrayList<Object> values = new ArrayList<Object>();
					if (fileItem.isFormField()) {
						String val = fileItem.getString();
						values.add(val);
						uploadFile.valueitems.add(val);
					} else {
						if (fileItem.getSize() != 0) {
							values.add(fileItem);
							uploadFile.uploaditems.add(fileItem);
						}
					}
					uploadFile.map.put(name, values);
				} else {
					ArrayList<Object> values = uploadFile.map.get(name);
					if (fileItem.isFormField()) {
						String val = fileItem.getString();
						values.add(val);
						uploadFile.valueitems.add(val);
					} else {
						if (fileItem.getSize() != 0) {
							values.add(fileItem);
							uploadFile.uploaditems.add(fileItem);
						}
					}
					uploadFile.map.put(name, values);
				}
			}
			uploadFile.isLoad = true;
		}
		return uploadFile;
	}

	/***************************************************************************
	 * 是否是上传请求
	 * 
	 * @param request
	 * @return
	 */
	public static boolean isUploadRequest(HttpServletRequest request) {
		String type = request.getContentType();
		if (type == null) {
			type = "";
		}
		if (type.toLowerCase().contains("multipart/form-data")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 获取所有上传文件
	 * 
	 * @return
	 */
	public List<FileItem> getAllUploadFile() {
		return uploaditems;
	}

	/***************************************************************************
	 * 获取所有非上传文件
	 * 
	 * @return
	 */
	public List<String> getAllValues() {
		return valueitems;
	}

	/***************************************************************************
	 * 获取所有参数名集合
	 * 
	 * @return
	 */
	public Iterator<String> getParamterNames() {
		Iterator<String> i = map.keySet().iterator();
		return i;
	}

	/***************************************************************************
	 * 获取某个参数的所有值集合
	 * 
	 * @param name
	 * @return
	 */
	public List<Object> getValues(String name) {
		return map.get(name);
	}

	/***************************************************************************
	 * 获取某个参数的值(针对一个变量对应一个值，如有多个值，请使用getValues方法)
	 * 
	 * @param name
	 * @return
	 */
	public String getParameter(String name, String defaultVal) {
		List<Object> list = getValues(name);
		if (list == null) {
			return defaultVal;
		} else {
			if (list.size() == 0) {
				return defaultVal;
			} else {
				return list.get(0).toString();
			}

		}
	}

	/***************************************************************************
	 * 获取上传文件(针对一个变量对应一个文件，如有多个文件，请使用getValues方法)
	 * 
	 * @param name
	 * @return
	 */
	public FileItem getFile(String name) {
		List<Object> list = getValues(name);
		if (list == null) {
			return null;
		} else {
			if (list.size() == 0) {
				return null;
			} else {
				return (FileItem) list.get(0);
			}
		}
	}

	/***************************************************************************
	 * 上传的文件是否存在(针对一个变量对应一个文件，如有多个文件，请使用getValues方法获取所有文件一一判断)
	 * 
	 * @param name
	 *            文件表单名
	 * @return
	 */
	public boolean exists(String name) {
		if (this.getFile(name) == null) {
			return false;
		} else {
			return true;
		}
	}

	/***************************************************************************
	 * 上传的文件是否存在
	 * 
	 * @param FileItem
	 * 
	 * @return
	 */
	public boolean exists(FileItem file) {
		if (file.getSize() == 0) {
			return false;
		} else {
			return true;
		}
	}

	/***************************************************************************
	 * 获取文件的名称
	 * 
	 * @param name
	 * @return
	 */
	public String getFileShortName(String name) {
		try {
			String shortname = "";
			List<Object> list = getValues(name);
			if (list != null) {
				FileItem file = (FileItem) list.get(0);
				String pathName = file.getName();
				int i = pathName.lastIndexOf("/");
				if (i == -1) {
					i = pathName.lastIndexOf("\\");
				}
				if (i != -1) {
					shortname = pathName.substring(i + 1);
				}
			}
			return shortname;
		} catch (Exception e) {
			return "";
		}
	}

	/***************************************************************************
	 * 获取文件的名称集合
	 * 
	 * @param name
	 * @return
	 */
	public ArrayList<String> getFileShortNameArray(String name) {
		ArrayList<String> namelist = new ArrayList<String>();
		List<Object> list = getValues(name);
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				FileItem file = (FileItem) list.get(i);
				String pathName = file.getName();
				int s = pathName.lastIndexOf("/");
				if (s == -1) {
					s = pathName.lastIndexOf("\\");
				}
				String shortname = null;
				if (s != -1) {
					shortname = pathName.substring(s + 1);
				}
				namelist.add(shortname);
			}
		}
		return namelist;
	}

	/***************************************************************************
	 * 获取文件后缀字符串
	 * 
	 * @param name
	 * @return
	 */
	public String getFileSuffix(String name) {

		try {
			String suffix = "";
			List<Object> list = getValues(name);
			if (list != null) {
				FileItem file = (FileItem) list.get(0);
				String pathName = file.getName();
				int i = pathName.lastIndexOf(".");
				if (i != -1) {
					suffix = pathName.substring(i + 1);
				}
			}
			return suffix;
		} catch (Exception e) {
			return "";
		}
	}

	/***************************************************************************
	 * 获取文件后缀字符串
	 * 
	 * @param name
	 * @return
	 */
	public String getFileSuffix(FileItem file) {

		try {
			String suffix = "";
			String pathName = file.getName();
			int i = pathName.lastIndexOf(".");
			if (i != -1) {
				suffix = pathName.substring(i + 1);
			}
			return suffix;
		} catch (Exception e) {
			return "";
		}
	}

	/***************************************************************************
	 * 获取文件后缀集合
	 * 
	 * @param name
	 * @return
	 */
	public ArrayList<String> getFileSuffixArray(String name) {
		ArrayList<String> suffixList = new ArrayList<String>();

		List<Object> list = getValues(name);
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				FileItem file = (FileItem) list.get(i);
				String pathName = file.getName();
				int s = pathName.lastIndexOf(".");
				String suffix = null;
				if (s != -1) {
					suffix = pathName.substring(s + 1);
				}
				suffixList.add(suffix);
			}

		}
		return suffixList;
	}

	/***************************************************************************
	 * 如果指定的参数名的值为文件流，则保存在指定路径下，如果为普通表单值，将抛出异常
	 * 
	 * @param name
	 * @param savePath
	 * @throws Exception
	 */
	public void save(String name, String savePath) throws Exception {
		getFile(name).write(new File(savePath));
	}

	/***************************************************************************
	 * 如果指定的参数名的值为文件流，则保存在指定路径下， 如果为普通表单值，将抛出异常
	 * 
	 * @param name
	 *            表单名
	 * @param saveDir
	 *            保存的文件夾路徑，如果不存在将新建
	 * @param newName
	 *            新命名
	 * @throws Exception
	 */
	public void save(String name, String saveDir, String newName) throws Exception {
		File file = new File(saveDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		getFile(name).write(new File(saveDir + newName));
	}

	/***************************************************************************
	 * 保存文件
	 * 
	 * @param fileItem
	 * @param saveDir
	 *            保存的文件夾路徑，如果不存在将新建
	 * @param newName
	 *            新命名
	 * @throws Exception
	 */
	public void save(FileItem fileItem, String saveDir, String newName) throws Exception {
		File file = new File(saveDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		fileItem.write(new File(saveDir + newName));
	}

	/***
	 * 下载文件
	 * 
	 * @param srcFile
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	public static void downloadStream(String srcFile, HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// 读出流
		File file = new File(srcFile);
		FileInputStream fis = new FileInputStream(file);

		long filelength = file.length();
		System.out.println("******" + filelength);
		System.out.println("******" + file.getTotalSpace());
		String downloadfilename = file.getName();

		long hadDownloadLength = 0;// 记录已下载文件大小
		int rangeSwitch = 0;// 0：从头开始的全文下载；1：从某字节开始的下载（bytes=27000-）；2：从某字节开始到某字节结束的下载（bytes=27000-39000）
		long toLength = 0;// 记录客户端需要下载的字节段的最后一个字节偏移量（比如bytes=27000-39000，则这个值是为39000）
		long contentLength = 0;// 客户端请求的字节总量
		String rangeBytes = "";// 记录客户端传来的形如“bytes=27000-”或者“bytes=27000-39000”的内容
		OutputStream os = null;// 写出数据
		OutputStream out = null;// 缓冲
		byte b[] = new byte[1024];// 暂存容器

		String range = request.getHeader("Range");// 客户端下载软件请求的数据格式（bytes=27000-39000）
		System.out.println("Range======" + range);
		if (range != null) {// 客户端请求的下载的文件块的开始字节
			response.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
			rangeBytes = range.replaceAll("bytes=", "");// 记录客户端传来的形如“bytes=27000-”或者“bytes=27000-39000”的内容
			if (rangeBytes.indexOf('-') == rangeBytes.length() - 1) {// bytes=969998336-
				rangeBytes = rangeBytes.substring(0, rangeBytes.indexOf('-'));// 获取开始字节

				rangeSwitch = 1;
				hadDownloadLength = Long.parseLong(rangeBytes.trim());
				contentLength = filelength - hadDownloadLength + 1;// 客户端请求的是969998336之后的字节
			} else {// bytes=1275856879-1275877358
				rangeSwitch = 2;
				String temp0 = rangeBytes.substring(0, rangeBytes.indexOf('-'));
				String temp2 = rangeBytes.substring(rangeBytes.indexOf('-') + 1, rangeBytes.length());
				hadDownloadLength = Long.parseLong(temp0.trim());// bytes=1275856879-1275877358，从第1275856879个字节开始下载
				toLength = Long.parseLong(temp2);// bytes=1275856879-1275877358，到第1275877358个字节结束
				contentLength = toLength - hadDownloadLength + 1;// 客户端请求的是1275856879-1275877358之间的字节
			}
		} else {// 从开始进行下载
			contentLength = filelength;// 客户端要求全文下载
		}

		if (hadDownloadLength != 0) {
			// 不是从最开始下载,
			// 响应的格式是:
			// Content-Range: bytes [文件块的开始字节]-[文件的总大小 - 1]/[文件的总大小]
			switch (rangeSwitch) {
			case 1: {// 针对 bytes=27000- 的请求
				String contentRange = new StringBuffer("bytes ").append(new Long(hadDownloadLength).toString())
						.append("-").append(new Long(filelength).toString()).append("/")
						.append(new Long(filelength).toString()).toString();
				response.setHeader("Content-Range", contentRange);
				System.out.println("Content-Range==1==" + contentRange);
				break;
			}
			case 2: {// 针对 bytes=27000-39000 的请求
				String contentRange = rangeBytes + "/" + new Long(filelength).toString();
				response.setHeader("Content-Range", contentRange);
				System.out.println("Content-Range==2==" + contentRange);
				break;
			}
			default: {
				break;
			}
			}
		}

		/**
		 * 如果设设置了Content-Length，则客户端会自动进行多线程下载。如果不希望支持多线程，则不要设置这个参数。 响应的格式是:
		 * Content-Length: [文件的总大小] - [客户端请求的下载的文件块的开始字节]
		 * ServletActionContext.getResponse().setHeader("Content-Length", new
		 * Long(file.length() - p).toString());
		 */
		// response.reset();// 告诉客户端允许断点续传多线程连接下载,响应的格式是:Accept-Ranges: bytes
		response.setHeader("Accept-Ranges", "bytes");// 如果是第一次下,还没有断点续传,状态是默认的200,无需显式设置;响应的格式是:HTTP/1.1200OK
		response.setContentType(Util.setContentType(downloadfilename));
		response.setContentLength((int) filelength);
		String contentDisposition = "attachment; filename=" + CharEncode.utf_to_iso(downloadfilename);
		response.setHeader("Content-Disposition", contentDisposition);
		response.setHeader("Cache-control", "public");
		response.setHeader("Pragma", "public");

		os = response.getOutputStream();
		out = new BufferedOutputStream(os);

		switch (rangeSwitch) {
		case 0: {
			System.out.println("Support commonly download!");
			// 普通下载，或者从头开始的下载
			int n = 0;
			while ((n = fis.read(b, 0, 1024)) != -1) {
				out.write(b, 0, n);
			}
			break;
		}
		case 1: {
			System.out.println("Support resume broken downloads!");
			// 针对 bytes=27000- 的请求
			fis.skip(hadDownloadLength);// 形如bytes=969998336-的客户端请求，跳过969998336个字节
			int n = 0;
			while ((n = fis.read(b, 0, 1024)) != -1) {
				out.write(b, 0, n);
			}
			break;
		}
		case 2: {// 针对 bytes=27000-39000 的请求
			System.out.println("Resume broken downloads,support xunlei download!");
			fis.skip(hadDownloadLength);// 形如bytes=1275856879-1275877358的客户端请求，找到第1275856879个字节
			int n = 0;
			long readLength = 0;// 记录已读字节数
			while (readLength <= contentLength - 1024) {// 大部分字节在这里读取
				n = fis.read(b, 0, 1024);
				readLength += 1024;
				out.write(b, 0, n);
			}
			if (readLength <= contentLength) {// 余下的不足 1024 个字节在这里读取
				n = fis.read(b, 0, (int) (contentLength - readLength));
				out.write(b, 0, n);
			}
		}
		default: {
			break;
		}

		}
		out.flush();
		fis.close();
	}
}
