package com.jhl.refpp.util;

public class DBC {

	/***
	 * 老板
	 */
	public static int BOSS = 1;
	/***
	 * 员工
	 */
	public static int EMPLOYEE = 2;

	/***
	 * 用户
	 */
	public static int CUSTOMER = 3;

	/***
	 * 店长
	 */
	public static int SELLER = 4;

	/***
	 * 会员级别（普通用户）
	 */
	public static int VIP1 = 1;
	/***
	 * 会员级别（普通会员）
	 */
	public static int VIP2 = 2;
	/***
	 * 会员级别（黄金会员）
	 */
	public static int VIP3 = 3;

	/***
	 * 公众号
	 */
	public static int PLATFORM_H5 = 0;

	/***
	 * 小程序
	 */
	public static int PLATFORM_PRO = 1;

	/***
	 * 支付（订单）
	 */
	public static int PAY_0 = 0; 
	

	/***
	 * 否
	 */
	public static int NO = 0;
	/***
	 * 是
	 */
	public static int YES = 1;

	/***
	 * 等级1
	 */
	public static int LEVEL_1 = 1;
	/***
	 * 等级2
	 */
	public static int LEVEL_2 = 2;
	/***
	 * 等级3
	 */
	public static int LEVEL_3 = 3;
	/***
	 * 等级4
	 */
	public static int LEVEL_4 = 4;
	/***
	 * 等级5
	 */
	public static int LEVEL_5 = 5; 
}
