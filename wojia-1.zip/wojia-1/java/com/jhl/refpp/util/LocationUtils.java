package com.jhl.refpp.util;

import com.spatial4j.core.context.SpatialContext;
import com.spatial4j.core.distance.DistanceUtils;
import com.spatial4j.core.io.GeohashUtils;
import com.spatial4j.core.shape.Rectangle;

import ch.hsr.geohash.GeoHash;

public class LocationUtils {

	private static double EARTH_RADIUS = 6378.137;

	private static double rad(double d) {
		return d * Math.PI / 180.0;
	}

	/**
	 * 通过经纬度获取距离(单位：米)
	 * 
	 * @param lat1
	 * @param lng1
	 * @param lat2
	 * @param lng2
	 * @return
	 */
	public static double getDistance(double lat1, double lng1, double lat2, double lng2) {
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1) - rad(lng2);
		double s = 2 * Math.asin(Math.sqrt(
				Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = Math.round(s * 10000d) / 10000d;
		s = s * 1000;
		return s;
	}

	public static void main(String[] args) {
		// 移动设备经纬度
		double lon = 104.06881, lat = 30.681558;
		// 千米
		int radius = 10;

		SpatialContext geo = SpatialContext.GEO;
		Rectangle rectangle = geo.getDistCalc().calcBoxByDistFromPt(
		        geo.makePoint(lon, lat), radius * DistanceUtils.KM_TO_DEG, geo, null);
		//System.out.println(rectangle.getMinX() + "-" + rectangle.getMaxX());// 经度范围
		//System.out.println(rectangle.getMinY() + "-" + rectangle.getMaxY());// 纬度范围
		
		//geohash length width height 1 5,009.4km 4,992.6km 2 1,252.3km 624.1km 3 156.5km 156km 4 39.1km 19.5km 5 4.9km 4.9km 6 1.2km 609.4m 7 152.9m 152.4m 8 38.2m 19m 9 4.8m 4.8m 10 1.2m 59.5cm 11 14.9cm 14.9cm 12 3.7cm 1.9cm
		String geoCode=GeohashUtils.encodeLatLon(lat, lon, 12);//计算code
		System.out.println(geoCode);
		
		 
		GeoHash geoHash = GeoHash.withCharacterPrecision(lat, lon, 10);
		// 当前
		//System.out.println(geoHash.toBase32());
		// N, NE, E, SE, S, SW, W, NW 计算出周围8个网格的geohash
		GeoHash[] adjacent = geoHash.getAdjacent();
		for (GeoHash hash : adjacent) {
		    //System.out.println(hash.toBase32());
		}
		
		
		// 商户经纬度
		double lon2 = 116.312528, lat2 = 39.983733; 
		double distance = geo.calcDistance(geo.makePoint(lon, lat), geo.makePoint(lon2, lat2)) 
		    * DistanceUtils.DEG_TO_KM;
		//System.out.println(distance);// KM
	}
}
