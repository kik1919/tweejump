package com.jhl.refpp.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*******************************************************************************
 * 时间工具类
 * 
 * @author 蒋海林
 * 
 */
public class DateParser {

	public static String sign = "-";
	private static String YYYYMMDDHHMMSS = "yyyy" + sign + "MM" + sign
			+ "dd HH:mm:ss";
	private static String YYYYMMDD = "yyyy" + sign + "MM" + sign + "dd";

	/***
	 * 获取当前时间,字符串为标准yyyy-mm-dd hh:mm:ss格式
	 * 
	 * @return
	 */
	public static String getCurTime() {
		return DateParser.StringTime(Calendar.getInstance());
	}

	/***
	 * 获取当前时间,字符串为标准yyyy-mm-dd格式
	 * 
	 * @return
	 */
	public static String getCurDate() {
		return DateParser.StringDate(Calendar.getInstance());
	}

	/***************************************************************************
	 * 包装时间字符串为标准yyyy-mm-dd hh:mm:ss格式
	 * 
	 * @param date
	 * @return
	 * @throws Exception
	 */
	public static String StringTime(String date) throws Exception {
		DateFormat df = new SimpleDateFormat(YYYYMMDDHHMMSS);
		Date s = df.parse(date);
		return df.format(s);
	}

	/***
	 * 包装时间字符串为标准yyyy-mm-dd格式
	 * 
	 * @param date
	 * @return
	 * @throws Exception
	 */
	public static String StringDate(String date) throws Exception {
		DateFormat df = new SimpleDateFormat(YYYYMMDD);
		Date tmp = df.parse(date);
		return df.format(tmp);
	}

	/***************************************************************************
	 * 把Calendar时间转换成yyyy-mm-dd hh:mm:ss时间字符串
	 * 
	 * @param time
	 * @return
	 */
	public static String StringTime(Calendar time) {
		return DateParser.StringTime(time.getTime());
	}

	/***************************************************************************
	 * 把Calendar时间转换成yyyy-mm-dd时间字符串
	 * 
	 * @param time
	 * @return
	 */
	public static String StringDate(Calendar time) {
		return DateParser.StringDate(time.getTime());
	}

	/***************************************************************************
	 * 把Date时间转换成yyyy-mm-dd HH:mm:ss时间字符串
	 * 
	 * @param time
	 * @return
	 */
	public static String StringTime(Date time) {
		DateFormat dateFm = new SimpleDateFormat(YYYYMMDDHHMMSS);
		return dateFm.format(time);
	}

	/***************************************************************************
	 * 把Date时间转换成yyyy-mm-dd时间字符串
	 * 
	 * @param time
	 * @return
	 */
	public static String StringDate(Date time) {
		DateFormat dateFm = new SimpleDateFormat(YYYYMMDD);
		return dateFm.format(time);
	}

	/***************************************************************************
	 * 把Calendar时间转换成Date时间
	 * 
	 * @param time
	 * @return
	 */
	public static Date parserDate(Calendar time) {
		return time.getTime();
	}

	/***************************************************************************
	 * 把String时间转换成Date时间
	 * 
	 * @param time
	 * @return
	 * @throws Exception
	 */
	public static Date parserDate(String time) throws Exception {
		return DateParser.parserDate(DateParser.getTime(time));
	}
	
	public static Date parserDate2(String time) throws Exception {
		return DateParser.parserDate(DateParser.getDate(time));
	}
	
	public static void main(String[] args) {
		try {
			System.out.println(DateParser.StringTime(DateParser.parserDate("2019-10-10 00:00:00")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/***************************************************************************
	 * 根据字符串时间设置Calendar对象
	 * 
	 * @param time
	 * @return
	 * @throws Exception
	 */
	public static Calendar getDate(String time) throws Exception {
		SimpleDateFormat sdf2 = new SimpleDateFormat(YYYYMMDD);
		Date date = sdf2.parse(time);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c;
	}

	public static Calendar getTime(String time) throws Exception {
		SimpleDateFormat sdf2 = new SimpleDateFormat(YYYYMMDDHHMMSS);
		Date date = sdf2.parse(time);
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c;
	}

	/***
	 * 根据传入的时间计算本月的第一天和最后一天
	 * 
	 * @param time
	 * @return
	 * @throws Exception
	 */
	public static StatDate getStartAndEndDayForMonth(Calendar time)
			throws Exception {
		StatDate my = new StatDate();
		int month = time.get(Calendar.MONTH) + 1;
		int year = time.get(Calendar.YEAR);
		int maxDay = time.getActualMaximum(Calendar.DATE);

		String start = year + sign + month + sign + 1;
		String end = year + sign + month + sign + maxDay;
		my.setStart(DateParser.StringDate(start));
		my.setEnd(DateParser.StringDate(end));

		Date startDate = DateParser.parserDate(start);
		Date endDate = DateParser.parserDate(end);
		my.setStartDate(startDate);
		my.setEndDate(endDate);

		Calendar startCalendar = DateParser.getDate(start);
		Calendar endCalendar = DateParser.getDate(end);
		my.setStartCalendar(startCalendar);
		my.setEndCalendar(endCalendar);

		return my;
	}

	/***************************************************************************
	 * 计算来两个时间相差天数
	 * 
	 * @param start
	 * @param end
	 * @return
	 * @throws Exception
	 */
	public static long differDay(String start, String end) throws Exception {
		Date startDate = DateParser.parserDate(start);
		Date endDate = DateParser.parserDate(end);
		long diff = endDate.getTime() - startDate.getTime();
		long days = diff / (1000 * 60 * 60 * 24);
		return days;
	}

	/***************************************************************************
	 * 计算来两个时间相差天数
	 * 
	 * @param start
	 * @param end
	 * @return
	 * @throws Exception
	 */
	public static long differDay(Calendar start, Calendar end) throws Exception {
		return DateParser.differDay(DateParser.StringTime(start),
				DateParser.StringTime(end));
	}

	/***************************************************************************
	 * 计算来两个时间相差小时
	 * 
	 * @param start
	 * @param end
	 * @return
	 * @throws ParseException
	 */
	public static long differHour(Calendar start, Calendar end)
			throws ParseException {
		Date startDate = DateParser.parserDate(start);
		Date endDate = DateParser.parserDate(end);
		long diff = endDate.getTime() - startDate.getTime();
		long days = diff / (1000 * 60 * 60);
		return days;
	}

	/***
	 * 计算来两个时间相差小时
	 * 
	 * @param start
	 * @param end
	 * @return
	 * @throws Exception
	 */
	public static long differHour(String start, String end) throws Exception {
		return DateParser.differHour(DateParser.getDate(start),
				DateParser.getDate(end));
	}

	/***************************************************************************
	 * 时区转换
	 * 
	 * @param curTime
	 * @param curTimeZone
	 * @param toTimeZone
	 * @return
	 * @throws Exception
	 */
	public static String transform(Calendar curTime, int curTimeZone,
			int toTimeZone) throws Exception {

		long start_hour = curTime.get(Calendar.HOUR_OF_DAY);// 开始时间小时

		long resultHour = start_hour - (curTimeZone - toTimeZone);
		if (resultHour < 0) {
			// 当算出的区时为负数时，应加上24:00，日期减一天
			resultHour = resultHour + 24;
			curTime.add(Calendar.DATE, -1);
		} else if (resultHour >= 24) {
			// 当算出的区时大于或等于24:00时，应减去24:00，日期加一天
			resultHour = resultHour - 24;
			curTime.add(Calendar.DATE, 1);
		}

		String resultDate = DateParser.StringDate(curTime) + " " + resultHour
				+ ":" + curTime.get(Calendar.MINUTE) + ":"
				+ curTime.get(Calendar.SECOND);

		return DateParser.StringTime(resultDate);

	}

	public static String getWeekDesc(String date) throws Exception {
		return DateParser.getWeekDesc(DateParser.getDate(date));
	}

	public static String getWeekDesc(Calendar date) throws Exception {
		String desc = "";
		int week = date.get(Calendar.DAY_OF_WEEK);
		if (week == 1) {
			desc = "周日";
		}
		if (week == 2) {
			desc = "周一";
		}
		if (week == 3) {
			desc = "周二";
		}
		if (week == 4) {
			desc = "周三";
		}
		if (week == 5) {
			desc = "周四";
		}
		if (week == 6) {
			desc = "周五";
		}
		if (week == 7) {
			desc = "周六";
		}
		return desc;
	}

}
