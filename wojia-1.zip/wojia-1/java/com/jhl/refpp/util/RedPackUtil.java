package com.jhl.refpp.util;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import org.apache.log4j.Logger;
import com.jfinal.kit.StrKit;
import com.jfinal.weixin.sdk.api.PaymentApi;
import com.jfinal.weixin.sdk.api.RedPackApi;
import com.jfinal.weixin.sdk.kit.PaymentKit;
import com.jfinal.weixin.sdk.utils.HttpUtils;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;

public class RedPackUtil {

	private static Logger logger = Logger.getLogger(RedPackUtil.class);

	/**
	 * 发送红包
	 * 
	 * @param openId
	 *            接收红包用户openid
	 * @param ammont
	 *            红包金额
	 */
	public static Message sendRedPack(String openId, String act_name, Integer ammont, String wishing, String remark,
			Para vo) throws Exception {
		System.out.println("=======开始发送红包（金额" + ammont + "）========");
		String nonce_str = Util.ID("UUID");
		String mch_billno = Util.getCusBillID();
		String mchId = vo.getString("mchId");
		String wxappid = vo.getString("appid");
		String send_name = vo.getString("name");
		String paternerKey = vo.getString("paternerKey");
		String rootid = vo.getString("id");
		String re_openid = openId;
		Integer total_amount = ammont;
		if (send_name != null && send_name.length() > 10) {
			send_name = send_name.substring(0, 10);
		}
		if (wishing != null && wishing.length() > 20) {
			wishing = wishing.substring(0, 20);
		}
		if (act_name != null && act_name.length() > 10) {
			act_name = act_name.substring(0, 10);
		}
		if (remark != null && remark.length() > 20) {
			remark = remark.substring(0, 20);
		}

		Integer total_num = 1;
		String client_ip = "127.0.0.1";
		/************************* 红包请求参数结束 ****************************/
		/************************* 生成签名 ****************************/
		SortedMap<String, String> packageParams = new TreeMap<String, String>();
		packageParams.put("nonce_str", nonce_str);
		packageParams.put("mch_billno", mch_billno);
		packageParams.put("mch_id", mchId);
		packageParams.put("wxappid", wxappid);
		packageParams.put("send_name", send_name);
		packageParams.put("scene_id", "PRODUCT_1");// 场景id
		packageParams.put("re_openid", re_openid);
		packageParams.put("total_amount", String.valueOf(total_amount));
		packageParams.put("total_num", String.valueOf(total_num));

		packageParams.put("wishing", wishing);// 红包祝福语
		packageParams.put("client_ip", client_ip);
		packageParams.put("act_name", act_name);// 活动名称
		packageParams.put("remark", remark);
		String sign = PaymentKit.createSign(packageParams, paternerKey);
		packageParams.put("sign", sign);

		String dest = Util.appRoot + "WEB-INF/cert/" + rootid;
		String certPath = dest + "/apiclient_cert.p12";
		System.out.println("=======certPath========" + certPath);
		String xmlResult = RedPackApi.sendRedPack(packageParams, certPath, mchId);
		Map<String, String> result = PaymentKit.xmlToMap(xmlResult);
		logger.info(result);
		String return_code = result.get("return_code");
		String return_msg = result.get("return_msg");
		if (StrKit.isBlank(return_code) || !"SUCCESS".equals(return_code)) {
			return new Message(0, "发送现金红包失败<br/>" + return_msg);
		}
		String result_code = result.get("result_code");
		String err_code_des = result.get("err_code_des");
		if (StrKit.isBlank(result_code) || !"SUCCESS".equals(result_code)) {
			return new Message(0, "发送现金红包失败<br/>" + err_code_des);
		}
		return new Message(1, "发送现金红包成功！");
	}

	/**
	 * 企业转账
	 * 
	 * @param openId
	 *            接收红包用户openid
	 * @param ammont
	 *            企业转账金额
	 */
	public static Message transfers(String openId, String username, Integer ammont, String remark, Para vo)
			throws Exception {
		System.out.println("=======开始企业转账（金额" + ammont + "）========");
		String nonce_str = Util.ID("UUID");
		String mch_billno = Util.getCusBillID();
		String mchId = vo.getString("mchId");
		String wxappid = vo.getString("appidWx");
		// String send_name = vo.getString("name");
		String paternerKey = vo.getString("paternerKey");
		String rootid = vo.getString("id");
		String re_openid = openId;
		Integer total_amount = ammont;
		String client_ip = "127.0.0.1";
		/************************* 红包请求参数结束 ****************************/
		/************************* 生成签名 ****************************/
		SortedMap<String, String> packageParams = new TreeMap<String, String>();
		packageParams.put("mch_appid", wxappid);
		packageParams.put("mchid", mchId);
		packageParams.put("nonce_str", nonce_str);
		packageParams.put("partner_trade_no", mch_billno);
		packageParams.put("openid", re_openid);
		packageParams.put("check_name", "NO_CHECK");// FORCE_CHECK
		packageParams.put("re_user_name", username);
		packageParams.put("amount", String.valueOf(total_amount));
		packageParams.put("desc", remark);

		packageParams.put("spbill_create_ip", client_ip);
		String sign = PaymentKit.createSign(packageParams, paternerKey);
		packageParams.put("sign", sign);

		String dest = Util.appRoot + "/WEB-INF/cert/" + rootid;

		String certPath = dest + "/apiclient_cert.p12";
		System.out.println("=======certPath========" + certPath);
		String xmlResult = transfers(packageParams, certPath, mchId);
		Map<String, String> result = PaymentKit.xmlToMap(xmlResult);
		logger.info("===result====" + result);
		String return_code = result.get("return_code");
		String return_msg = result.get("return_msg");
		if (StrKit.isBlank(return_code) || !"SUCCESS".equals(return_code)) {
			return new Message(0, "企业转账失败<br/>" + return_msg);
		}
		String result_code = result.get("result_code");
		String err_code_des = result.get("err_code_des");
		if (StrKit.isBlank(result_code) || !"SUCCESS".equals(result_code)) {
			return new Message(0, "企业转账失败<br/>" + err_code_des);
		}
		String payment_no = result.get("payment_no");
		return new Message(1, "企业转账成功！", new Para("wxOrderid", payment_no));
	}

	public static String transfers(Map<String, String> params, String certPath, String partner) {
		return HttpUtils.postSSL("https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers",
				PaymentKit.toXml(params), certPath, partner);
	}

	public static Message refund(String serviceid, String billid, String price, String refundPrice, Para shop,
			String desc) {

		String APPID = shop.getString("appid");
		String mchId = shop.getString("mchId");
		String send_name = shop.getString("name");
		String paternerKey = shop.getString("paternerKey");
		String rootid = shop.getString("id");

		Float fp = Float.valueOf(price);
		fp = fp * 100;
		int priceFen = fp.intValue();

		fp = Float.valueOf(refundPrice);
		fp = fp * 100;
		int refundPriceFen = fp.intValue();

		logger.info("微信退款开始============（金额" + refundPrice + "）=============================");
		Map<String, String> params = new HashMap<String, String>();

		params.put("appid", APPID);
		logger.info("appid===========" + APPID);

		params.put("mch_id", mchId);
		logger.info("mch_id===========" + mchId);

		params.put("out_trade_no", billid);// 订单ID
		logger.info("out_trade_no===========" + billid);

		params.put("out_refund_no", serviceid);// 退单ID
		logger.info("out_refund_no===========" + serviceid);

		params.put("total_fee", String.valueOf(priceFen));// 订单总金额
		logger.info("total_fee===========" + priceFen);

		params.put("refund_fee", String.valueOf(refundPriceFen));// 退款总金额
		logger.info("refund_fee===========" + refundPriceFen);

		if (desc == null || desc.equals("")) {
			params.put("refund_desc", "用户申请退款");
		} else {
			params.put("refund_desc", desc);
		}

		String dest = Util.appRoot + "/WEB-INF/cert/" + rootid;
		String certPath = dest + "/apiclient_cert.p12";
		System.out.println("=======certPath========" + certPath);

		Map<String, String> result = PaymentApi.refund(params, paternerKey, certPath);

		logger.info("微信退款请求响应报文:" + PaymentKit.toXml(result));

		String return_code = result.get("return_code");
		logger.info("签名结果代码===================" + return_code);
		String result_code = result.get("result_code");
		logger.info("业务结果===================" + result_code);
		String err_code_des = result.get("err_code_des");
		logger.info("错误结果===================" + err_code_des);

		if (StrKit.notBlank(return_code) && "SUCCESS".equals(return_code)) {
			if ("SUCCESS".equals(result_code)) {
				return new Message(1, err_code_des);
			} else {
				return new Message(0, err_code_des);
			}
		} else {
			return new Message(0, err_code_des);
		}
	}

	public static void main(String[] args) {
		// gh_9fda2ea12d52#wx7a189f600abb25ac#b54f0658beab95d5a042deaf515ecb9a#wechat_jinghaihuanyu#1485901412#SHOP201803141746175314.txt#f2gf3g2hej3g4f37d8s96cm98fkkd7zl#
		Para vo = new Para();
		vo.put("name", "蜜美月商城");
		vo.put("mchId", "1485901412");
		vo.put("appid", "wx7a189f600abb25ac");
		vo.put("paternerKey", "f2gf3g2hej3g4f37d8s96cm98fkkd7zl");
		vo.put("id", "S00000");
		try {
			Message mes = transfers("oPtotwmu0hgfcl57DdLwMr1qoYcg", "蒋海林", 100, "这是您在“克丽缇娜美容会所”门店外拓活动中获得的提成金额奖励", vo);

			// Message mes = sendRedPack("oPtotwmu0hgfcl57DdLwMr1qoYcg",
			// "营业额提现", 100, "这是您在“克丽缇娜美容会所”门店外拓活动中获得的提成金额奖励",
			// "这是您在“克丽缇娜美容会所”门店外拓活动中获得的提成金额奖励", vo);
			// Message mes =refund("R0002", "OI2018110302280738816", "0.01",
			// "0.02", vo, "测试退款");
			System.out.println("====" + mes.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
