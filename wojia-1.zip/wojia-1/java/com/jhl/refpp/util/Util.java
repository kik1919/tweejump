
package com.jhl.refpp.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
import com.jhl.refpp.po.Squence;
import com.jhl.refpp.po.SquenceExample;
import com.jhl.refpp.support.MapperFactory;

public class Util {

	public static AtomicLong userid_uniqeid = new AtomicLong(0);
	public static AtomicLong uniqeid = new AtomicLong(0);

	public static String appRoot = Util.class.getResource("/").getFile().toString().replaceAll("/WEB-INF/classes", "");

	public static String setContentType(String returnFileName) {
		String contentType = "application/octet-stream";
		if (returnFileName.lastIndexOf(".") < 0)
			return contentType;
		returnFileName = returnFileName.toLowerCase();
		returnFileName = returnFileName.substring(returnFileName.lastIndexOf(".") + 1);

		if (returnFileName.equals("html") || returnFileName.equals("htm") || returnFileName.equals("shtml")) {
			contentType = "text/html";
		} else if (returnFileName.equals("css")) {
			contentType = "text/css";
		} else if (returnFileName.equals("xml")) {
			contentType = "text/xml";
		} else if (returnFileName.equals("gif")) {
			contentType = "image/gif";
		} else if (returnFileName.equals("jpeg") || returnFileName.equals("jpg")) {
			contentType = "image/jpeg";
		} else if (returnFileName.equals("js")) {
			contentType = "application/x-javascript";
		} else if (returnFileName.equals("atom")) {
			contentType = "application/atom+xml";
		} else if (returnFileName.equals("rss")) {
			contentType = "application/rss+xml";
		} else if (returnFileName.equals("mml")) {
			contentType = "text/mathml";
		} else if (returnFileName.equals("txt")) {
			contentType = "text/plain";
		} else if (returnFileName.equals("jad")) {
			contentType = "text/vnd.sun.j2me.app-descriptor";
		} else if (returnFileName.equals("wml")) {
			contentType = "text/vnd.wap.wml";
		} else if (returnFileName.equals("htc")) {
			contentType = "text/x-component";
		} else if (returnFileName.equals("png")) {
			contentType = "image/png";
		} else if (returnFileName.equals("tif") || returnFileName.equals("tiff")) {
			contentType = "image/tiff";
		} else if (returnFileName.equals("wbmp")) {
			contentType = "image/vnd.wap.wbmp";
		} else if (returnFileName.equals("ico")) {
			contentType = "image/x-icon";
		} else if (returnFileName.equals("jng")) {
			contentType = "image/x-jng";
		} else if (returnFileName.equals("bmp")) {
			contentType = "image/x-ms-bmp";
		} else if (returnFileName.equals("svg")) {
			contentType = "image/svg+xml";
		} else if (returnFileName.equals("jar") || returnFileName.equals("var") || returnFileName.equals("ear")) {
			contentType = "application/java-archive";
		} else if (returnFileName.equals("doc")) {
			contentType = "application/msword";
		} else if (returnFileName.equals("pdf")) {
			contentType = "application/pdf";
		} else if (returnFileName.equals("rtf")) {
			contentType = "application/rtf";
		} else if (returnFileName.equals("xls")) {
			contentType = "application/vnd.ms-excel";
		} else if (returnFileName.equals("ppt")) {
			contentType = "application/vnd.ms-powerpoint";
		} else if (returnFileName.equals("7z")) {
			contentType = "application/x-7z-compressed";
		} else if (returnFileName.equals("rar")) {
			contentType = "application/x-rar-compressed";
		} else if (returnFileName.equals("swf")) {
			contentType = "application/x-shockwave-flash";
		} else if (returnFileName.equals("rpm")) {
			contentType = "application/x-redhat-package-manager";
		} else if (returnFileName.equals("der") || returnFileName.equals("pem") || returnFileName.equals("crt")) {
			contentType = "application/x-x509-ca-cert";
		} else if (returnFileName.equals("xhtml")) {
			contentType = "application/xhtml+xml";
		} else if (returnFileName.equals("zip")) {
			contentType = "application/zip";
		} else if (returnFileName.equals("mid") || returnFileName.equals("midi") || returnFileName.equals("kar")) {
			contentType = "audio/midi";
		} else if (returnFileName.equals("mp3")) {
			contentType = "audio/mpeg";
		} else if (returnFileName.equals("ogg")) {
			contentType = "audio/ogg";
		} else if (returnFileName.equals("m4a")) {
			contentType = "audio/x-m4a";
		} else if (returnFileName.equals("ra")) {
			contentType = "audio/x-realaudio";
		} else if (returnFileName.equals("3gpp") || returnFileName.equals("3gp")) {
			contentType = "video/3gpp";
		} else if (returnFileName.equals("mp4")) {
			contentType = "video/mp4";
		} else if (returnFileName.equals("mpeg") || returnFileName.equals("mpg")) {
			contentType = "video/mpeg";
		} else if (returnFileName.equals("mov")) {
			contentType = "video/quicktime";
		} else if (returnFileName.equals("flv")) {
			contentType = "video/x-flv";
		} else if (returnFileName.equals("m4v")) {
			contentType = "video/x-m4v";
		} else if (returnFileName.equals("mng")) {
			contentType = "video/x-mng";
		} else if (returnFileName.equals("asx") || returnFileName.equals("asf")) {
			contentType = "video/x-ms-asf";
		} else if (returnFileName.equals("wmv")) {
			contentType = "video/x-ms-wmv";
		} else if (returnFileName.equals("avi")) {
			contentType = "video/x-msvideo";
		}

		return contentType;
	}

	private static String _ID(String pre, Integer len) {
		Calendar c = Calendar.getInstance();
		String year = String.valueOf(c.get(Calendar.YEAR));
		String month = String.valueOf(c.get(Calendar.MONTH));
		String day = String.valueOf(c.get(Calendar.DATE));
		String hour = String.valueOf(c.get(Calendar.HOUR));
		String min = String.valueOf(c.get(Calendar.MINUTE));
		String sec = String.valueOf(c.get(Calendar.SECOND));
		String mi = String.valueOf(c.get(Calendar.MILLISECOND));
		month = month.length() < 2 ? "0" + month : month;
		day = day.length() < 2 ? "0" + day : day;
		hour = hour.length() < 2 ? "0" + hour : hour;
		min = min.length() < 2 ? "0" + min : min;
		sec = sec.length() < 2 ? "0" + sec : sec;
		String rs=  year + month + day + hour + min + sec + mi + uniqeid.getAndIncrement();
		if(len!=null) {
			int l=rs.length();
			int s=l-len;
			return pre +rs.substring(s);
		}else {
			return pre +rs;
		}
	}

	public static String ID(String pre) {
		return _ID(pre, null);
	}

	public static String ID(String pre, int len) {
		return _ID(pre, len);
	}

	public static String getCusBillID() {
		return ID("M");
	}

	public static String userID() {
		List<Squence> s = MapperFactory.squenceMapper.selectByExample(new SquenceExample());
		Squence squence = null;
		if (s == null || s.size() == 0) {
			squence = new Squence();
			squence.setId(Util.ID("SEQUENCE"));
			squence.setNum(0);
			MapperFactory.squenceMapper.insert(squence);
		} else {
			squence = s.get(0);
			squence.setNum(squence.getNum() + 1);
			MapperFactory.squenceMapper.updateByPrimaryKeySelective(squence);
		}
		String id = squence.getNum() + ""; 
		return id;
	}
 
	
	/**
	 * @param args
	 */
	public static void pullImage(String src, String dest) throws Exception {
		// new一个URL对象
		URL url = new URL(src);
		// 打开链接
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		// 设置请求方式为"GET"
		conn.setRequestMethod("GET");
		// 超时响应时间为5秒
		conn.setConnectTimeout(5 * 1000);
		// 通过输入流获取图片数据
		InputStream inStream = conn.getInputStream();
		// 得到图片的二进制数据，以二进制封装得到数据，具有通用性
		byte[] data = readInputStream(inStream);
		// new一个文件对象用来保存图片，默认保存当前工程根目录
		File imageFile = new File(dest);
		// 创建输出流
		FileOutputStream outStream = new FileOutputStream(imageFile);
		// 写入数据
		outStream.write(data);
		// 关闭输出流
		outStream.close();
	}

	/**
	 * 将InputStream写入本地文件
	 * 
	 * @param destination
	 *            写入本地目录
	 * @param input
	 *            输入流
	 * @throws IOException
	 */
	public static void writeToLocal(String destination, InputStream input) throws IOException {
		int index;
		byte[] bytes = new byte[1024];
		FileOutputStream downloadFile = new FileOutputStream(destination);
		while ((index = input.read(bytes)) != -1) {
			downloadFile.write(bytes, 0, index);
			downloadFile.flush();
		}
		downloadFile.close();
		input.close();
	}

	public static byte[] readInputStream(InputStream inStream) throws Exception {
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		// 创建一个Buffer字符串
		byte[] buffer = new byte[1024];
		// 每次读取的字符串长度，如果为-1，代表全部读取完毕
		int len = 0;
		// 使用一个输入流从buffer里把数据读取出来
		while ((len = inStream.read(buffer)) != -1) {
			// 用输出流往buffer里写入数据，中间参数代表从哪个位置开始读，len代表读取的长度
			outStream.write(buffer, 0, len);
		}
		// 关闭输入流
		inStream.close();
		// 把outStream里的数据写入内存
		return outStream.toByteArray();
	}

	public static int randomNum6() {
		int max = 999999;
		int min = 100000;
		Random random = new Random();
		int s = random.nextInt(max) % (max - min + 1) + min;
		return s;
	}

	public static String getFileSub(String path) {
		if (path == null) {
			return "";
		}
		int lastPointer = path.lastIndexOf(".");
		String sub = "";
		if (lastPointer != -1) {
			sub = path.substring(lastPointer);
		}
		return sub;
	}

	/***
	 * 判断集合是否有值
	 * 
	 * @param list
	 * @return
	 */
	public static boolean hasValue(List<?> list) {
		if (list != null && list.size() != 0) {
			return true;
		} else {
			return false;
		}
	}
 

	public static String getIp(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (!StringUtils.isEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)) {
			// 多次反向代理后会有多个ip值，第一个ip才是真实ip
			int index = ip.indexOf(",");
			if (index != -1) {
				return ip.substring(0, index);
			} else {
				return ip;
			}
		}
		ip = request.getHeader("X-Real-IP");
		if (!StringUtils.isEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)) {
			return ip;
		}
		return request.getRemoteAddr();
	}

	public static String printStackTraceToString(Throwable t) {
		StringWriter sw = new StringWriter();
		t.printStackTrace(new PrintWriter(sw, true));
		return sw.getBuffer().toString();
	}

	private static final ThreadLocal<HttpServletRequest> reqtl = new ThreadLocal<HttpServletRequest>();
	private static final ThreadLocal<HttpServletResponse> restl = new ThreadLocal<HttpServletResponse>();
	private static final ThreadLocal<HttpSession> sessiontl = new ThreadLocal<HttpSession>();

	public static HttpServletRequest getRequest() {
		return reqtl.get();
	}

	public static HttpServletResponse getResponse() {
		return restl.get();
	}

	public static HttpSession getSession() {
		return sessiontl.get();
	}

	public static void setRequest(HttpServletRequest req) {
		reqtl.set(req);
	}

	public static void setResponse(HttpServletResponse res) {
		restl.set(res);
	}

	public static void setSession(HttpSession res) {
		sessiontl.set(res);
	}

	public static void removeRequest() {
		reqtl.remove();
	}

	public static void removeResponse() {
		restl.remove();
	}

	public static void removeSession() {
		sessiontl.remove();
	}
}
