package com.jhl.refpp.util;

import java.io.UnsupportedEncodingException;

/*******************************************************************************
 * 提供java语言中常见字符编码转换方法，常见字符编码包括：UTF-8,GBK,ISO_8859_1,UNICODE
 * 
 * @author 蒋海林
 * @version version1.0
 * 
 */
public abstract class CharEncode {
	private CharEncode() {
	}

	/***************************************************************************
	 * 从ISO_8859_1编码转换城GBK编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String iso_to_gbk(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("iso-8859-1"), "GBK");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从UTF-8编码转换城GBK编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String utf_to_gbk(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("UTF-8"), "GBK");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从GBK编码转换城UTF-8编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String gbk_to_utf(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("GBK"), "UTF-8");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从ISO_8859_1编码转换城UTF-8编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String iso_to_utf(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("iso-8859-1"), "UTF-8");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从GBK编码转换城ISO_8859_1编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String gbk_to_iso(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("GBK"), "iso-8859-1");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从UTF-8编码转换城ISO_8859_1编码
	 * 
	 * @param text
	 *            文本内容
	 * @return 返回编码后的文本内容
	 */
	public static String utf_to_iso(String text) {
		if (text == null) {
			return null;
		}
		try {
			return new String(text.getBytes("UTF-8"), "iso-8859-1");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/***************************************************************************
	 * 从GBK编码转换城UNICODE编码
	 * 
	 * @param gbkStr
	 *            中文字符串
	 * @return 返回编码后的文本内容
	 */
	public static String gbk_to_unicode(String gbkStr) {
		if(gbkStr==null){
			return null;
		}
		char[] arChar = gbkStr.toCharArray();
		int iValue = 0;
		String uStr = "";
		for (int i = 0; i < arChar.length; i++) {
			iValue = gbkStr.charAt(i);
			if (iValue <= 256)
				uStr = new StringBuilder(uStr).append("\\u00").append(
						Integer.toHexString(iValue)).toString();
			else
				uStr = new StringBuilder(uStr).append("\\u").append(
						Integer.toHexString(iValue)).toString();
		}
		return uStr;
	}

	/***************************************************************************
	 * 自定义编码转换格式
	 * 
	 * @param text
	 *            文本内容
	 * @param sformat
	 *            原始文本格式
	 * @param eformat
	 *            转换后的文本格式
	 * @return 返回编码后的文本内容
	 */
	public static String convert(String text, String sformat, String eformat) {
		try {
			return new String(text.getBytes(sformat), eformat);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		}
	}
}
