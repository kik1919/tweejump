package com.jhl.refpp.util;
 

public class StationDesc {
	/***
	 * 业务员岗位（1：推广员；2：初级美容师；3：中级美容师；4：高级美容师；5：代理院长；6：院长；7：技术经理；8：采购经理；9：后勤部经理；10：总经理；）
	 * @param n
	 * @return
	 */
	public static String get(Integer n) {
		if(n==1) {
			return "推广员";
		}if(n==2) {
			return "初级美容师";
		}if(n==3) {
			return "中级美容师";
		}if(n==4) {
			return "高级美容师";
		}if(n==5) {
			return "代理院长";
		}if(n==6) {
			return "院长";
		}if(n==7) {
			return "技术经理";
		}if(n==8) {
			return "采购经理";
		}if(n==9) {
			return "后勤部经理";
		}if(n==10) {
			return "总经理";
		}else {
			return "";
		}
	}
}
