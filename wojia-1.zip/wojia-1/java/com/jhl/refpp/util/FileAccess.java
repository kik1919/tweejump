package com.jhl.refpp.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/*******************************************************************************
 * 文件和文件夹访问，包括创建、删除、移动、复制
 * 
 * @author 蒋海林
 * @version version1.0
 */
public class FileAccess {

	/***************************************************************************
	 * 创建文件.
	 * 
	 * @param path
	 * @throws IOException
	 */
	public static void createFile(String path) throws Exception {
		try {
			File filename = new File(path);
			if (!filename.exists()) {
				filename.createNewFile();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public static String createFile(String dir, String filename) throws Exception {
		try {
			File f = new File(dir);
			if (!f.exists()) {
				f.mkdirs();
			}
			FileAccess.createFile(dir + filename);
			return dir + filename;
		} catch (Exception e) {
			throw e;
		}
	}

	/***************************************************************************
	 * 创建文件夹.
	 * 
	 * @param path
	 * @throws IOException
	 */
	public static boolean createDirectiory(String path) throws Exception {
		try {
			File filename = new File(path);
			if (!filename.exists()) {
				return filename.mkdirs();
			}
			return false;
		} catch (Exception e) {
			throw e;
		}
	}

	/***
	 * 移动文件或者文件夹
	 * 
	 * @param srcFile
	 * @param destPath
	 * @return
	 * @throws Exception
	 */
	public static boolean Move(String srcFile, String destPath) throws Exception {
		try {
			File file = new File(srcFile);
			File dir = new File(destPath);
			boolean success = file.renameTo(new File(dir, file.getName()));
			return success;
		} catch (Exception e) {
			throw e;
		}
	}

	/***************************************************************************
	 * 复制文件
	 * 
	 * @param sourceFile
	 *            文件源路径
	 * @param targetFile
	 *            目标路径
	 * @throws Exception
	 */
	public static void copyFile(File sourceFile, File targetFile) throws Exception {
		FileInputStream input = null;
		BufferedInputStream inBuff = null;

		// 新建文件输出流并对它进行缓冲
		FileOutputStream output = null;
		BufferedOutputStream outBuff = null;

		try {
			// 新建文件输入流并对它进行缓冲
			input = new FileInputStream(sourceFile);
			inBuff = new BufferedInputStream(input);

			// 新建文件输出流并对它进行缓冲
			output = new FileOutputStream(targetFile);
			outBuff = new BufferedOutputStream(output);

			// 缓冲数组
			byte[] b = new byte[1024 * 5];
			int len;
			while ((len = inBuff.read(b)) != -1) {
				outBuff.write(b, 0, len);
			}
			// 刷新此缓冲的输出流
			outBuff.flush();

		} catch (Exception e) {
			throw e;
		} finally {
			// 关闭流
			if (inBuff != null) {
				inBuff.close();
			}
			if (outBuff != null) {
				outBuff.close();
			}
			if (output != null) {
				output.close();
			}
			if (input != null) {
				input.close();
			}
		}
	}

	/***************************************************************************
	 * 复制文件夹
	 * 
	 * @param sourceDir
	 *            文件源路径
	 * @param targetDir
	 *            目标路径
	 * @throws Exception
	 */
	public static void copyDirectiory(String sourceDir, String targetDir) throws Exception {
		try {
			// 新建目标目录
			(new File(targetDir)).mkdirs();
			// 获取源文件夹当前下的文件或目录
			File[] file = (new File(sourceDir)).listFiles();
			for (int i = 0; i < file.length; i++) {
				if (file[i].isFile()) {
					// 源文件
					File sourceFile = file[i];
					// 目标文件
					File targetFile = new File(
							new File(targetDir).getAbsolutePath() + File.separator + file[i].getName());
					copyFile(sourceFile, targetFile);
				}
				if (file[i].isDirectory()) {
					// 准备复制的源文件夹
					String dir1 = sourceDir + "/" + file[i].getName();
					// 准备复制的目标文件夹
					String dir2 = targetDir + "/" + file[i].getName();
					copyDirectiory(dir1, dir2);
				}
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public static void main(String[] args) {
		try {
			File f = new File(
					"D:\\workspace\\jhhy\\webapp\\img\\shop\\SHOP201802221618309423\\product\\PRODUCT201801270940068850\\");
			f.mkdirs();
			FileAccess.createFile(f + "/abcd");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***
	 * 复制文件
	 * 
	 * @param oldPath
	 * @param newPath
	 * @throws Exception
	 */
	public static void CopyFile(String oldPath, String newPath) throws Exception {
		int bytesum = 0;
		int byteread = 0;
		InputStream inStream = null;
		FileOutputStream fs = null;
		try {
			File oldfile = new File(oldPath);
			if (oldfile.exists()) {
				inStream = new FileInputStream(oldPath);
				fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				while ((byteread = inStream.read(buffer)) != -1) {
					bytesum += byteread;
					fs.write(buffer, 0, byteread);
				}

			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (inStream != null) {
				inStream.close();
			}
			if (fs != null) {
				fs.close();
			}
		}
	}

	/**
	 * 删除目录（文件夹）以及目录下的文件
	 * 
	 * @param sPath
	 *            被删除目录的文件路径
	 * @return 目录删除成功返回true，否则返回false
	 * @throws Exception
	 */
	public static boolean deleteDirectory(String sPath) throws Exception {
		try {
			// 如果sPath不以文件分隔符结尾，自动添加文件分隔符
			if (!sPath.endsWith(File.separator)) {
				sPath = sPath + File.separator;
			}
			File dirFile = new File(sPath);
			// 如果dir对应的文件不存在，或者不是一个目录，则退出
			if (!dirFile.exists() || !dirFile.isDirectory()) {
				return false;
			}
			boolean flag = true;
			// 删除文件夹下的所有文件(包括子目录)
			File[] files = dirFile.listFiles();
			for (int i = 0; i < files.length; i++) {
				// 删除子文件
				if (files[i].isFile()) {
					flag = deleteFile(files[i].getAbsolutePath());
					if (!flag)
						break;
				} // 删除子目录
				else {
					flag = deleteDirectory(files[i].getAbsolutePath());
					if (!flag)
						break;
				}
			}
			if (!flag)
				return false;
			// 删除当前目录
			if (dirFile.delete()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 删除单个文件
	 * 
	 * @param sPath
	 *            被删除文件的文件名
	 * @return 单个文件删除成功返回true，否则返回false
	 * @throws Exception
	 */
	public static boolean deleteFile(String sPath) throws Exception {
		try {
			boolean flag = false;
			File file = new File(sPath);
			// 路径为文件且不为空则进行删除
			if (file.isFile() && file.exists()) {
				file.delete();
				flag = true;
			}
			return flag;
		} catch (Exception e) {
			throw e;
		}
	}

}
