package com.jhl.refpp.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/*******************************************************************************
 * 把时间拆分成时间段,常用于统计中
 * 
 * @author 蒋海林
 */
public abstract class SplitDate {

	/***************************************************************************
	 * 从开始时间到结束时间，按月份拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForMonth(Calendar start, Calendar end) throws Exception {
		List<StatDate> list = new ArrayList<StatDate>();
		for (Calendar time = start; time.before(end);) {
			StatDate d = new StatDate();
			int curD = time.get(Calendar.DATE);// 当前天
			int maxData = time.getActualMaximum(Calendar.DATE);// 当月最大天数

			d.setStart(DateParser.StringDate(time) + " 00:00:00");
			d.setStartCalendar((Calendar) time.clone());

			if (curD != 1) {

				time.add(Calendar.DATE, maxData - curD + 1);

				if (time.get(Calendar.MARCH) != end.get(Calendar.MARCH) && time.after(end)) {
					time.add(Calendar.DATE, -(end.getActualMaximum(Calendar.DATE) - end.get(Calendar.DATE)));
				}

			} else {

				time.add(Calendar.MONTH, 1);

				if (time.get(Calendar.MARCH) + time.get(Calendar.YEAR) != end.get(Calendar.MARCH) + end.get(Calendar.YEAR) && time.after(end)) {
					time.add(Calendar.DATE, -(end.getActualMaximum(Calendar.DATE) - end.get(Calendar.DATE)));
				}

			}
			Calendar temp = (Calendar) time.clone();
			temp.add(Calendar.DATE, -1);
			d.setEnd(DateParser.StringDate(temp) + " 23:59:59");
			d.setEndCalendar((Calendar) time.clone());
			list.add(d);

		}
		return list;
	}

	/***************************************************************************
	 * 从开始时间到结束时间，按月份拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForMonth(String start, String end) throws Exception {

		return SplitDate.splitForMonth(DateParser.getDate(start), DateParser.getDate(end));
	}

	/***************************************************************************
	 * 从开始时间到结束时间，按周拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForWeek(Calendar start, Calendar end) throws Exception {
		List<StatDate> list = new ArrayList<StatDate>();
		Calendar temp = start;
		int i = 0;
		while (temp.before(end)) {
			StatDate d = new StatDate();
			d.setStart(DateParser.StringTime(temp));
			d.setStartCalendar((Calendar) temp.clone());
			temp.add(Calendar.DATE, 1);
			int first = temp.get(Calendar.DAY_OF_WEEK) - 1;// 获取开始日期是当前星期的第几天（下标从周日到周六分别是1、2、3、4、5、6、7）
			if (i == 0) {
				temp.add(Calendar.DATE, 7 - first);// 算出本周最后一天
				i++;
			} else {
				Calendar t = (Calendar) temp.clone();
				t.add(Calendar.DATE, 6);// 算出本周最后一天
				if (t.after(end)) {
					long diff = end.getTimeInMillis() - temp.getTimeInMillis();
					long days = diff / (1000 * 60 * 60 * 24);
					temp.add(Calendar.DATE, Integer.parseInt(String.valueOf(days)));// 算出本周最后一天
				} else {
					temp.add(Calendar.DATE, 6);// 算出本周最后一天
				}
			}

			if (temp.after(end)) {
				temp = end;
			}
			d.setEnd(DateParser.StringTime(temp));
			d.setEndCalendar((Calendar) temp.clone());

			list.add(d);

		}
		return list;
	}

	/***************************************************************************
	 * 从开始时间到结束时间，按周拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForWeek(String start, String end) throws Exception {

		return SplitDate.splitForWeek(DateParser.getDate(start), DateParser.getDate(end));

	}

	/***************************************************************************
	 * 从开始时间到结束时间，按日拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForDay(Calendar start, Calendar end) throws Exception {
		List<StatDate> list = new ArrayList<StatDate>();
		Calendar temp = start;
		while (temp.before(end)) {
			StatDate d = new StatDate();
			d.setStart(DateParser.StringTime(temp));
			d.setStartCalendar((Calendar) temp.clone());
			temp.add(Calendar.DATE, 1);
			if (temp.after(end)) {
				temp = end;
			}

			d.setEnd(DateParser.StringTime(temp));
			d.setEndCalendar((Calendar) temp.clone());

			list.add(d);

		}
		return list;
	}

	/***************************************************************************
	 * 从开始时间到结束时间，按日拆分成时间段
	 * 
	 * @param start
	 * @param end
	 */
	public static List<StatDate> splitForDay(String start, String end) throws Exception {
		Calendar temp = DateParser.getTime(start);
		Calendar endC = DateParser.getTime(end);
		return SplitDate.splitForDay(temp, endC);
	}

	public static void main(String[] args) {
		try {
			List<StatDate> list = SplitDate.splitForDay("2015-1-1 17:30:00", "2015-2-2 16:30:00");
			for (StatDate StatDate : list) {
				System.out.println(StatDate.getStart() + "=====" + StatDate.getEnd());
			}

			System.out.println("******************");
			list = SplitDate.splitForWeek("2015-1-1 17:30:00", "2015-2-2 16:30:00");
			for (StatDate StatDate : list) {
				System.out.println(StatDate.getStart() + "=====" + StatDate.getEnd());
			}

			System.out.println("******************");
			list = SplitDate.splitForMonth("2015-1-1", "2015-2-2");
			for (StatDate StatDate : list) {
				System.out.println(StatDate.getStart() + "=====" + StatDate.getEnd());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
