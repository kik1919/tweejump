package com.jhl.refpp.util;
 
import com.jfinal.weixin.sdk.api.ApiResult;
import com.jfinal.weixin.sdk.utils.HttpUtils;
import com.jhl.refpp.core.Para;

public class TemplateMiniApi {
	private static String sendApiUrl = "https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=";

	/**
	 * 发送小程序模板消息
	 * 
	 * @param jsonStr
	 *            json字符串
	 * @return {ApiResult}
	 * @throws Exception
	 */
	public static ApiResult send(String jsonStr, Para shop) throws Exception {
		String accessToken = WeixinUtil.postToken(shop.getString("appidWx"), shop.getString("appSecretWx"));
		String jsonResult = HttpUtils.post(sendApiUrl + accessToken, jsonStr);
		return new ApiResult(jsonResult);
	}
}
