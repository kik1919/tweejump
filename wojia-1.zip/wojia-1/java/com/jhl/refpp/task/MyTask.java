package com.jhl.refpp.task;

import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jhl.refpp.po.SerialNoExample;
import com.jhl.refpp.service.MesService;
import com.jhl.refpp.support.MapperFactory;

@Component
public class MyTask {

	@Resource(name = "mesService")
	private MesService mesService;

	public void testJob() { 
	}

	/***
	 * 每天2点定时任务
	 */
	public void buildsend2hMesTask() {
		try {
			this.delSerialNoYear();
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}

	/***
	 * 每天8点8分定时任务
	 */
	public void buildsend8h8mMesTask() {
		try { 
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}

	/***
	 * 星期三8点8分定时任务
	 */
	public void buildsendWed8h8mMesTask() {
		try { 
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}

	/***
	 * 删除一年之前的流水
	 */
	public void delSerialNoYear() {
		try {
			Calendar cur = Calendar.getInstance();
			Calendar tem = (Calendar) cur.clone();
			tem.add(Calendar.YEAR, -1);
			System.out.println("==========开始跑批处理=============");

			SerialNoExample serialNoExample = new SerialNoExample();
			serialNoExample.createCriteria().andCreatedAtLessThan(tem.getTime());
			MapperFactory.serialNoMapper.deleteByExample(serialNoExample);

		} catch (Exception e) { 
			e.printStackTrace();
		}
	}

}
