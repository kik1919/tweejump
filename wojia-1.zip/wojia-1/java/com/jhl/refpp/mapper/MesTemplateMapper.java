package com.jhl.refpp.mapper;

import com.jhl.refpp.po.MesTemplate;
import com.jhl.refpp.po.MesTemplateExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MesTemplateMapper {
    int countByExample(MesTemplateExample example);

    int deleteByExample(MesTemplateExample example);

    int deleteByPrimaryKey(String id);

    int insert(MesTemplate record);

    int insertSelective(MesTemplate record);

    List<MesTemplate> selectByExample(MesTemplateExample example);

    MesTemplate selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") MesTemplate record, @Param("example") MesTemplateExample example);

    int updateByExample(@Param("record") MesTemplate record, @Param("example") MesTemplateExample example);

    int updateByPrimaryKeySelective(MesTemplate record);

    int updateByPrimaryKey(MesTemplate record);
}