package com.jhl.refpp.mapper;

import com.jhl.refpp.po.WxSession;
import com.jhl.refpp.po.WxSessionExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface WxSessionMapper {
    int countByExample(WxSessionExample example);

    int deleteByExample(WxSessionExample example);

    int deleteByPrimaryKey(String id);

    int insert(WxSession record);

    int insertSelective(WxSession record);

    List<WxSession> selectByExample(WxSessionExample example);

    WxSession selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") WxSession record, @Param("example") WxSessionExample example);

    int updateByExample(@Param("record") WxSession record, @Param("example") WxSessionExample example);

    int updateByPrimaryKeySelective(WxSession record);

    int updateByPrimaryKey(WxSession record);
}