package com.jhl.refpp.mapper;

import com.jhl.refpp.po.SerialNo;
import com.jhl.refpp.po.SerialNoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SerialNoMapper {
    int countByExample(SerialNoExample example);

    int deleteByExample(SerialNoExample example);

    int deleteByPrimaryKey(String id);

    int insert(SerialNo record);

    int insertSelective(SerialNo record);

    List<SerialNo> selectByExample(SerialNoExample example);

    SerialNo selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") SerialNo record, @Param("example") SerialNoExample example);

    int updateByExample(@Param("record") SerialNo record, @Param("example") SerialNoExample example);

    int updateByPrimaryKeySelective(SerialNo record);

    int updateByPrimaryKey(SerialNo record);
}