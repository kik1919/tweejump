package com.jhl.refpp.mapper;

import com.jhl.refpp.po.Squence;
import com.jhl.refpp.po.SquenceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SquenceMapper {
    int countByExample(SquenceExample example);

    int deleteByExample(SquenceExample example);

    int deleteByPrimaryKey(String id);

    int insert(Squence record);

    int insertSelective(Squence record);

    List<Squence> selectByExample(SquenceExample example);

    Squence selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Squence record, @Param("example") SquenceExample example);

    int updateByExample(@Param("record") Squence record, @Param("example") SquenceExample example);

    int updateByPrimaryKeySelective(Squence record);

    int updateByPrimaryKey(Squence record);
}