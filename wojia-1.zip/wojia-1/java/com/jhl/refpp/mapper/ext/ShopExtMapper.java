package com.jhl.refpp.mapper.ext;
    
import java.util.List;

import com.jhl.refpp.core.Para;
 
public interface ShopExtMapper {
	List<Para> getList(Para map);
	int getList_count(Para map);
}