package com.jhl.refpp.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jfinal.weixin.sdk.api.ApiConfig;
import com.jfinal.weixin.sdk.api.SnsAccessTokenApi;
import com.jfinal.weixin.sdk.jfinal.ApiController;
import com.jhl.refpp.core.Context;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.util.WeixinUtil;

@Controller
@RequestMapping("/oauth2")
public class RedirectUriController extends ApiController {
	/**
	 * 如果要支持多公众账号，只需要在此返回各个公众号对应的 ApiConfig 对象即可 可以通过在请求 url 中挂参数来动态从数据库中获取
	 * ApiConfig 属性值
	 */
	public ApiConfig getApiConfig() {
		return null;
	}

	@Resource(name = "shopService")
	private ShopService shopService;

	@RequestMapping(value = "/oauth")
	@ResponseBody
	public Message oauth(HttpServletRequest req, HttpServletResponse res) {
		try {
			String host = req.getServerName();
			String shopid = req.getParameter("shopid");
			String scope = req.getParameter("scope");
			String toUrl = req.getParameter("toUrl");
			if (toUrl == null || toUrl.trim().equals("")) {
				toUrl = "";
			}
			String toUrlParam = req.getQueryString();
			if (toUrlParam == null || toUrlParam.trim().equals("")) {
				toUrlParam = "";
			}
			System.out.println("START========请求授权oauth2/oauth======START");
			System.out.println("========scope======" + scope);
			System.out.println("========serverName======" + host);
			System.out.println("========shopid======" + shopid);
			System.out.println("========toUrl======" + toUrl);
			System.out.println("========toUrlParam======" + toUrlParam);
			Para shop = shopService.loadWXConfById(shopid);
			if (shop == null) {
				return new Message(0, "公众号尚未配置");
			}
			String appId = shop.getString("appid");
			String redirectUri = WeixinUtil.urlEncodeUTF8(Context.url(host) + toUrl + "?" + toUrlParam);
			System.out.println("=====redirectUri====" + redirectUri);
			boolean snsapiBase = true;
			if (scope != null) {
				snsapiBase = Boolean.getBoolean(scope);
			}
			String url = SnsAccessTokenApi.getAuthorizeURL(appId, redirectUri, shopid, snsapiBase);
			System.out.println("====url=====" + url);
			res.sendRedirect(url);
			System.out.println("END========请求授权oauth2/oauth======END");
			return new Message(1, url);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

}
