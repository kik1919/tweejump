package com.jhl.refpp.controller;

import java.security.spec.AlgorithmParameterSpec;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.DataList;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.core.config.tag.Pager;
import com.jhl.refpp.service.MesService;
import com.jhl.refpp.service.UserService;
import com.sun.org.apache.xml.internal.security.utils.Base64;

@Controller
@RequestMapping("/user")
public class UserController extends BaseController {

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "mesService")
	private MesService mesService;

	@RequestMapping(value = "/getList.boss", method = RequestMethod.POST)
	@ResponseBody
	public DataList getList(@RequestParam HashMap<Object, Object> map, Pager pager) {
		try {
			Para para = new Para(map);
			return userService.getList(para, pager);
		} catch (Exception e) {
			e.printStackTrace();
			return new DataList();
		}
	}

	@RequestMapping(value = "/get", method = RequestMethod.POST)
	@ResponseBody
	public Message get(@RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			Para rs = userService.get(para);
			if (rs != null) {
				return new Message(1, "获取数据成功", rs);
			} else {
				return new Message(0, "获取数据失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/findUser", method = RequestMethod.POST)
	@ResponseBody
	public Message findUser(@RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			String unionid = para.getString("unionid");
			String openid = para.getString("openid");
			Para rs = userService.findUser(unionid, openid);
			if (rs != null) {
				return new Message(1, "获取数据成功", rs);
			} else {
				return new Message(0, "获取数据失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/updateByIdForAdmin.boss", method = RequestMethod.POST)
	@ResponseBody
	public Message updateByIdForAdmin(@RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			return userService.updateByIdForAdmin(para);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/updateByIdForAdminMobileNorepeat.boss", method = RequestMethod.POST)
	@ResponseBody
	public Message updateByIdForAdminMobileNorepeat(@RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			return userService.updateByIdForAdminMobileNorepeat(para);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/updateById.vip1", method = RequestMethod.POST)
	@ResponseBody
	public Message updateById(@RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			return userService.updateById(para);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/updateByIdForBase", method = RequestMethod.POST)
	@ResponseBody
	public Message updateByIdForBase(@RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			return userService.updateByIdForBase(para);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	@ResponseBody
	public Message logout(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {
		try {
			request.getSession().removeAttribute("loginUser");
			return new Message(1, "已登出");
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public Message login(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			Message mes = userService.login(para);
			if (mes.getState() == Message.SUCCESS) {
				request.getSession().setAttribute("loginUser", mes.getData().get("loginUser"));
			}
			return mes;
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	@ResponseBody
	public Message register(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			para.put("req", request);
			Message mes = userService.register(para);
			if (mes.getState() == Message.SUCCESS) {
				request.getSession().setAttribute("loginUser", mes.getData().get("loginUser"));
			}
			return mes;
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	/***
	 * 发送验证码
	 * 
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/verificationCode", method = RequestMethod.POST)
	@ResponseBody
	public Para verificationCode(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {
		Para data = new Para();
		try {
			Para para = new Para(map);
			Message mes = mesService.sendVerificationCodeSMS(para);
			return mes.getData();
		} catch (Exception e) {
			e.printStackTrace();
			return data;
		}
	}

	/***
	 * 解密并且获取用户手机号码（小程序）
	 * 
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/deciphering", method = RequestMethod.POST)
	@ResponseBody
	public Message deciphering(@RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			String encrypData = para.getString("encrypData");
			String ivData = para.getString("ivData");
			String sessionKey = para.getString("sessionKey");

			AlgorithmParameterSpec ivSpec = new IvParameterSpec(Base64.decode(ivData));
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			SecretKeySpec keySpec = new SecretKeySpec(Base64.decode(sessionKey), "AES");
			cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
			// 解析解密后的字符串  
			String mobile = new String(cipher.doFinal(Base64.decode(encrypData)), "UTF-8");

			return new Message(1, "解密手机号码成功", new Para("mobile", mobile));
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/updatePwd.boss", method = RequestMethod.POST)
	@ResponseBody
	public Message updatePwd(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {

		try {
			Para para = new Para(map);
			Message mes = userService.updatePwd(para);
			return mes;
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}
}
