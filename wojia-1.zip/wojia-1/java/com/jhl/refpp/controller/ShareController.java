package com.jhl.refpp.controller;

import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jfinal.kit.HashKit;
import com.jfinal.weixin.sdk.api.ApiConfig;
import com.jfinal.weixin.sdk.api.ApiConfigKit;
import com.jfinal.weixin.sdk.api.JsTicket;
import com.jfinal.weixin.sdk.api.JsTicketApi;
import com.jfinal.weixin.sdk.api.JsTicketApi.JsApiType;
import com.jfinal.weixin.sdk.jfinal.ApiController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.service.ShopService;

@Controller
@RequestMapping("/jssdk")
public class ShareController extends ApiController {
	@Resource(name = "shopService")
	private ShopService shopService;

	/**
	 * 如果要支持多公众账号，只需要在此返回各个公众号对应的 ApiConfig 对象即可 可以通过在请求 url 中挂参数来动态从数据库中获取
	 * ApiConfig 属性值
	 */
	public ApiConfig getApiConfig() {
		return null;
	}

	private static String create_timestamp() {
		return Long.toString(System.currentTimeMillis() / 1000);
	}

	private static String create_nonce_str() {
		return UUID.randomUUID().toString();
	}

	@RequestMapping(value = "/index", method = RequestMethod.POST)
	@ResponseBody
	public Message index(String userid, String shopid, String cusUrl, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out.println("START========注册分享事件======START");
		System.out.println("客户端地址：=============" + cusUrl);
		Para data = new Para();
		this.setHttpServletRequest(request);
		this.setHttpServletResponse(response);
		shopService.loadWXConfById(shopid);
		JsTicket jsApiTicket = JsTicketApi.getTicket(JsApiType.jsapi);
		String jsapi_ticket = jsApiTicket.getTicket();
		String nonce_str = create_nonce_str();
		// 注意 URL 一定要动态获取，不能 hardcode.
		String url = "https://" + getRequest().getServerName() // 服务器地址
		// + ":"
		// + getRequest().getServerPort() //端口号
				+ getRequest().getContextPath() // 项目名称
				+ getRequest().getServletPath();// 请求页面或其他地址

		String qs = getRequest().getQueryString(); // 参数
		if (qs != null) {
			url = url + "?" + (getRequest().getQueryString());
		}
		url = cusUrl;
		String timestamp = create_timestamp();
		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		// 注意这里参数名必须全部小写，且必须有序
		String str = "jsapi_ticket=" + jsapi_ticket + "&noncestr=" + nonce_str + "&timestamp=" + timestamp + "&url="
				+ url;
		System.out.println("========================" + str);
		String signature = HashKit.sha1(str);

		System.out.println("appId " + ApiConfigKit.getApiConfig().getAppId() + "  nonceStr " + nonce_str + " timestamp "
				+ timestamp);
		System.out.println("url " + url + " signature " + signature);
		System.out.println("nonceStr " + nonce_str + " timestamp " + timestamp);
		System.out.println(" jsapi_ticket " + jsapi_ticket);
		System.out.println("nonce_str  " + nonce_str);
		data.put("appId", ApiConfigKit.getApiConfig().getAppId());
		data.put("nonceStr", nonce_str);
		data.put("timestamp", timestamp);
		data.put("url", url);
		data.put("signature", signature);
		data.put("jsapi_ticket", jsapi_ticket);
		System.out.println("END========注册分享事件======END");
		return new Message(1, "", data);

	}

}
