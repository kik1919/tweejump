package com.jhl.refpp.controller;

import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.util.DBC;

@Controller
@RequestMapping("/auth")
public class AuthController extends BaseController {

	@RequestMapping(value = "/notAuth")
	@ResponseBody
	public Message notAuth(HttpServletRequest req) {
		try {
			Message mes = new Message(0, "对不起，没有" + req.getAttribute("notAuthDesc") + "权限！");
			mes.setAuth(DBC.YES);
			mes.setState(2);
			mes.setRows(new ArrayList<Para>());
			return mes;
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

}
