package com.jhl.refpp.controller;

import java.util.HashMap;
import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.service.ShopService;

@Controller
@RequestMapping("/shop")
public class ShopController extends BaseController {

	@Resource(name = "shopService")
	private ShopService shopService;

	@RequestMapping(value = "/get", method = RequestMethod.POST)
	@ResponseBody
	public Message get(@RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			Para shop = shopService.loadWXConf(para);
			shop.remove("appSecret");
			shop.remove("paternerKey");
			shop.remove("token");
			return new Message(1, "加载门店信息成功", shop);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

}
