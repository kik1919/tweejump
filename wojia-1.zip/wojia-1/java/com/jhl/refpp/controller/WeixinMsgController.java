
package com.jhl.refpp.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.kit.LogKit;
import com.jfinal.log.Log;
import com.jfinal.weixin.sdk.api.ApiConfig;
import com.jfinal.weixin.sdk.api.ApiResult;
import com.jfinal.weixin.sdk.api.UserApi;
import com.jfinal.weixin.sdk.jfinal.MsgControllerAdapter;
import com.jfinal.weixin.sdk.msg.InMsgParser;
import com.jfinal.weixin.sdk.msg.in.InImageMsg;
import com.jfinal.weixin.sdk.msg.in.InLinkMsg;
import com.jfinal.weixin.sdk.msg.in.InLocationMsg;
import com.jfinal.weixin.sdk.msg.in.InMsg;
import com.jfinal.weixin.sdk.msg.in.InNotDefinedMsg;
import com.jfinal.weixin.sdk.msg.in.InShortVideoMsg;
import com.jfinal.weixin.sdk.msg.in.InTextMsg;
import com.jfinal.weixin.sdk.msg.in.InVideoMsg;
import com.jfinal.weixin.sdk.msg.in.InVoiceMsg;
import com.jfinal.weixin.sdk.msg.in.event.InCustomEvent;
import com.jfinal.weixin.sdk.msg.in.event.InFollowEvent;
import com.jfinal.weixin.sdk.msg.in.event.InLocationEvent;
import com.jfinal.weixin.sdk.msg.in.event.InMassEvent;
import com.jfinal.weixin.sdk.msg.in.event.InMenuEvent;
import com.jfinal.weixin.sdk.msg.in.event.InMerChantOrderEvent;
import com.jfinal.weixin.sdk.msg.in.event.InNotDefinedEvent;
import com.jfinal.weixin.sdk.msg.in.event.InPoiCheckNotifyEvent;
import com.jfinal.weixin.sdk.msg.in.event.InQrCodeEvent;
import com.jfinal.weixin.sdk.msg.in.event.InShakearoundUserShakeEvent;
import com.jfinal.weixin.sdk.msg.in.event.InSubmitMemberCardEvent;
import com.jfinal.weixin.sdk.msg.in.event.InTemplateMsgEvent;
import com.jfinal.weixin.sdk.msg.in.event.InUpdateMemberCardEvent;
import com.jfinal.weixin.sdk.msg.in.event.InUserPayFromCardEvent;
import com.jfinal.weixin.sdk.msg.in.event.InUserViewCardEvent;
import com.jfinal.weixin.sdk.msg.in.event.InVerifyFailEvent;
import com.jfinal.weixin.sdk.msg.in.event.InVerifySuccessEvent;
import com.jfinal.weixin.sdk.msg.in.event.InWifiEvent;
import com.jfinal.weixin.sdk.msg.in.speech_recognition.InSpeechRecognitionResults;
import com.jfinal.weixin.sdk.msg.out.OutCustomMsg;
import com.jfinal.weixin.sdk.msg.out.OutNewsMsg;
import com.jhl.refpp.core.Context;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.service.UserService;
import com.jhl.refpp.service.WeChatService;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.StringUtils;

@Controller
@RequestMapping("/msg")
public class WeixinMsgController extends MsgControllerAdapter {
	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "shopService")
	private ShopService shopService;

	@Resource(name = "weChatService")
	private WeChatService weChatService;

	private static final Log logger = Log.getLog(WeixinMsgController.class);

	/**
	 * 如果要支持多公众账号，只需要在此返回各个公众号对应的 ApiConfig 对象即可 可以通过在请求 url 中挂参数来动态从数据库中获取
	 * ApiConfig 属性值
	 */
	public ApiConfig getApiConfig() {
		return null;
	}

	@RequestMapping(value = "/x", method = RequestMethod.GET)
	@ResponseBody
	public Message portal(HttpServletRequest request, HttpServletResponse response) {

		try {
			String signature = request.getParameter("signature");
			String timestamp = request.getParameter("timestamp");
			String nonce = request.getParameter("nonce");
			String echostr = request.getParameter("echostr");
			System.out.println("signature:" + signature);
			System.out.println("timestamp:" + timestamp);
			System.out.println("nonce:" + nonce);
			System.out.println("echostr:" + echostr);
			PrintWriter pw = response.getWriter();
			pw.append(echostr);
			pw.flush();

			return new Message(1, "成功");
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/")
	@ResponseBody
	public void index(HttpServletRequest request, HttpServletResponse response) {
		this.setHttpServletRequest(request);
		this.setHttpServletResponse(response);
		String signature = request.getParameter("signature");
		String timestamp = request.getParameter("timestamp");
		String nonce = request.getParameter("nonce");
		String echostr = request.getParameter("echostr");
		if (signature != null && timestamp != null && nonce != null && echostr != null) {
			// 消息验证
			try {

				System.out.println("signature:" + signature);
				System.out.println("timestamp:" + timestamp);
				System.out.println("nonce:" + nonce);
				System.out.println("echostr:" + echostr);
				PrintWriter pw = response.getWriter();
				pw.append(echostr);
				pw.flush();

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {

			BufferedReader br = null;
			StringBuilder result = new StringBuilder();
			try {

				br = request.getReader();
				for (String line = null; (line = br.readLine()) != null;) {
					result.append(line).append("\n");
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			} finally {
				if (br != null)
					try {
						br.close();
					} catch (IOException e) {
						LogKit.error(e.getMessage(), e);
					}
			}
			System.out.println("==================" + result.toString());

			// 解析消息并根据消息类型分发到相应的处理方法
			InMsg msg = InMsgParser.parse(result.toString());
			if (msg instanceof InTextMsg)
				processInTextMsg((InTextMsg) msg);
			else if (msg instanceof InImageMsg)
				processInImageMsg((InImageMsg) msg);
			else if (msg instanceof InSpeechRecognitionResults)
				processInSpeechRecognitionResults((InSpeechRecognitionResults) msg);
			else if (msg instanceof InVoiceMsg)
				processInVoiceMsg((InVoiceMsg) msg);
			else if (msg instanceof InVideoMsg)
				processInVideoMsg((InVideoMsg) msg);
			else if (msg instanceof InShortVideoMsg) // 支持小视频
				processInShortVideoMsg((InShortVideoMsg) msg);
			else if (msg instanceof InLocationMsg)
				processInLocationMsg((InLocationMsg) msg);
			else if (msg instanceof InLinkMsg)
				processInLinkMsg((InLinkMsg) msg);
			else if (msg instanceof InCustomEvent)
				processInCustomEvent((InCustomEvent) msg);
			else if (msg instanceof InFollowEvent)
				processInFollowEvent((InFollowEvent) msg);
			else if (msg instanceof InQrCodeEvent)
				processInQrCodeEvent((InQrCodeEvent) msg);
			else if (msg instanceof InLocationEvent)
				processInLocationEvent((InLocationEvent) msg);
			else if (msg instanceof InMassEvent)
				processInMassEvent((InMassEvent) msg);
			else if (msg instanceof InMenuEvent)
				processInMenuEvent((InMenuEvent) msg);
			else if (msg instanceof InTemplateMsgEvent)
				processInTemplateMsgEvent((InTemplateMsgEvent) msg);
			else if (msg instanceof InShakearoundUserShakeEvent)
				processInShakearoundUserShakeEvent((InShakearoundUserShakeEvent) msg);
			else if (msg instanceof InVerifySuccessEvent)
				processInVerifySuccessEvent((InVerifySuccessEvent) msg);
			else if (msg instanceof InVerifyFailEvent)
				processInVerifyFailEvent((InVerifyFailEvent) msg);
			else if (msg instanceof InPoiCheckNotifyEvent)
				processInPoiCheckNotifyEvent((InPoiCheckNotifyEvent) msg);
			else if (msg instanceof InWifiEvent)
				processInWifiEvent((InWifiEvent) msg);
			else if (msg instanceof InUserViewCardEvent)
				processInUserViewCardEvent((InUserViewCardEvent) msg);
			else if (msg instanceof InSubmitMemberCardEvent)
				processInSubmitMemberCardEvent((InSubmitMemberCardEvent) msg);
			else if (msg instanceof InUpdateMemberCardEvent)
				processInUpdateMemberCardEvent((InUpdateMemberCardEvent) msg);
			else if (msg instanceof InUserPayFromCardEvent)
				processInUserPayFromCardEvent((InUserPayFromCardEvent) msg);
			else if (msg instanceof InMerChantOrderEvent)
				processInMerChantOrderEvent((InMerChantOrderEvent) msg);
			else if (msg instanceof InNotDefinedEvent) {
				logger.error("未能识别的事件类型。 消息 xml 内容为：\n" + getInMsgXml());
				processIsNotDefinedEvent((InNotDefinedEvent) msg);
			} else if (msg instanceof InNotDefinedMsg) {
				logger.error("未能识别的消息类型。 消息 xml 内容为：\n" + getInMsgXml());
				processIsNotDefinedMsg((InNotDefinedMsg) msg);
			}
		}
	}

	@Override
	protected void processInCustomEvent(InCustomEvent inCustomEvent) {
		System.out.println("===================多客户系统==================");

	}

	/***
	 * 触发客户文本消息
	 */
	public void processInTextMsg(InTextMsg inTextMsg) {
		try {
			String id = inTextMsg.getToUserName();// 公众号唯一原始ID。
			String openid = inTextMsg.getFromUserName();
			String content = inTextMsg.getContent();
			if (content.indexOf("人工服务") != -1) {
				System.out.println("==========连接人工服务=============");
				OutCustomMsg outMsg = new OutCustomMsg();
				outMsg.setToUserName(openid);
				outMsg.setFromUserName(id);
				outMsg.setCreateTime(inTextMsg.getCreateTime());
				outMsg.setMsgType("transfer_customer_service");
				String outMsgXml = outMsg.toXml();
				System.out.println("==========outMsgXml=============" + outMsgXml);
				this.getResponse().getWriter().write(outMsgXml);
			} else if (content.indexOf("操作") != -1) {
				System.out.println("==========发送操作手册=============");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 实现父类抽方法，处理关注/取消关注消息
	 */

	public void processInFollowEvent(InFollowEvent inFollowEvent) {
		try {
			OutNewsMsg outMsg = new OutNewsMsg(inFollowEvent);
			String event = inFollowEvent.getEvent();
			String host = this.getRequest().getServerName();
			String id = inFollowEvent.getToUserName();// 公众号唯一原始ID。

			Para shop = shopService.loadWXConfByWX(id);// 加载门店公众号配置
			String shopid = shop.getString("id");
			String poster = shop.getString("poster");
			String shopName = shop.getString("name");
			String shopPoster = "img/shopPoster.jpg";
			if (!StringUtils.isNullOrEmpty(poster)) {
				shopPoster = poster.split(",")[0];
			}

			String openid = inFollowEvent.getFromUserName();
			ApiResult result = UserApi.getUserInfo(openid);
			System.out.println("========result==========" + result);
			if (result.isSucceed()) {
				// 获取微信用户数据成功
				String jsonStr = result.getJson();
				JSONObject wxUser = JSON.parseObject(jsonStr);
				String unionid = wxUser.getString("unionid");

				if (event.equals(InFollowEvent.EVENT_INFOLLOW_SUBSCRIBE)) {
					// 关注  
					wxUser.put("shopid", shopid);
					wxUser.put("refereeid", null);
					wxUser.put("platform", DBC.PLATFORM_H5); 
					wxUser.put("isAttention", DBC.YES);

					weChatService.register(wxUser);

					outMsg.addNews(shopName + "欢迎您", "", Context.url(host) + shopPoster + "?v=1",
							Context.url(host) + "oauth2/oauth/?shopid=" + shopid + "&scope=false");
					String outMsgXml = outMsg.toXml();
					this.getResponse().getWriter().write(outMsgXml);
				} else if (event.equals(InFollowEvent.EVENT_INFOLLOW_UNSUBSCRIBE)) {
					// 取消关注
					Para user = userService.findWholeUser(unionid, openid);
					if (user != null) {
						// 取消关联门店
						userService.cancelAttention(unionid, openid);
					}
					System.out.println(openid + "已取消关注！！！！！");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void processInQrCodeEvent(InQrCodeEvent inQrCodeEvent) {
		try {
			OutNewsMsg outMsg = new OutNewsMsg(inQrCodeEvent);
			String host = this.getRequest().getServerName();
			String id = inQrCodeEvent.getToUserName();// 公众号唯一原始ID。

			Para shop = shopService.loadWXConfByWX(id);// 加载门店公众号配置
			String shopid = shop.getString("id");
			String poster = shop.getString("poster");
			String shopName = shop.getString("name");
			String shopPoster = "img/shopPoster.jpg";
			if (!StringUtils.isNullOrEmpty(poster)) {
				shopPoster = poster.split(",")[0];
			}

			/////////////////// 获取用户微信数据Start///////////////////
			String openid = inQrCodeEvent.getFromUserName();
			ApiResult result = UserApi.getUserInfo(openid);
			System.out.println("========result==========" + result);

			if (result.isSucceed()) {// 获取微信用户数据成功
				String jsonStr = result.getJson();
				JSONObject wxUser = JSON.parseObject(jsonStr);

				String key = inQrCodeEvent.getEventKey();// 场景id,就是推荐用户openid
				String refereeOpenid = key.replace("qrscene_", "");// 推荐人ID
				Para param = new Para();
				param.put("openid", refereeOpenid);
				Para referee = userService.get(param);// 获取用户信息
				String refereeid = null;
				if (referee != null) {
					refereeid = referee.getString("id");
				}

				// 关注 
				wxUser.put("shopid", shopid);
				wxUser.put("platform", DBC.PLATFORM_H5); 
				wxUser.put("refereeid", refereeid);
				wxUser.put("isAttention", DBC.YES); 

				weChatService.register(wxUser);

				outMsg.addNews(shopName + "欢迎您", "", Context.url(host) + shopPoster + "?v=1",
						Context.url(host) + "oauth2/oauth/?shopid=" + shopid + "&scope=false");
				String outMsgXml = outMsg.toXml();
				this.getResponse().getWriter().write(outMsgXml);

			}
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/**
	 * 实现父类抽方法，处理自定义菜单事件
	 */

	public void processInMenuEvent(InMenuEvent inMenuEvent) {
		logger.debug("菜单事件：" + inMenuEvent.getFromUserName());
		try {
			String id = inMenuEvent.getToUserName();// 公众号唯一原始ID。
			String openid = inMenuEvent.getFromUserName();

			String eventKey = inMenuEvent.getEventKey();
			if ("rselfmenu_1_3".equals(eventKey)) {
				System.out.println("==========连接人工服务=============");
				OutCustomMsg outMsg = new OutCustomMsg();
				outMsg.setToUserName(openid);
				outMsg.setFromUserName(id);
				outMsg.setCreateTime(inMenuEvent.getCreateTime());
				outMsg.setMsgType("transfer_customer_service");
				String outMsgXml = outMsg.toXml();
				System.out.println("==========outMsgXml=============" + outMsgXml);
				this.getResponse().getWriter().write(outMsgXml);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
