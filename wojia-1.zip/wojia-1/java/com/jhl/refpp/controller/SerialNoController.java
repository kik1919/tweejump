package com.jhl.refpp.controller;

import java.util.HashMap;
import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.DataList;
import com.jhl.refpp.core.config.tag.Pager;
import com.jhl.refpp.service.SerialNoService;

@Controller
@RequestMapping("/serialNo")
public class SerialNoController extends BaseController {

	@Resource(name = "serialNoService")
	private SerialNoService serialNoService;

	@RequestMapping(value = "/getList.boss", method = RequestMethod.POST)
	@ResponseBody
	public DataList getList(@RequestParam HashMap<Object, Object> map, Pager pager) {
		try {
			Para para = new Para(map);
			return serialNoService.getList(para, pager);
		} catch (Exception e) {
			e.printStackTrace();
			return new DataList();
		}
	}

}
