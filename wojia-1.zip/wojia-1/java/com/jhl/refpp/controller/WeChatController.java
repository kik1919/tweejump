package com.jhl.refpp.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.kit.HttpKit;
import com.jfinal.weixin.sdk.kit.IpKit;
import com.jfinal.weixin.sdk.kit.PaymentKit;
import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Context;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.exception.ServiceLogicException;
import com.jhl.refpp.po.WxExample;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.service.UserService;
import com.jhl.refpp.service.WeChatService;
import com.jhl.refpp.service.WxSessionService;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.StringUtils;

@Controller
@RequestMapping("/weChat")
public class WeChatController extends BaseController {

	@Resource(name = "shopService")
	private ShopService shopService;

	@Resource(name = "weChatService")
	private WeChatService weChatService;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "wxSessionService")
	private WxSessionService wxSessionService;

	@RequestMapping(value = "/getSessionKeyWX", method = RequestMethod.POST)
	@ResponseBody
	public Message getSessionKeyWX(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {
		try {
			// 小程序专用
			Para para = new Para(map);
			String code = para.getString("code");
			String appid = para.getString("appid");
			JSONObject wxUser = weChatService.getWeChatInfoWX(code, appid,null,null);
			System.out.println("==========获取小程序用户信息=========" + wxUser);
			String sessionKey = wxUser.getString("sessionKey");
			if (StringUtils.isNullOrEmpty(sessionKey)) {
				return new Message(0, "无法获取有效的sessionKey");
			}
			return new Message(1, "成功", new Para("sessionKey", sessionKey));
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/getWeChatInfoWX", method = RequestMethod.POST)
	@ResponseBody
	public Message getWeChatInfoWX(HttpServletRequest request, String code, String appid, String encryptedData,
			String iv) {

		try {
			// 先判断当前运行的小程序是否为合法的小程序（是否配置此小程序作为业务系统一部分？）
			WxExample wxExample = new WxExample();
			wxExample.createCriteria().andAppidEqualTo(appid);
			int count = MapperFactory.wxMapper.countByExample(wxExample);
			if (count == 0) {
				return new Message(0, "非法配置的小程序");
			}

			// 小程序专用
			JSONObject wxUser = weChatService.getWeChatInfoWX(code, appid, encryptedData, iv);
			System.out.println("==========获取小程序用户信息=========" + wxUser);
			if (wxUser != null) {
				String openid = wxUser.getString("openid");
				String unionid = wxUser.getString("unionid");
				Para user = userService.findWholeUser(unionid, openid);
				Para userPara = new Para();
				userPara.put("user", user);
				userPara.put("wxUser", wxUser);
				return new Message(1, "成功获取用户数据", userPara);
			} else {
				return new Message(0, "无法获取微信用户", new Para());
			}

		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/registerWX", method = RequestMethod.POST)
	@ResponseBody
	public Message registerWX(HttpServletRequest request, @RequestParam HashMap<Object, Object> map, String refereeid,
			String shopid, String appid) {

		try {
			Para para = new Para(map);

			// 小程序专用
			JSONObject wxUser = para.toJSONObject();
			System.out.println("==========获取小程序用户信息=========" + wxUser);

			if (wxUser != null) {
				String openid = wxUser.getString("openid");
				String unionid = wxUser.getString("unionid");

				wxUser.put("shopid", shopid);
				wxUser.put("platform", DBC.PLATFORM_PRO);
				wxUser.put("refereeid", refereeid);

				// 小程序传递的参数名和公众号有些许不同，处理下
				wxUser.put("nickname", wxUser.getString("nickName"));
				wxUser.put("headimgurl", wxUser.getString("avatarUrl"));
				wxUser.put("sex", wxUser.getString("gender"));
				wxUser.put("province", wxUser.getString("province"));
				wxUser.put("city", wxUser.getString("city"));
				wxUser.put("country", wxUser.getString("country"));
				wxUser.put("unionid", wxUser.getString("unionid"));

				Message mesR = null;
				Para user = userService.findUser(unionid, openid);
				if (user != null) {
					userService.updateWxidById(user.getString("id"), openid, unionid);// 更新下openid和unionid
					user.put("sessionKey", wxUser.getString("sessionKey"));// 小程序注册用户手机号需要用到

					System.out.println("=======客户数据已存在=========" + user);
					mesR = new Message(1, "获取用户数据成功", new Para("user", user));
				} else {
					mesR = weChatService.register(wxUser);
					user = mesR.getData().getPara("user");

					System.out.println("=======注册新客户数据=========" + user);
				}
				// 返回sessionid
				HttpSession session = request.getSession();
				String sessionid = session.getId();
				user.put("sessionid", sessionid);

				// 保存小程序会话记录
				Para wxSessionPara = new Para();
				wxSessionPara.put("userid", user.getString("id"));
				wxSessionPara.put("appid", appid);
				wxSessionPara.put("sessionid", sessionid);
				wxSessionPara.put("data", JSONObject.toJSONString(user));
				wxSessionService.add(wxSessionPara);

				return mesR;
			} else {
				return new Message(0, "无法自动注册，没有有效的openid");
			}

		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/getWeChatInfo", method = RequestMethod.POST)
	@ResponseBody
	public Message getWeChatInfo(HttpServletRequest request, @RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			String code = para.getString("code");
			String shopid = para.getString("shopid");

			String refereeid = para.getString("refereeid");
			request.getSession().setAttribute("weixinUser", null);
			Object weixinUser = request.getSession().getAttribute("weixinUser");

			JSONObject wxUser = null;
			if (weixinUser != null) {
				// 证明已经查找过用户信息，直接使用。
				wxUser = (JSONObject) weixinUser;
			} else {
				wxUser = weChatService.getWeChatInfo(code, shopid);
				request.getSession().setAttribute("weixinUser", wxUser);
			}

			System.out.println("==========获取用户信息=========" + wxUser);
			if (wxUser == null) {
				request.getSession().setAttribute("weixinUser", null);
				throw new ServiceLogicException("无法获取微信用户");
			}
			String openid = wxUser.getString("openid");
			String unionid = wxUser.getString("unionid");

			Message mes = null;
			Para user = userService.findUser(unionid, openid);
			if (user != null) {
				userService.updateWxidById(user.getString("id"), openid, unionid);// 更新下openid和unionid
				request.getSession().setAttribute("loginUser", user);
				mes = new Message(1, "获取用户数据成功", new Para("user", user));
				System.out.println("=======客户数据已存在=========");
			} else {
				// 数据库没有用户，则注册用户
				wxUser.put("shopid", shopid);
				wxUser.put("platform", DBC.PLATFORM_H5);
				wxUser.put("refereeid", refereeid);
				mes = weChatService.register(wxUser);
				System.out.println("=======注册新客户数据=========");
			}

			return mes;
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/unifiedorder", method = RequestMethod.GET)
	@ResponseBody
	public Message unifiedorder(@RequestParam HashMap<Object, Object> map, HttpServletRequest req) {
		try {
			Para para = new Para(map);
			System.out.println("========" + para);
			String billid = para.getString("billid");// 业务订单号
			String shopid = para.getString("shopid"); // 公众号门店ID
			String userid = para.getString("userid");// 支付用户userid
			String appidWx = para.getString("appidWx");// 小程序appid

			String price = "0";
			Para validRS = weChatService.validUnifiedorder(para);
			if (validRS.getBoolean("pass")) {
				price = validRS.getString("price");// 验证成功后获取真实的支付金额
			} else {
				return new Message(0, validRS.getString("desc"));
			}
			String host = req.getServerName();
			String notify_url = Context.url(host) + "weChat/pay_notify";

			String ip = IpKit.getRealIp(req);
			Para payRS = weChatService.unifiedorder(notify_url, userid, billid, price, ip, shopid, appidWx);
			return new Message(1, "微信统一下单成功", payRS);
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	@RequestMapping(value = "/pay_notify", method = RequestMethod.POST)
	@ResponseBody
	public void pay_notify(HttpServletRequest req, HttpServletResponse res) {

		try {
			System.out.println("==============支付后开始回调=============");

			// 支付结果通用通知文档:
			// https://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=9_7
			String xmlMsg = HttpKit.readData(req);
			System.out.println("支付通知=" + xmlMsg);

			Map<String, String> params = PaymentKit.xmlToMap(xmlMsg);

			String appid = params.get("appid");
			String result_code = params.get("result_code");

			Para shop = shopService.loadWXConfByWX(appid);// 加载门店公众号配置
			// 注意重复通知的情况，同一订单号可能收到多次通知，请注意一定先判断订单状态
			// 避免已经成功、关闭、退款的订单被再次更新

			if (PaymentKit.verifyNotify(params, shop.getString("paternerKey"))) {

				if (("SUCCESS").equals(result_code)) {
					weChatService.paySuccess(params);// 支付成功后处理
					Map<String, String> xml = new HashMap<String, String>();
					xml.put("return_code", "SUCCESS");
					xml.put("return_msg", "OK");
					res.getWriter().write(PaymentKit.toXml(xml));

				} else {
					weChatService.payFail(params);// 支付失败后处理
					Map<String, String> xml = new HashMap<String, String>();
					xml.put("return_code", "ERROR");
					xml.put("return_msg", "OK");
					res.getWriter().write(PaymentKit.toXml(xml));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
