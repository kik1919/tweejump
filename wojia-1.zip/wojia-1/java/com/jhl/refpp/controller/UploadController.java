package com.jhl.refpp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.ProgressListener;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.util.ImgCompress;
import com.jhl.refpp.util.UploadFile;

@Controller
@RequestMapping("/file")
public class UploadController extends BaseController {

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	@ResponseBody
	public Message upload(HttpServletRequest req) {

		// System.out.println("======UploadFile=========");

		try {
			if (UploadFile.isUploadRequest(req)) {
				UploadFile uploadFile = UploadFile.parser(req, new ProgressListener() {
					@Override
					public void update(long arg0, long arg1, int arg2) {
					}
				});
				String path = req.getServletContext().getRealPath("/");
				// System.out.println("======path======" + path);

				List<Object> fileNames = uploadFile.getValues("fileName");
				List<Object> filePaths = uploadFile.getValues("filePath");
				List<Object> fileSuffixs = uploadFile.getValues("fileSuffix");
				List<Object> widths = uploadFile.getValues("width");
				List<Object> heights = uploadFile.getValues("height");
				List<Object> isCompresss = uploadFile.getValues("isCompress");
				List<Object> pathPres = uploadFile.getValues("pathPre");
				// System.out.println(fileNames.size());
				// System.out.println(filePaths.size());
				// System.out.println(fileSuffixs.size());
				// System.out.println(widths.size());
				// System.out.println(heights.size());
				// System.out.println(isCompresss.size());
				List<FileItem> files = uploadFile.getAllUploadFile();
				for (int i = 0; i < files.size(); i++) {
					FileItem file = files.get(i);
					String fileName = fileNames.get(i).toString();
					String filePath = filePaths.get(i).toString();
					String fileSuffix = fileSuffixs.get(i).toString();
					String pathPre = pathPres.get(i).toString();
					if (pathPre.equals("null") || pathPre.equals("undefined")) {
						pathPre = "img";
					}
					boolean isCompress = Boolean.parseBoolean(isCompresss.get(i).toString());
					uploadFile.save(file, path + pathPre + "/" + filePath + "/", fileName + "." + fileSuffix);
					// System.out.println(pathPre+"=======size========="+file.getSize());
					if (isCompress) {
						int width = Integer.parseInt(widths.get(i).toString());
						int height = Integer.parseInt(heights.get(i).toString());
						String src = path + pathPre + "/" + filePath + "/" + fileName + "." + fileSuffix;
						ImgCompress imgCom = new ImgCompress();
						imgCom.setSrcFile(src);
						imgCom.setDestFile(src);
						imgCom.resizeFix(width, height);
					}

				}
				return new Message();
			} else {
				return new Message(Message.ERROR, "失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}

	}

}
