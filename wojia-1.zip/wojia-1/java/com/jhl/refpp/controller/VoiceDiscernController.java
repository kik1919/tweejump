package com.jhl.refpp.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.baidu.aip.speech.AipSpeech;
import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.util.Util;

@Controller
@RequestMapping("/discern")
public class VoiceDiscernController extends BaseController {

	// 设置APPID/AK/SK，注册百度语音识别API即可获取
	public static final String APP_ID = "16341817";
	public static final String API_KEY = "GjPzw0yv3ExOWGtmD7W9YD2p";
	public static final String SECRET_KEY = "VLxG3FYKfPAPfHdAztHRAkHzgVDqMmV9";

	@RequestMapping(value = "/speechRecognition", method = RequestMethod.POST)
	@ResponseBody
	public Message speechRecognition(HttpServletRequest request) {
		try {
			String rs = null;
			Para data = new Para();
			MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
			MultipartHttpServletRequest multipartRequest = resolver.resolveMultipart(request);
			MultipartFile file = multipartRequest.getFile("file");
			byte[] pcmBytes = mp3Convertpcm(file.getInputStream());
			JSONObject resultJson = speechBdApi(pcmBytes);
			System.out.println(resultJson.toString());
			if (null != resultJson && resultJson.getInt("err_no") == 0) {
				rs = resultJson.getJSONArray("result").get(0).toString();
				data.put("rs", rs);
			}
			if (rs != null) {
				return new Message(1, "语音转换成功", data);
			} else {
				return new Message(0, "语音转换失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

	/**
	 * @Description MP3转换pcm
	 * @param mp3Stream
	 *            原始文件流
	 * @return 转换后的二进制
	 * @throws Exception
	 * @author liuyang
	 * @blog http://www.pqsky.me
	 * @date 2018年1月30日
	 */
	public byte[] mp3Convertpcm(InputStream mp3Stream) throws Exception {
		BufferedInputStream zipTest = new BufferedInputStream(mp3Stream);
		AudioInputStream mp3audioStream = AudioSystem.getAudioInputStream(zipTest);
		AudioInputStream pcmaudioStream = AudioSystem.getAudioInputStream(AudioFormat.Encoding.PCM_SIGNED,
				mp3audioStream);
		byte[] pcmBytes = IOUtils.toByteArray(pcmaudioStream);
		pcmaudioStream.close();
		mp3audioStream.close();
		return pcmBytes;
	}

	public static void main(String[] args) throws UnsupportedAudioFileException, IOException {
		AudioInputStream mp3audioStream = AudioSystem.getAudioInputStream(new File(Util.appRoot + "img/bg0.mp3"));
		AudioInputStream pcmaudioStream = AudioSystem.getAudioInputStream(AudioFormat.Encoding.PCM_SIGNED,
				mp3audioStream);
		byte[] pcmBytes = IOUtils.toByteArray(pcmaudioStream);
		pcmaudioStream.close();
		mp3audioStream.close();
		System.out.println(pcmBytes);
	}

	/**
	 * @Description 调用百度语音识别API
	 * @param pcmBytes
	 * @return
	 * @author liuyang
	 * @blog http://www.pqsky.me
	 * @date 2018年1月30日
	 */
	public static JSONObject speechBdApi(byte[] pcmBytes) {
		// 初始化一个AipSpeech
		AipSpeech client = new AipSpeech(APP_ID, API_KEY, SECRET_KEY);
		// 可选：设置网络连接参数
		client.setConnectionTimeoutInMillis(2000);
		client.setSocketTimeoutInMillis(60000);
		// 调用接口
		JSONObject res = client.asr(pcmBytes, "pcm", 16000, null);
		return res;
	}

}
