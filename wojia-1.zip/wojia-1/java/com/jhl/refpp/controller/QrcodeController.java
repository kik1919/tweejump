package com.jhl.refpp.controller;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jhl.refpp.core.BaseController;
import com.jhl.refpp.core.Para;
import com.jhl.refpp.core.config.tag.Message;
import com.jhl.refpp.service.ShopService;
import com.jhl.refpp.util.WeixinUtil;

@Controller
@RequestMapping("/qrcode")
public class QrcodeController extends BaseController {

	@Resource(name = "shopService")
	private ShopService shopService;

	@RequestMapping(value = "/wx", method = RequestMethod.POST)
	@ResponseBody
	public Message wx(@RequestParam HashMap<Object, Object> map) {
		try {
			Para para = new Para(map);
			String shopid = para.getString("shopid");
			String path = para.getString("path");
			String page = para.getString("page");
			String param = para.getString("param");
			Para shop = shopService.loadWXConfById(shopid);// 加载门店微信配置
			String accessToken = WeixinUtil.postToken(shop.getString("appidWx"), shop.getString("appSecretWx"));
			System.out.println("======accessToken=======" + accessToken);
			String qrcode = WeixinUtil.getminiqrQr(path, page, param, accessToken);// 第一个为参数
																					// 第二个为token
			return new Message(1, "成功", new Para("qrcode", qrcode));
		} catch (Exception e) {
			e.printStackTrace();
			return new Message(e);
		}
	}

}
