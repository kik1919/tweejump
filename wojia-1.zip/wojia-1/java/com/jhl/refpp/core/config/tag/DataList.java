package com.jhl.refpp.core.config.tag;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.jhl.refpp.core.Para;
import com.jhl.refpp.exception.SupportException;
import com.jhl.refpp.po.SerialNo;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.Util;

/***
 * 集合类，用于映射成XML、JSON格式的数据。
 * 
 * @author 蒋海林
 * 
 */
public class DataList extends HashMap<String, Object> {
	private static final long serialVersionUID = 1L;

	private String trackID = new Date().getTime() + "";
	private int state = 0;

	private int size = 0;// 当前行数
	private int count = 0;// 总行数
	private int total = 0;// 总数
	private List data = new ArrayList();// 包含实际数据的数组
	private List rows = new ArrayList();// 包含实际数据的数组

	private void init() {
		this.put("trackID", this.trackID);
		this.put("state", this.state);
		this.put("size", this.size);
		this.put("count", this.count);
		this.put("data", this.data);
		this.put("total", this.count);
		this.put("rows", this.data);
	}

	public DataList() {
		// 生成JSON数据做准备
		this.init();
	}

	public DataList(List list, int count) {
		if (list == null) {
			list = new ArrayList();
			this.state = 0;
		} else if (list.size() == 0) {
			this.state = 0;
		} else {
			this.size = list.size();
			this.state = 1;
		}
		this.data = list;
		this.count = count;
		this.rows = list;
		this.total = count;
		// 生成JSON数据做准备
		this.init();
	}

	public DataList(List list, int count, SerialNo serialNo) {
		this(list, count);
		if (serialNo != null) {
			// 记录流水
			serialNo.setLevel(DBC.YES);
			serialNo.setTrace(serialNo.getDetail());
			serialNo.setId(new Date().getTime() + "");
			serialNo.setCreatedAt(new Date());
			MapperFactory.serialNoMapper.insert(serialNo);
		}
	}

	/***
	 * 获取被包装数据的Class对象
	 * 
	 * @return
	 * @throws SupportException
	 */
	public Class<?> getBeanClass() throws SupportException {
		if (this.data != null && this.data.size() != 0) {
			return this.data.get(0).getClass();
		} else {
			return Message.class;
		}
	}

	/***
	 * 获取被包装数据集合的第一个对象
	 * 
	 * @return
	 * @throws SupportException
	 */
	public Object getFirstBean() throws SupportException {
		if (this.data != null && this.data.size() != 0) {
			return this.data.get(0);
		} else {
			return null;
		}
	}

	public List append(DataList dataList) {
		this.data.addAll(dataList.data);
		if (this.data.size() == 0) {
			this.state = 0;
		} else {
			this.size = this.data.size();
			this.state = 1;
		}
		// 生成JSON数据做准备
		this.init();

		return this.data;
	}

	public List<Para> list() {
		return this.data;
	}

	public Para first() {
		if (this.data != null && this.data.size() != 0) {
			return (Para) this.data.get(0);
		} else {
			return null;
		}
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getTrackID() {
		return trackID;
	}

	public void setTrackID(String trackID) {
		this.trackID = trackID;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public List Data() {
		return data;
	}

	public List Rows() {
		return rows;
	}

	public void setData(List data) {
		this.data = data;
		this.init();
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public void setRows(List rows) {
		this.rows = rows;
	}

}
