package com.jhl.refpp.core.config.tag;

import java.util.Date;
import java.util.List;

import com.jhl.refpp.core.Para;
import com.jhl.refpp.exception.ServiceLogicException;
import com.jhl.refpp.po.SerialNo;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.DBC;
import com.jhl.refpp.util.Util;

/***
 * 消息标识定义 <br/>
 * MESSAGE
 * 
 * @author 蒋海林
 * 
 */
public class Message {
	/***
	 * 错误，标号0
	 */
	public static int ERROR = 0;
	/***
	 * 成功，标号1
	 */
	public static int SUCCESS = 1;

	private int state = 1;
	private String message = "";
	private String description = "";
	private String trackID = new Date().getTime() + "";
	private int auth = 0;// 权限判断标识;0：普通；1：权限

	public int getAuth() {
		return auth;
	}

	public void setAuth(int auth) {
		this.auth = auth;
	}

	private Para data;
	private List<Para> rows;

	public List<Para> getRows() {
		return rows;
	}

	public void setRows(List<Para> rows) {
		this.rows = rows;
	}

	public Para getData() {
		return data;
	}

	public void setData(Para data) {
		this.data = data;
	}

	public Message() {

	}

	public Message(int count, String message, Para data) {
		this.message = message;
		this.data = data;
		if (count != 0) {
			this.description = "成功";
			this.state = 1;
		} else {
			this.description = "失败";
			this.state = 0;
		}
	}

	public Message(int count, String message) {
		this.message = message;
		if (count != 0) {
			this.description = "成功";
			this.state = 1;
		} else {
			this.description = "失败";
			this.state = 0;
		}
	}

	public Message(Exception e) {
		this(ERROR, Message.msg(e));
		// 记录流水
		SerialNo serialNo = new SerialNo();
		if (e.getClass() == ServiceLogicException.class) {
			ServiceLogicException my = (ServiceLogicException) e;
			serialNo = my.getSerialNo();
			if (serialNo == null) {
				serialNo = new SerialNo();
			}
			serialNo.setLevel(DBC.YES);
		} else {
			serialNo.setDetail(Message.msg(e));
			serialNo.setLevel(DBC.NO);
		}
		serialNo.setTrace(Util.printStackTraceToString(e).replaceAll("<br/>", ";")
				.replaceAll("\n", "<p class='marginline'><p>").substring(0, 5000));
		serialNo.setId(new Date().getTime() + "");
		serialNo.setCreatedAt(new Date());
		MapperFactory.serialNoMapper.insertSelective(serialNo);

	}

	public Message(int count, String message, Para data, SerialNo serialNo) {
		this(count, message, data);
		if (serialNo != null) {
			// 记录流水
			serialNo.setLevel(DBC.YES);
			serialNo.setTrace(serialNo.getDetail());
			serialNo.setId(new Date().getTime() + "");
			serialNo.setCreatedAt(new Date());
			MapperFactory.serialNoMapper.insert(serialNo);
		}
	}

	public Message(int count, String message, SerialNo serialNo) {
		this(count, message);
		if (serialNo != null) {
			// 记录流水
			serialNo.setLevel(DBC.YES);
			serialNo.setTrace(serialNo.getDetail());
			serialNo.setId(new Date().getTime() + "");
			serialNo.setCreatedAt(new Date());
			MapperFactory.serialNoMapper.insert(serialNo);
		}

	}

	public String getTrackID() {
		return trackID;
	}

	public void setTrackID(String trackID) {
		this.trackID = trackID;
	}

	/***
	 * 设置状态<br/>
	 * 同时设置默认描述
	 * 
	 * @param state
	 */
	public void setState(int state) {
		this.state = state;
		if (state == 0) {
			this.description = "失败";
		} else if (state == 1) {
			this.description = "成功";
		} else {
			this.description = "信息";
		}
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getState() {
		return state;
	}

	public String getMessage() {
		return message;
	}

	/***
	 * 包装Exception错误信息<br/>
	 * 数据库访问或者程序异常时候发生错误 <br/>
	 * 然后包装后返回的提示消息。
	 * 
	 * @param e
	 * @return
	 */
	public static String msg(Exception e) {
		e.printStackTrace();
		if (e.getMessage() != null) {
			if (e.getClass() == ServiceLogicException.class) {
				return e.getMessage();
			} else {
				return e.getMessage();
			}

		} else {
			return "出现空指针异常！";
		}
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
