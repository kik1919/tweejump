package com.jhl.refpp.core.config.tag;

import java.util.HashMap;
import java.util.Map;

public class Pager {
	private String sort;// 排序列（easyui表格）
	private Integer rows;// 行数（easyui表格）
	private Integer page;// 页码（easyui表格）

	private Integer start;
	private Integer limit;
	private String order;
	private String exceptFields;
	private String fields;
	private Map<String, String> exceptFieldsMap;
	private Map<String, String> fieldsMap;

	// 支持easyui表格组件
	private void supportEasyui() {
		if (this.page != null && this.rows != null) {
			if (this.page == 1) {
				this.start = 0;
			} else {
				this.start = (this.page - 1) * this.rows;
			}
			this.limit = this.rows;
		}
	}

	public Map<String, String> getExceptFieldsMap() {
		return exceptFieldsMap;
	}

	public Map<String, String> getFieldsMap() {
		return fieldsMap;
	}

	public Pager() {
	}

	public Pager(Integer start, Integer limit) {
		this.limit = limit;
		this.start = start;
	}

	public Pager(Integer start, Integer limit, String order) {
		this.limit = limit;
		this.start = start;
		this.order = order;
	}

	public Integer getStart() {
		supportEasyui();
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getLimit() {
		supportEasyui();
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public String getOrder() {
		supportEasyui();
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public Integer getRows() {
		return rows;
	}

	public void setRows(Integer rows) {
		this.rows = rows;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public String getExceptFields() {
		return exceptFields;
	}

	public void setExceptFields(String exceptFields) {
		this.exceptFields = exceptFields;
		if (this.exceptFields != null) {
			exceptFieldsMap = new HashMap<String, String>();
			String[] fields = exceptFields.split(",");
			for (int i = 0; i < fields.length; i++) {
				String field = fields[i];
				exceptFieldsMap.put(field, field);
			}
		}
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
		if (this.fields != null) {
			fieldsMap = new HashMap<String, String>();
			String[] fieldstr = fields.split(",");
			for (int i = 0; i < fieldstr.length; i++) {
				String field = fieldstr[i];
				fieldsMap.put(field, field);
			}
		}
	}

}
