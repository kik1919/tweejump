package com.jhl.refpp.core;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.alibaba.fastjson.JSON;
import com.jhl.refpp.po.WxSession;
import com.jhl.refpp.po.WxSessionExample;
import com.jhl.refpp.support.MapperFactory;
import com.jhl.refpp.util.Util;

public class BaseController {
	protected HashMap<Object, Object> getLoginUser() {
		Para loginUser = (Para) Util.getSession().getAttribute("loginUser");
		if (loginUser != null) {
			return loginUser;
		} else {
			try {
				WxSessionExample wxSessionExample = new WxSessionExample();
				wxSessionExample.createCriteria().andSessionidEqualTo(Util.getRequest().getParameter("sessionid"));
				List<WxSession> sessionList = MapperFactory.WxSessionMapper.selectByExample(wxSessionExample);
				if (Util.hasValue(sessionList)) {
					WxSession wxSession = sessionList.get(0);
					Map<Object, Object> map = (Map<Object, Object>) JSON.parse(wxSession.getData());
					loginUser = new Para(map);
					return loginUser;
				}
				return null;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}

		}
	} 

	@InitBinder
	protected void ininBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
