package com.jhl.refpp.core;

import com.jhl.refpp.util.StringUtils;

public class Context {
	public static String context = "/wojia/";

	public static String url(String host) {
		if (StringUtils.isNullOrEmpty(host)) {
			return "https://www.scjhhy.com" + context;
		} else {
			return "https://" + host + context;
		}

	}
}
