package com.jhl.refpp.core;

import java.lang.reflect.Method;
import java.util.List;

import com.jhl.refpp.core.config.tag.DataList;
import com.jhl.refpp.exception.SupportException;
import com.jhl.refpp.util.StringUtils;

public class SqlMappler {
	public static DataList _query(Object mapper, Para para, String method) throws Exception {
		Class c = mapper.getClass();
		String m = "";
		if (StringUtils.isEmpty(method)) {
			m = "getList";
		} else {
			m = method;
		}
		Method getList = c.getMethod(m, Para.class);
		Method getListCount = null;
		try {
			getListCount = c.getMethod(m + "_count", Para.class);
		}catch(Exception e) {
			getListCount = null;
		}
		if (getList == null) {
			throw new SupportException("沒有找到getList方法");
		}
		List<Para> list = (List<Para>) getList.invoke(mapper, para);

		int count = 0;
		if (getListCount != null) {
			count = (int) getListCount.invoke(mapper, para);
		}
		DataList data = new DataList(list, count);
		return data;
	}

	public static DataList query(Object mapper, Para para) throws Exception {
		return _query(mapper, para, null);
	}

	public static DataList query(Object mapper, Para para, String method) throws Exception {
		return _query(mapper, para, method);
	}
}
