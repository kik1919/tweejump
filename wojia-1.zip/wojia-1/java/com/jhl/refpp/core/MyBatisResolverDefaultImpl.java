package com.jhl.refpp.core;

import java.sql.Types;
 
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.internal.types.JavaTypeResolverDefaultImpl;
 
public class MyBatisResolverDefaultImpl extends JavaTypeResolverDefaultImpl {
	public MyBatisResolverDefaultImpl()
	{
		 
		super.typeMap.put(Types.ARRAY, new JavaTypeResolverDefaultImpl.JdbcTypeInformation("DECIMAL", new FullyQualifiedJavaType(Integer.class.getName())));


	}
}
