package com.jhl.refpp.core;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.jhl.refpp.util.DateParser;

public class Para extends HashMap<Object, Object> {
	public Para() {

	}

	public Para(Object key, Object value) {
		this.put(key, value);
	}

	/***
	 * 把map重新包装成自定义map
	 * 
	 * @param params
	 */
	public Para(Map<Object, Object> params) {
		this.append(params);
	}

	/***
	 * 转换成JSONObject
	 * 
	 * @param params
	 * @return
	 */
	public JSONObject toJSONObject() {
		JSONObject json = new JSONObject();
		for (Map.Entry<Object, Object> entry : this.entrySet()) {
			Object name = entry.getKey();
			Object value = entry.getValue();
			json.put(name.toString(), value);
		}
		return json;
	}

	/***
	 * 追加
	 * 
	 * @param params
	 * @return
	 */
	public Para append(Map<Object, Object> params) {
		for (Map.Entry<Object, Object> entry : params.entrySet()) {
			Object name = entry.getKey();
			Object value = entry.getValue();
			this.put(name, value);
		}
		return this;
	}

	/***
	 * 重新填充
	 * 
	 * @param params
	 * @return
	 */
	public Para puts(Map<Object, Object> params) {
		this.clear();
		this.append(params);
		return this;
	}

	/***
	 * 转换成Para对象
	 * 
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static Para trans(Object obj) throws Exception {
		Para para = new Para();
		Field[] fs = obj.getClass().getDeclaredFields();
		int len = fs.length;
		for (int i = 0; i < len; i++) {
			Field f = fs[i];
			f.setAccessible(true);
			String name = f.getName();
			Object value = f.get(obj);
			para.put(name, value);
		}
		return para;
	}

	/***
	 * 转换成bean对象
	 * 
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public Object trans(Class clazz) throws Exception {
		Object obj = clazz.newInstance();
		Field[] fs = clazz.getDeclaredFields();
		int len = fs.length;
		for (int i = 0; i < len; i++) {
			Field f = fs[i];
			f.setAccessible(true);
			String name = f.getName();
			Object value = this.get(name);
			String type = f.getType().getName();
			if (type.equals("java.lang.String")) {
				f.set(obj, value);

			} else if (type.equals("java.lang.Integer")) {
				f.set(obj, this.getInteger(name));
			} else if (type.equals("int")) {
				Integer val = this.getInteger(name);
				if (val != null) {
					f.setInt(obj, val.intValue());
				}

			} else if (type.equals("java.lang.Boolean")) {
				f.set(obj, this.getBoolean(name));
			} else if (type.equals("boolean")) {
				Boolean val = this.getBoolean(name);
				if (val != null) {
					f.setBoolean(obj, val.booleanValue());
				}
			} else if (type.equals("java.lang.Float")) {
				f.set(obj, this.getFloat(name));
			} else if (type.equals("float")) {
				Float val = this.getFloat(name);
				if (val != null) {
					f.setFloat(obj, val.floatValue());
				}

			} else if (type.equals("java.lang.Double")) {
				f.set(obj, this.getFloat(name));
			} else if (type.equals("double")) {
				Double val = this.getDouble(name);
				if (val != null) {
					f.setDouble(obj, val.doubleValue());
				}

			} else if (type.equals("java.lang.Long")) {
				f.set(obj, this.getLong(name));
			} else if (type.equals("long")) {
				Long val = this.getLong(name);
				if (val != null) {
					f.setLong(obj, val.longValue());
				}

			} else if (type.equals("java.lang.Byte")) {
				f.set(obj, this.getByte(name));
			} else if (type.equals("byte")) {
				Byte val = this.getByte(name);
				if (val != null) {
					f.setByte(obj, val.byteValue());
				}

			} else if (type.equals("java.lang.Short")) {
				f.set(obj, this.getShort(name));
			} else if (type.equals("short")) {
				Short val = this.getShort(name);
				if (val != null) {
					f.setShort(obj, val.shortValue());
				}

			} else if (type.equals("java.math.BigDecimal")) {
				// 转换金额
				Float val = this.getFloat(name);
				if (val != null) {
					f.set(obj, new java.math.BigDecimal(val.floatValue()));
				}
			} else if (type.equals("java.util.Date")) {
				// 转换时间
				Object val = this.get(name);
				if (val != null && !val.equals("") && val instanceof String) {
					String str = val.toString();
					// System.out.println("==1===");
					String t[] = str.split(" ");
					if (t.length == 1) {
						f.set(obj, DateParser.parserDate2(str));
					} else {
						f.set(obj, DateParser.parserDate(str));
					}
				} else if (val != null && !val.equals("") && val instanceof Object) {
					// System.out.println("==2===");
					f.set(obj, val);
				}
			}
		}
		return obj;
	}

	public String getString(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return value.toString();
		}
		return null;
	}

	public Boolean getBoolean(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Boolean.parseBoolean(value.toString());
		}
		return null;
	}

	public Integer getInteger(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Integer.valueOf(value.toString());
		}
		return null;
	}

	public Byte getByte(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Byte.valueOf(value.toString());
		}
		return null;
	}

	public Short getShort(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Short.valueOf(value.toString());
		}
		return null;
	}

	public Float getFloat(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Float.valueOf(value.toString());
		}
		return null;
	}

	public Long getLong(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Long.valueOf(value.toString());
		}
		return null;
	}

	public Double getDouble(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return Double.valueOf(value.toString());
		}
		return null;
	}

	public Para getPara(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return (Para) value;
		}
		return null;
	}

	public Date getDate(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return (Date) value;
		}
		return null;
	}

	public BigDecimal getBigDecimal(Object key) {
		Object value = this.get(key);
		if (value != null) {
			return new BigDecimal(value.toString());
		}
		return null;
	}
}
