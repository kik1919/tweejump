INSERT INTO `mb_shop` (`id`, `oid`, `appid_wx`, `app_secret_wx`, `appid`, `app_secret`, `token`, `mch_id`, `file`, `paterner_key`, `name`,`phone`, `head_pic`) VALUES
	('S00000', 'gh_9fda2ea12d52', 'wx43e20b7fb87212e3', 'b5ec8ebb726311f8ad53c39a920416ab', 'wx7a189f600abb25ac', 'b54f0658beab95d5a042deaf515ecb9a', 'wechat_jinghaihuanyu', '1485901412', 'S00000.txt', 'f2gf3g2hej3g4f37d8s96cm98fkkd7zl', '易联易购', '13888888888','img/shop.jpg');
 
INSERT INTO `mb_user` (`id`, `is_del`, `created_at`, `openid`, `unionid`, `openid_wx`, `is_attention`, `qr_code_url`, `from_bootid`, `name`, `country`, `province`, `city`, `sex`, `mobile`, `head_pic`, `pwd`, `credit`, `platform`, `role`, `level`) VALUES
	('00000000000', 0, '2018-10-06 19:50:48.000', 'oPtotwmu0hgfcl57DdLwMr1qoYcg', 'oBuUS0u2qQUUqs3V1aKsdlA2cows', 'oFnf15WXGAtJLB65uzcdiW1j2Ut4', 1, 'http://weixin.qq.com/q/02QYKINl-qcJ210000g07x', '', '蒋海林', '中国', '四川', '成都', '1', '13880636883', 'img/user/00000000000/20580412477128_0.jpeg', '96e79218965eb72c92a549dd5a330112', 24674220, 0, 1, 5),
	('00000000010', 0, '2018-10-24 11:12:36.000', 'oPtotwqFHpD4Ty84APoePTX6w31w', 'oBuUS0mdgLbUFVvWmPtYKl5rjjSE', NULL, 1, 'http://weixin.qq.com/q/02S5tKNZ-qcJ210000g07V', '', '刘子靖-靖海环宇总经理', '中国', '四川', '成都', '1', '13333333333', 'img/user/00000000010/20580331299924_0.jgp', '96e79218965eb72c92a549dd5a330112', 0, 0, 1, 2),
	('00000000011', 0, '2018-10-24 20:31:01.000', 'oPtotwpCG3C8vcb298ZH6yTyjCgc', 'oBuUS0j8Zp5vWa4Bm6yq0Ko6ufJE', NULL, 1, 'http://weixin.qq.com/q/024SY2M6-qcJ210000w07e', '', '欧梵婷 金枝玉叶', '中国', '四川', '成都', '2', '13666666666', 'img/user/00000000011.jpg', '96e79218965eb72c92a549dd5a330112', 0, 0, 2, 2),
	('00000000012', 0, '2018-11-08 22:49:55.000', 'oPtotwo19rggpBD0ZF8ym4NvCpfw', 'oBuUS0tw3imGiXOTiocNbbfSjtkY', NULL, 1, 'http://weixin.qq.com/q/02m0dcM4-qcJ210000w07g', '', '代敏', '中国', '四川', '成都', '2', '13222222222', 'img/user/00000000012.jpg', '96e79218965eb72c92a549dd5a330112', 10, 0, 2, 2);
	
insert into mb_booth_type values("1",0,100,"美容","img/menu/menu1.png?ver=1");
insert into mb_booth_type values("2",0,100,"美发","img/menu/menu2.png?ver=1");
insert into mb_booth_type values("3",0,100,"娱乐","img/menu/menu3.png?ver=1");
insert into mb_booth_type values("4",0,100,"健身","img/menu/menu4.png?ver=1");
insert into mb_booth_type values("5",0,100,"教育","img/menu/menu5.png?ver=1");
insert into mb_booth_type values("6",0,100,"购物","img/menu/menu6.png?ver=1");
insert into mb_booth_type values("7",0,100,"餐饮","img/menu/menu7.png?ver=1");
insert into mb_booth_type values("8",0,100,"旅游","img/menu/menu8.png?ver=1");
insert into mb_booth_type values("9",0,100,"母婴","img/menu/menu9.png?ver=1"); 


--A:booth
--B:boothType
--C:boothUser
--M:buyCard
--E:card
--F:goods
--N:serialNo
--H:UseGoods
--I:SendTime
--V:vip
--J:SpBuyReturnCashService
--K:SpBuyGoodsService
--G:SpService
--K:SpWithdrawService 
--Q:SpGoodsService
--R:SpConditionService
--S:SpBuyService SpBuyTmpService
--L:achGoodsService
--P:achEmpGoodsService
--X:projectService
--Y:cardQrcodeService
--Z:vipUsageRecordService
--DOC:docService
--_A:appointmentService
--_B:cusRemarkService
--_C:empService
--_D:mobileMsgService
--_E:actService
--_F:actBuyService
--_G:wxSessionService



--2019-2-19以下表新增is_valid字段
--mb_sp_buy is_valid amount pre_spbid
--mb_sp_buy_project is_valid
--mb_sp_buy_return_cash is_valid
--mb_sp_withdraw spbid is_valid

