-- -----------------------------------------------------
-- 公众号配置
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_shop` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `oid` VARCHAR(200) NULL  COMMENT '微信数据(原始ID)',
  `appid` VARCHAR(200) NULL  COMMENT '微信数据(appId)',
  `app_secret` VARCHAR(200) NULL  COMMENT '微信数据(appSecret)',
  `token` VARCHAR(200) NULL  COMMENT '微信数据(token)',
  `mch_id` VARCHAR(200) NULL  COMMENT '微信数据(mch_id)',
  `file` VARCHAR(200) NULL  COMMENT '微信数据(file)',
  `paterner_key` VARCHAR(200) NULL  COMMENT '微信数据(paternerKey)',
  `name` VARCHAR(50) NOT NULL COMMENT '名称',
  `phone` VARCHAR(50) NULL COMMENT '电话（手机号/固定电话）',
  `poster` VARCHAR(500) NULL  COMMENT '海报URL',
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '公众号配置';

-- -----------------------------------------------------
-- 小程序配置
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_wx` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',  
  `appid` VARCHAR(50) NULL  COMMENT '',
  `app_secret` VARCHAR(50) NULL  COMMENT '',
  `name` VARCHAR(50) NULL  COMMENT '名称',
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '小程序配置';
 
-- -----------------------------------------------------
-- 用户
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_user` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `is_del` INT(11) NOT NULL DEFAULT '0' COMMENT '是否禁用（0：否、1：是）',
  `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
  `unionid` VARCHAR(50) NULL COMMENT '开放ID',
  `openid` VARCHAR(50) NULL COMMENT '公众号openid',
  `is_attention` INT(11) NULL DEFAULT '1' COMMENT '是否关注公众号（0：否、1：是）',
  `qr_code_url` VARCHAR(500) NULL  COMMENT '公众号推广二维码',
  `referee` VARCHAR(50) NULL DEFAULT NULL COMMENT '推荐人的用户ID',
  `name` VARCHAR(50) NOT NULL COMMENT '微信昵称',
  `country` VARCHAR(50) NULL  COMMENT '国家',
  `province` VARCHAR(50) NULL  COMMENT '省',
  `city` VARCHAR(50) NULL  COMMENT '城市',
  `sex` VARCHAR(50) NULL  COMMENT '性别',
  `mobile` VARCHAR(11) NULL  COMMENT '手机号',
  `platform` INT(11) NOT NULL DEFAULT '0' COMMENT '从什么平台注册？（0：H5、1：小程序）',
  `pwd` VARCHAR(50) NULL  COMMENT '密码',
  `credit` INT(11) NOT NULL DEFAULT '0' COMMENT '分积',
  `role` INT(11) NOT NULL DEFAULT '3' COMMENT '角色（1：管理员；2：业务员；3：顾客；4：店家；）',
  `level` INT(11) NOT NULL DEFAULT '1' COMMENT '顾客等级（1：普通用户；2：普通会员；3：黄金会员；）',
  `head_pic` VARCHAR(500) NULL  COMMENT '头像图片URL', 
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '用户';

-- -----------------------------------------------------
-- 小程序用户保存会话信息
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_wx_session` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `appid` VARCHAR(200) NULL  COMMENT '微信数据(appId)',
  `userid` VARCHAR(50) NULL COMMENT '用户ID',
  `sessionid` VARCHAR(50) NULL COMMENT '会话ID',
  `openid` VARCHAR(50) NULL COMMENT 'OPENID',
  `data` JSON NOT NULL COMMENT '会话数据', 
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '小程序用户保存会话信息';

-- -----------------------------------------------------
-- 操作日志
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_serial_no` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `created_at` datetime(3) NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
  `level` INT(11) NULL DEFAULT '0' COMMENT '级别（0：系统级别错误；1：业务逻辑错误）',
  `trace` VARCHAR(5000) NULL  COMMENT '跟踪信息，常用语错误日志',
  `detail` VARCHAR(5000) NULL  COMMENT '内容，日志描述',
  `targetid` VARCHAR(50) NULL  COMMENT '引用ID',
  `userid` VARCHAR(50) NULL  COMMENT '用户ID/操作者',
  `username` VARCHAR(50) NULL  COMMENT '用户/操作者', 
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '操作日志';

-- -----------------------------------------------------
-- 序列
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_squence` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `num` INT(11) NOT NULL COMMENT '序列号',
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci
COMMENT = '序列';

-- -----------------------------------------------------
-- 消息模板配置
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mb_mes_template` (
  `id` VARCHAR(50) NOT NULL COMMENT '唯一标识',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NULL COMMENT '类别（1：服务下单成功通知、2:订单变更提醒、3：订单取消通知、4：密码修改通知、5：下单成功通知、6：发货提醒、7：登陆提醒）',
  `tid` varchar(50) COLLATE utf8mb4_unicode_ci COMMENT '模板ID', 
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消息模板配置';

 